var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// backend/meter.ts
var meter_exports = {};
__export(meter_exports, {
  onRequest: () => onRequest
});
module.exports = __toCommonJS(meter_exports);

// core/http.ts
var BudgetExceeded = class extends Error {
  constructor(budget, calls, method, path) {
    super(`Leader API budget of ${budget} calls exhausted (${calls} used); refused ${method} ${path}`);
    this.name = "BudgetExceeded";
    this.budget = budget;
    this.calls = calls;
    this.method = method;
    this.path = path;
  }
};
var RateLimited = class extends Error {
  constructor(method, path, retryAfterMs) {
    super(`Rate limited by the Leader (second 429 this sweep) on ${method} ${path}`);
    this.name = "RateLimited";
    this.method = method;
    this.path = path;
    this.retryAfterMs = retryAfterMs;
  }
};
var RETRY_AFTER_MAX_MS = 6e4;
function parseRetryAfter(value, nowMs) {
  if (value === void 0 || value === null)
    return void 0;
  const v = value.trim();
  if (v === "")
    return void 0;
  if (/^\d+(\.\d+)?$/.test(v))
    return Math.round(Number(v) * 1e3);
  const at = Date.parse(v);
  return Number.isFinite(at) ? Math.max(0, at - nowMs) : void 0;
}
function retryAfterOf(source, nowMs) {
  if (source === null || typeof source !== "object")
    return void 0;
  const s = source;
  if (typeof s.retryAfterMs === "number" && Number.isFinite(s.retryAfterMs))
    return Math.max(0, s.retryAfterMs);
  const h = s.headers;
  if (!h)
    return void 0;
  return parseRetryAfter(h["retry-after"] ?? h["Retry-After"], nowMs);
}
function retryWaitMs(retryAfterMs, fallbackMs) {
  if (retryAfterMs === void 0)
    return fallbackMs;
  if (retryAfterMs > RETRY_AFTER_MAX_MS)
    return void 0;
  return Math.max(1e3, retryAfterMs);
}
var RATE_LIMIT_RETRY_MS = 5e3;
function defaultSleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
var DEFAULT_TIMEOUT_MS = 25e3;
var TIMEOUT_PREFIX = "timeout:";
var NETWORK_ERROR_PREFIX = "network_error:";
function callFetch(fetchFn, url, init) {
  return Reflect.apply(fetchFn, globalThis, [url, init]);
}
function joinUrl(baseUrl, path) {
  const base = baseUrl.replace(/\/+$/, "");
  return path.startsWith("/") ? base + path : `${base}/${path}`;
}
function collectHeaders(res) {
  if (!res.headers || typeof res.headers.forEach !== "function")
    return void 0;
  const out = {};
  res.headers.forEach((value, key) => {
    out[key.toLowerCase()] = value;
  });
  return out;
}
function createFetchHttp(options) {
  const defaultTimeout = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  return {
    async request(method, path, body, opts) {
      const timeoutMs = opts?.timeoutMs ?? defaultTimeout;
      const raw = opts?.raw === true;
      const init = { method, headers: {} };
      if (body !== void 0) {
        if (raw && typeof body === "string") {
          init.headers = { "content-type": "text/plain" };
          init.body = body;
        } else {
          init.headers = { "content-type": "application/json" };
          init.body = JSON.stringify(body);
        }
      }
      const controller = typeof AbortController === "function" ? new AbortController() : void 0;
      if (controller)
        init.signal = controller.signal;
      let timer;
      const timedOut = new Promise((resolve) => {
        timer = setTimeout(() => resolve("timeout"), timeoutMs);
      });
      try {
        const exchange = (async () => {
          const res2 = await callFetch(options.fetch, joinUrl(options.baseUrl, path), init);
          const text2 = await res2.text();
          return { res: res2, text: text2 };
        })();
        exchange.catch(() => void 0);
        const outcome = await Promise.race([exchange, timedOut]);
        if (outcome === "timeout") {
          controller?.abort();
          return { status: 0, ok: false, text: `${TIMEOUT_PREFIX} no response from ${method} ${path} within ${timeoutMs} ms` };
        }
        const { res, text } = outcome;
        const headers = collectHeaders(res);
        const result = { status: res.status, ok: res.ok };
        if (headers)
          result.headers = headers;
        if (raw || text.length === 0) {
          result.text = text;
          return result;
        }
        try {
          result.json = JSON.parse(text);
        } catch {
          result.text = text;
        }
        return result;
      } catch (e) {
        return { status: 0, ok: false, text: `${NETWORK_ERROR_PREFIX} ${e instanceof Error ? e.message : String(e)}` };
      } finally {
        if (timer !== void 0)
          clearTimeout(timer);
      }
    }
  };
}

// core/codec.ts
var utf8Encoder = new TextEncoder();
function utf8Decode(bytes) {
  return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
}
function utf8ByteLength(s) {
  let bytes = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 128)
      bytes += 1;
    else if (c < 2048)
      bytes += 2;
    else if (c >= 55296 && c <= 56319 && i + 1 < s.length) {
      const next = s.charCodeAt(i + 1);
      if (next >= 56320 && next <= 57343) {
        bytes += 4;
        i++;
      } else
        bytes += 3;
    } else
      bytes += 3;
  }
  return bytes;
}
function fnv1a(s) {
  const bytes = utf8Encoder.encode(s);
  let h = 2166136261;
  for (let i = 0; i < bytes.length; i++) {
    h ^= bytes[i];
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}
function stableStringify(value) {
  if (value === null || typeof value !== "object") {
    const s = JSON.stringify(value);
    return s === void 0 ? "null" : s;
  }
  if (Array.isArray(value)) {
    return "[" + value.map((v) => isOmitted(v) ? "null" : stableStringify(v)).join(",") + "]";
  }
  const obj = value;
  const parts = [];
  for (const k of Object.keys(obj).sort()) {
    const v = obj[k];
    if (isOmitted(v))
      continue;
    parts.push(JSON.stringify(k) + ":" + stableStringify(v));
  }
  return "{" + parts.join(",") + "}";
}
function isOmitted(v) {
  return v === void 0 || typeof v === "function" || typeof v === "symbol";
}
var B64_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var B64_LOOKUP = (() => {
  const t = new Int16Array(128).fill(-1);
  for (let i = 0; i < B64_ALPHABET.length; i++)
    t[B64_ALPHABET.charCodeAt(i)] = i;
  return t;
})();
var ENCODE_CHUNK = 3 * 8192;
var DECODE_CHUNK = 4 * 8192;
function globalFn(name) {
  const fn = globalThis[name];
  return typeof fn === "function" ? fn : void 0;
}
function binaryString(bytes) {
  return String.fromCharCode.apply(null, bytes);
}
function toBase64(bytes) {
  const btoaFn = globalFn("btoa");
  if (btoaFn) {
    const pieces = [];
    for (let i = 0; i < bytes.length; i += ENCODE_CHUNK)
      pieces.push(btoaFn(binaryString(bytes.subarray(i, i + ENCODE_CHUNK))));
    return pieces.join("");
  }
  return toBase64Pure(bytes);
}
function toBase64Pure(bytes) {
  const out = [];
  let i = 0;
  for (; i + 2 < bytes.length; i += 3) {
    const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
    out.push(B64_ALPHABET[n >> 18 & 63], B64_ALPHABET[n >> 12 & 63], B64_ALPHABET[n >> 6 & 63], B64_ALPHABET[n & 63]);
  }
  const rest = bytes.length - i;
  if (rest === 1) {
    const n = bytes[i] << 16;
    out.push(B64_ALPHABET[n >> 18 & 63], B64_ALPHABET[n >> 12 & 63], "==");
  } else if (rest === 2) {
    const n = bytes[i] << 16 | bytes[i + 1] << 8;
    out.push(B64_ALPHABET[n >> 18 & 63], B64_ALPHABET[n >> 12 & 63], B64_ALPHABET[n >> 6 & 63], "=");
  }
  return out.join("");
}
function fromBase64(input) {
  const s = input.replace(/[\t\n\f\r ]+/g, "");
  if (s.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(s))
    throw new Error("invalid base64 input");
  const padding = s.endsWith("==") ? 2 : s.endsWith("=") ? 1 : 0;
  const out = new Uint8Array(s.length / 4 * 3 - padding);
  const atobFn = globalFn("atob");
  if (!atobFn)
    return fromBase64Pure(s, out);
  let o = 0;
  for (let i = 0; i < s.length; i += DECODE_CHUNK) {
    const bin = atobFn(s.slice(i, i + DECODE_CHUNK));
    for (let j = 0; j < bin.length; j++)
      out[o++] = bin.charCodeAt(j);
  }
  return out;
}
function fromBase64Pure(s, out) {
  let o = 0;
  for (let i = 0; i < s.length; i += 4) {
    const a = B64_LOOKUP[s.charCodeAt(i)];
    const b = B64_LOOKUP[s.charCodeAt(i + 1)];
    const c = s[i + 2] === "=" ? 0 : B64_LOOKUP[s.charCodeAt(i + 2)];
    const d = s[i + 3] === "=" ? 0 : B64_LOOKUP[s.charCodeAt(i + 3)];
    const n = a << 18 | b << 12 | c << 6 | d;
    if (o < out.length)
      out[o++] = n >> 16 & 255;
    if (o < out.length)
      out[o++] = n >> 8 & 255;
    if (o < out.length)
      out[o++] = n & 255;
  }
  return out;
}
function streamCtor(name) {
  const ctor = globalThis[name];
  return typeof ctor === "function" ? ctor : void 0;
}
function hasCompressionStreams() {
  return streamCtor("CompressionStream") !== void 0 && streamCtor("DecompressionStream") !== void 0;
}
async function pump(stream, input) {
  const writer = stream.writable.getWriter();
  const reader = stream.readable.getReader();
  const writing = (async () => {
    await writer.write(input);
    await writer.close();
  })();
  writing.catch(() => void 0);
  const parts = [];
  let total = 0;
  for (; ; ) {
    const { done, value } = await reader.read();
    if (done)
      break;
    if (value) {
      parts.push(value);
      total += value.byteLength;
    }
  }
  await writing;
  const out = new Uint8Array(total);
  let offset = 0;
  for (const p of parts) {
    out.set(p, offset);
    offset += p.byteLength;
  }
  return out;
}
var webCodec = {
  encoding: "gzip",
  async gzip(s) {
    const Ctor = streamCtor("CompressionStream");
    if (!Ctor)
      throw new Error("CompressionStream is not available in this runtime");
    return pump(new Ctor("gzip"), utf8Encoder.encode(s));
  },
  async gunzip(b) {
    const Ctor = streamCtor("DecompressionStream");
    if (!Ctor)
      throw new Error("DecompressionStream is not available in this runtime");
    return utf8Decode(await pump(new Ctor("gzip"), b));
  }
};
var identityCodec = {
  encoding: "identity",
  async gzip(s) {
    return utf8Encoder.encode(s);
  },
  async gunzip(b) {
    return utf8Decode(b);
  }
};
function detectCodec() {
  return hasCompressionStreams() ? webCodec : identityCodec;
}

// core/adapters/cribl-urls.ts
var seg = encodeURIComponent;
var group = (gid) => `/m/${seg(gid)}`;
var streamGroups = () => "/products/stream/groups";
var inputs = (gid) => `${group(gid)}/system/inputs`;
var outputs = (gid) => `${group(gid)}/system/outputs`;
var pipelines = (gid) => `${group(gid)}/pipelines`;
var routes = (gid) => `${group(gid)}/routes`;
var versionLog = (gid, count2) => `${group(gid)}/version?count=${Math.max(1, Math.floor(count2))}`;
var versionShow = (gid, hash, diffLineLimit = 1) => `${group(gid)}/version/show?commit=${seg(hash)}&diffLineLimit=${Math.max(1, Math.floor(diffLineLimit))}`;
var versionFiles = (gid, hash) => `${group(gid)}/version/files?commit=${seg(hash)}`;
var metricsQuery = () => "/system/metrics/query";
var kvKey = (key) => `/kvstore/${key.split("/").map(seg).join("/")}`;
var kvKeys = () => "/kvstore/keys";

// core/time.ts
var MINUTE_MS = 6e4;
var HOUR_MS = 36e5;
var DAY_MS = 864e5;
var MINUTES_PER_YEAR = 525600;
function minuteFloor(ms) {
  return Math.floor(ms / MINUTE_MS) * MINUTE_MS;
}
function hourFloor(ms) {
  return Math.floor(ms / HOUR_MS) * HOUR_MS;
}
function toIso(ms) {
  return new Date(ms).toISOString();
}
function fromIso(iso2) {
  if (typeof iso2 !== "string" || iso2.length === 0)
    return Number.NaN;
  return Date.parse(iso2);
}
function utcHourKey(ms) {
  return toIso(ms).slice(0, 13);
}
function utcDayKey(ms) {
  return toIso(ms).slice(0, 10);
}
function utcMonthKey(ms) {
  return toIso(ms).slice(0, 7);
}
var partsFormatters = /* @__PURE__ */ new Map();
function partsFormatter(tz) {
  let f = partsFormatters.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", {
      timeZone: tz,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
    partsFormatters.set(tz, f);
  }
  return f;
}
function zonedParts(ms, tz) {
  const out = { year: 0, month: 0, day: 0, hour: 0, minute: 0, second: 0 };
  for (const p of partsFormatter(tz).formatToParts(new Date(ms))) {
    switch (p.type) {
      case "year":
        out.year = Number(p.value);
        break;
      case "month":
        out.month = Number(p.value);
        break;
      case "day":
        out.day = Number(p.value);
        break;
      case "hour":
        out.hour = Number(p.value) % 24;
        break;
      case "minute":
        out.minute = Number(p.value);
        break;
      case "second":
        out.second = Number(p.value);
        break;
      default:
        break;
    }
  }
  return out;
}
function tzOffsetMs(ms, tz) {
  const p = zonedParts(ms, tz);
  const wallAsUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  return wallAsUtc - Math.floor(ms / 1e3) * 1e3;
}
function zonedWallToUtc(year, month, day, hour, tz) {
  const wall = Date.UTC(year, month - 1, day, hour);
  let t = wall - tzOffsetMs(wall, tz);
  const second = wall - tzOffsetMs(t, tz);
  if (second !== t)
    t = second;
  const target = `${pad4(year)}-${pad2(month)}-${pad2(day)}`;
  for (let i = 0; i < 12; i++) {
    const p = zonedParts(t, tz);
    const key = `${pad4(p.year)}-${pad2(p.month)}-${pad2(p.day)}`;
    if (key > target || key === target && p.hour >= hour)
      break;
    t += 15 * MINUTE_MS;
    t = Math.floor(t / (15 * MINUTE_MS)) * 15 * MINUTE_MS;
  }
  return t;
}
function pad2(n) {
  return n < 10 ? `0${n}` : String(n);
}
function pad4(n) {
  return String(n).padStart(4, "0");
}
function localDayKey(ms, tz) {
  const p = zonedParts(ms, tz);
  return `${pad4(p.year)}-${pad2(p.month)}-${pad2(p.day)}`;
}
function localMonthKey(ms, tz) {
  return localDayKey(ms, tz).slice(0, 7);
}
function localMidnightMs(ms, tz) {
  const p = zonedParts(ms, tz);
  return zonedWallToUtc(p.year, p.month, p.day, 0, tz);
}
function localMonthStartMs(ms, tz) {
  const p = zonedParts(ms, tz);
  return zonedWallToUtc(p.year, p.month, 1, 0, tz);
}
function localNextMonthStartMs(ms, tz) {
  const p = zonedParts(ms, tz);
  const y = p.month === 12 ? p.year + 1 : p.year;
  const m = p.month === 12 ? 1 : p.month + 1;
  return zonedWallToUtc(y, m, 1, 0, tz);
}
function localDayStartMs(dayKey, tz) {
  const [y, m, d] = dayKey.split("-").map(Number);
  return zonedWallToUtc(y, m, d, 0, tz);
}
function daysInMonth(ms, tz) {
  const p = zonedParts(ms, tz);
  return new Date(Date.UTC(p.year, p.month, 0)).getUTCDate();
}
function minutesInMonth(ms, tz) {
  return Math.round((localNextMonthStartMs(ms, tz) - localMonthStartMs(ms, tz)) / MINUTE_MS);
}
function addDaysToKey(dayKey, n) {
  const [y, m, d] = dayKey.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}
function daysBetweenKeys(fromKey, toKey) {
  const [y1, m1, d1] = fromKey.split("-").map(Number);
  const [y2, m2, d2] = toKey.split("-").map(Number);
  return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / DAY_MS);
}
var displayFormatters = /* @__PURE__ */ new Map();
function displayFormatter(tz, kind) {
  const cacheKey = `${kind}|${tz}`;
  let f = displayFormatters.get(cacheKey);
  if (!f) {
    const base = { timeZone: tz };
    const opts = kind === "time" ? { ...base, hour: "numeric", minute: "2-digit", hour12: true } : kind === "datetime" ? { ...base, month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", hour12: true } : kind === "monthday" ? { ...base, month: "short", day: "numeric" } : { ...base, month: "short", day: "numeric", year: "numeric" };
    f = new Intl.DateTimeFormat("en-US", opts);
    displayFormatters.set(cacheKey, f);
  }
  return f;
}
function normalizeSpaces(s) {
  return s.replace(/[   ]/g, " ");
}
function formatLocalTime(ms, tz) {
  return normalizeSpaces(displayFormatter(tz, "time").format(new Date(ms)));
}
function isValidTimeZone(tz) {
  if (typeof tz !== "string" || tz.length === 0)
    return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

// core/settings.ts
var SETTINGS_SCHEMA_VERSION = 1;
var DEFAULT_QR_URL = "https://github.com/Cribl-Community/cc-meter-reader";
var DEFAULT_THRESHOLDS = {
  regressionPoints: 15,
  regressionMinutes: 3,
  regressionCommitWindowMin: 30,
  spikeSigma: 3,
  spikeMinutes: 2,
  spikeMinCentsPerHour: 500,
  budgetWarnPct: 90,
  budgetAlertPct: 100,
  goodNewsPoints: 15,
  cooldownMinutes: 60,
  ewmaAlpha: 14e-4,
  warmupSamples: 10,
  recoveryMinutes: 5,
  regressionMinCentsPerDay: 500
};
function defaultSettings(nowIso, tz, runtime = "ui") {
  return {
    schemaVersion: SETTINGS_SCHEMA_VERSION,
    updatedAt: nowIso,
    displayTimezone: isValidTimeZone(tz) ? tz : "UTC",
    headlinePeriodDefault: "mtd",
    presenter: { headlinePeriod: "annualized", qrUrl: DEFAULT_QR_URL },
    live: { pollSeconds: 10, presenterPollSeconds: 5 },
    budgets: {},
    thresholds: { ...DEFAULT_THRESHOLDS },
    goodNewsEnabled: false,
    excludedObjectKeys: [],
    includeInternal: false,
    notifications: [],
    humanize: {},
    demo: { enabled: false, replayMode: false, profile: true },
    runtime: runtime === "backend" ? "backend" : "ui"
  };
}
function goodNewsActive(settings) {
  return settings.goodNewsEnabled === true || settings.demo?.enabled === true && settings.demo?.profile === true;
}
var isNum = (v) => typeof v === "number" && Number.isFinite(v);
var isObj = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
var CRIBL_ID_PATTERN = /^[A-Za-z0-9_-]{1,512}$/;
var SECRET_TOKEN = /\bxox[abposr]-|\bxapp-|\bghp_|\bgho_|\bghs_|\bgithub_pat_|\bAKIA[0-9A-Z]{16}\b|-{5}BEGIN [A-Z ]*KEY|\bBearer\s+\S/;
var HOST_WITH_PATH = /(?:^|[^A-Za-z0-9.@-])(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}(?::\d+)?\/\S/;
var BARE_USERINFO = /(?:^|\s)[^\s:@/]+:[^\s@/]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}/;
var RANDOM_TOKEN = /^(?=[A-Za-z0-9]*[a-z])(?=[A-Za-z0-9]*[A-Z])(?=[A-Za-z0-9]*\d)[A-Za-z0-9]{20,}$/;
var UUID_TOKEN = /(?:^|[^0-9A-Za-z])[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?:$|[^0-9A-Za-z])/i;
var HEX_RUN = /(?:^|[^0-9A-Za-z])[0-9a-f]{24,}(?:$|[^0-9A-Za-z])/i;
var LOWER_ALNUM_RUN = /(?:^|[^0-9A-Za-z])(?=[a-z0-9]*\d)(?=[a-z0-9]*[a-z])[a-z0-9]{24,}(?:$|[^0-9A-Za-z])/;
var JWT_TOKEN = /(?:^|[^\w-])eyJ[\w-]+\.[\w-]+\./;
var KEY_PREFIX = /(?:^|[^\w.])SG\.[\w-]{6,}|(?:^|[^A-Za-z0-9])[sr]k_(?:live|test)_\w+|(?:^|[^A-Za-z0-9])[sr]k_[A-Za-z0-9]{16,}|(?:^|[^A-Za-z0-9])sk-[\w-]{16,}/;
var PASSWORD_WORD = /^(?=\S*[a-z])(?=\S*[A-Z])(?=\S*\d)(?=\S*[^\sA-Za-z0-9._-])\S{8,64}$/;
function looksLikeSecretToken(value) {
  if (typeof value !== "string")
    return false;
  const v = value.trim();
  if (v === "")
    return false;
  return UUID_TOKEN.test(v) || HEX_RUN.test(v) || LOWER_ALNUM_RUN.test(v) || JWT_TOKEN.test(v) || KEY_PREFIX.test(v) || PASSWORD_WORD.test(v);
}
function unstorableText(value) {
  return looksLikeCredentialText(value) || looksLikeSecretToken(value);
}
function looksLikeCredentialText(value) {
  if (typeof value !== "string")
    return false;
  const v = value.trim();
  if (v === "")
    return false;
  return v.includes("://") || urlHasCredentials(v) || HOST_WITH_PATH.test(v) || BARE_USERINFO.test(v) || SECRET_TOKEN.test(v) || RANDOM_TOKEN.test(v);
}
function isStorableTargetId(value) {
  return typeof value === "string" && CRIBL_ID_PATTERN.test(value) && !unstorableText(value);
}
var WEBHOOK_URL = [
  /^https?:\/\/hooks\.slack\.com\//i,
  /^https?:\/\/[^/?#]*\.webhook\.office\.com\//i,
  /^https?:\/\/outlook\.office(?:365)?\.com\/webhook/i,
  /^https?:\/\/(?:[^/?#]*\.)?discord(?:app)?\.com\/api\/webhooks\//i,
  /^https?:\/\/hooks\.zapier\.com\//i,
  /^https?:\/\/events\.pagerduty\.com\//i,
  /^https?:\/\/(?:[^/?#]*\.)?webhook\.site\//i,
  /^https?:\/\/maker\.ifttt\.com\/trigger\//i,
  /^https?:\/\/api\.telegram\.org\/bot/i
];
function isWebhookUrl(url) {
  if (typeof url !== "string")
    return false;
  const u = url.trim();
  return urlHasCredentials(u) || WEBHOOK_URL.some((re) => re.test(u));
}
function isStorableEndpoint(e) {
  return e?.channel === "cribl-bell" || e?.channel === "cribl-target";
}
function storableEndpoint(e) {
  if (!isObj(e) || typeof e.id !== "string" || e.id === "" || looksLikeCredentialText(e.id))
    return void 0;
  const ep = e;
  if (!isStorableEndpoint(ep))
    return void 0;
  if (ep.channel === "cribl-target" && !isStorableTargetId(ep.criblTargetId))
    return void 0;
  const out = normalizeEndpoint({ ...ep, url: "", host: "" });
  if (out.channel === "cribl-bell")
    delete out.criblTargetId;
  if (unstorableText(out.name))
    out.name = out.channel === "cribl-target" ? out.criblTargetId ?? "" : "";
  return out;
}
function storableLabels(map) {
  const out = {};
  if (!isObj(map))
    return out;
  for (const [k, v] of Object.entries(map))
    if (typeof v === "string" && !unstorableText(v) && !unstorableText(k))
      out[k] = v;
  return out;
}
function storableSettings(s) {
  if (!Array.isArray(s.notifications))
    return s;
  const notifications = s.notifications.map(storableEndpoint).filter((e) => e !== void 0);
  const out = { ...s, notifications };
  if (s.humanize !== void 0)
    out.humanize = storableLabels(s.humanize);
  if (s.presenter && isWebhookUrl(s.presenter.qrUrl))
    out.presenter = { ...s.presenter, qrUrl: DEFAULT_QR_URL };
  return out;
}
function urlHasCredentials(url) {
  return /^[a-z][a-z0-9+.-]*:\/\/[^/?#]*@/i.test((url ?? "").trim());
}
function hostFromUrl(url) {
  if (urlHasCredentials(url))
    return void 0;
  const m = /^https:\/\/(\[[^\]]+\]|[^/?#:]+)(?::\d+)?(?:[/?#]|$)/i.exec((url ?? "").trim());
  return m ? m[1].toLowerCase() : void 0;
}
var SEVERITIES = ["info", "medium", "high"];
var FORMATS = ["generic", "slack", "servicenow"];
var PERIODS = ["mtd", "today", "30d", "annualized"];
function pick(stored, fallback) {
  if (stored === void 0 || stored === null)
    return fallback;
  if (typeof fallback === "number")
    return isNum(stored) ? stored : fallback;
  return typeof stored === typeof fallback ? stored : fallback;
}
function pickPeriod(stored, fallback) {
  return PERIODS.includes(stored) ? stored : fallback;
}
function mergeSettings(stored, defaults) {
  const s = isObj(stored) ? stored : {};
  const presenter = isObj(s.presenter) ? s.presenter : {};
  const live = isObj(s.live) ? s.live : {};
  const thresholds = isObj(s.thresholds) ? s.thresholds : {};
  const demo = isObj(s.demo) ? s.demo : {};
  const mergedThresholds = { ...defaults.thresholds };
  for (const k of Object.keys(defaults.thresholds)) {
    mergedThresholds[k] = pick(thresholds[k], defaults.thresholds[k]);
  }
  const budgets = {};
  if (isObj(s.budgets)) {
    for (const [k, v] of Object.entries(s.budgets)) {
      if (isObj(v) && isNum(v.centsPerMonth))
        budgets[k] = { centsPerMonth: v.centsPerMonth };
    }
  }
  const humanizeMap = storableLabels(s.humanize);
  const storedQr = typeof presenter.qrUrl === "string" ? presenter.qrUrl : defaults.presenter.qrUrl;
  const qrUrl = isWebhookUrl(storedQr) ? DEFAULT_QR_URL : storedQr;
  const out = {
    schemaVersion: SETTINGS_SCHEMA_VERSION,
    updatedAt: pick(s.updatedAt, defaults.updatedAt),
    displayTimezone: typeof s.displayTimezone === "string" && isValidTimeZone(s.displayTimezone) ? s.displayTimezone : defaults.displayTimezone,
    headlinePeriodDefault: pickPeriod(s.headlinePeriodDefault, defaults.headlinePeriodDefault),
    presenter: { headlinePeriod: pickPeriod(presenter.headlinePeriod, defaults.presenter.headlinePeriod), ...qrUrl !== void 0 ? { qrUrl } : {} },
    live: {
      pollSeconds: pick(live.pollSeconds, defaults.live.pollSeconds),
      presenterPollSeconds: pick(live.presenterPollSeconds, defaults.live.presenterPollSeconds)
    },
    budgets: isObj(s.budgets) ? budgets : { ...defaults.budgets },
    thresholds: mergedThresholds,
    goodNewsEnabled: pick(s.goodNewsEnabled, defaults.goodNewsEnabled),
    excludedObjectKeys: Array.isArray(s.excludedObjectKeys) ? s.excludedObjectKeys.filter((k) => typeof k === "string") : [...defaults.excludedObjectKeys],
    includeInternal: pick(s.includeInternal, defaults.includeInternal),
    // D57: a stored direct webhook (written by a build before 1.0.14 / 1.1.0) is dropped on read, URL and all, as is
    // a target whose id is not shaped like a Cribl id (a URL typed as the target id before the rule 4.5 fix); the Cribl channels
    // keep no URL and no name is a URL: nothing a sweep or a tab reads can carry a webhook URL out of KV.
    notifications: (Array.isArray(s.notifications) ? s.notifications : defaults.notifications).map(storableEndpoint).filter((e) => e !== void 0),
    humanize: isObj(s.humanize) ? humanizeMap : { ...defaults.humanize },
    demo: {
      enabled: pick(demo.enabled, defaults.demo.enabled),
      replayMode: pick(demo.replayMode, defaults.demo.replayMode),
      profile: pick(demo.profile, defaults.demo.profile)
    },
    runtime: s.runtime === "backend" || s.runtime === "ui" ? s.runtime : defaults.runtime
  };
  const cost = isNum(s.criblCostCentsPerMonth) ? s.criblCostCentsPerMonth : defaults.criblCostCentsPerMonth;
  if (cost !== void 0)
    out.criblCostCentsPerMonth = cost;
  if (cost !== void 0 && cost > 0 && s.criblCostEstimate === true)
    out.criblCostEstimate = true;
  if (isObj(s.mutes)) {
    const mutes = {};
    for (const [k, v] of Object.entries(s.mutes)) {
      if (isObj(v) && typeof v.until === "string")
        mutes[k] = typeof v.by === "string" ? { until: v.until, by: v.by } : { until: v.until };
    }
    if (Object.keys(mutes).length > 0)
      out.mutes = mutes;
  }
  const keyboard = isObj(s.keyboard) ? s.keyboard : {};
  if (typeof keyboard.singleKeyShortcuts === "boolean")
    out.keyboard = { singleKeyShortcuts: keyboard.singleKeyShortcuts };
  else if (defaults.keyboard)
    out.keyboard = { ...defaults.keyboard };
  if (isNum(s.savingsGoalCentsPerMonth) && s.savingsGoalCentsPerMonth > 0)
    out.savingsGoalCentsPerMonth = s.savingsGoalCentsPerMonth;
  return out;
}
function normalizeEndpoint(e) {
  const out = {
    id: e.id,
    name: typeof e.name === "string" ? e.name : "",
    url: e.url,
    host: hostFromUrl(e.url) ?? (typeof e.host === "string" ? e.host : ""),
    format: FORMATS.includes(e.format) ? e.format : "generic",
    minSeverity: SEVERITIES.includes(e.minSeverity) ? e.minSeverity : "medium",
    weeklyReceipt: typeof e.weeklyReceipt === "boolean" ? e.weeklyReceipt : true,
    enabled: typeof e.enabled === "boolean" ? e.enabled : true
  };
  const lt = e.lastTest;
  if (isObj(lt) && typeof lt.at === "string" && isNum(lt.status))
    out.lastTest = { at: lt.at, status: lt.status, hostAuthorized: lt.hostAuthorized === true };
  if (e.channel === "webhook" || e.channel === "cribl-bell" || e.channel === "cribl-target")
    out.channel = e.channel;
  if (typeof e.criblTargetId === "string" && e.criblTargetId !== "")
    out.criblTargetId = e.criblTargetId;
  if (out.criblTargetId !== void 0 && typeof e.confirmedAt === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/.test(e.confirmedAt) && Number.isFinite(Date.parse(e.confirmedAt)) && e.confirmedTargetId === out.criblTargetId) {
    out.confirmedAt = e.confirmedAt;
    out.confirmedTargetId = e.confirmedTargetId;
  }
  return out;
}

// core/kv.ts
var KEYS = {
  settings: "settings",
  prices: "prices",
  snapshot: "snapshot",
  inventory: "inventory",
  baselines: "baselines",
  timeline: "timeline",
  notifyLog: "notify/log",
  lock: "lock/meter",
  demoState: "demo/state",
  tour: "tour/active",
  meta: "meta",
  totals: "totals"
};
var PREFIXES = {
  rollMin: "roll/min/",
  rollHour: "roll/hour/",
  rollDay: "roll/day/",
  incidents: "incidents/"
};
var CHUNK_THRESHOLD_BYTES = 9e4;
var CHUNK_CHARS = 9e4;
var MAX_CHUNKS = 256;
var KEY_RE = /^[A-Za-z0-9_.-]+(?:\/[A-Za-z0-9_.-]+)*$/;
var PREFIX_RE = /^(?:[A-Za-z0-9_.-]+\/?)*$/;
var CHUNK_KEY_RE = /\/c\/\d+$/;
function assertValidKey(key) {
  if (!KEY_RE.test(key))
    throw new Error(`invalid KV key "${key}": use '/'-separated segments of [A-Za-z0-9_.-]`);
}
function assertValidPrefix(prefix) {
  if (!PREFIX_RE.test(prefix))
    throw new Error(`invalid KV prefix "${prefix}"`);
}
function chunkKey(key, index) {
  return `${key}/c/${index}`;
}
function isChunkKey(key) {
  return CHUNK_KEY_RE.test(key);
}
var KvHttpError = class extends Error {
  constructor(op, key, status, detail2, retryAfterMs) {
    super(`KV ${op} ${key} failed: HTTP ${status}${detail2 ? ` ${detail2.slice(0, 200)}` : ""}`);
    this.name = "KvHttpError";
    this.op = op;
    this.key = key;
    this.status = status;
    this.retryAfterMs = retryAfterMs;
  }
};
function kvError(op, key, res) {
  return new KvHttpError(op, key, res.status, res.text, res.status === 429 ? retryAfterOf(res, Date.now()) : void 0);
}
var KvDocTooLarge = class extends Error {
  constructor(key, bytes, chunks, maxChunks) {
    super(`KV document ${key} is ${bytes} bytes \u2192 ${chunks} chunks (max ${maxChunks}); compact it before writing`);
    this.name = "KvDocTooLarge";
    this.key = key;
    this.bytes = bytes;
    this.chunks = chunks;
  }
};
function unwrapKvText(text) {
  const t = text.trim();
  if (!t.startsWith('"'))
    return text;
  try {
    const inner = JSON.parse(t);
    if (typeof inner === "string") {
      const s = inner.trim();
      if (s.startsWith("{") || s.startsWith("[") || s.startsWith('"'))
        return inner;
    }
  } catch {
  }
  return text;
}
function normalizeKeyList(body, prefix) {
  const obj = body !== null && typeof body === "object" ? body : void 0;
  const list = Array.isArray(body) ? body : obj?.items ?? obj?.keys ?? obj?.data;
  if (!Array.isArray(list))
    return [];
  const out = /* @__PURE__ */ new Set();
  for (const entry of list) {
    let name = entry;
    if (entry !== null && typeof entry === "object") {
      const e = entry;
      name = e.key ?? e.name ?? e.id;
    }
    if (typeof name !== "string")
      continue;
    const clean = name.replace(/^\/+/, "");
    if (clean.length > 0 && clean.startsWith(prefix))
      out.add(clean);
  }
  return [...out].sort();
}
function isProxyMissingKey(res) {
  return res.status === 0 && /ReadableStreamDefaultController/.test(res.text ?? "") && /not valid JSON/.test(res.text ?? "");
}
function createHttpKvStore(http) {
  return {
    async get(key) {
      const res = await http.request("GET", kvKey(key), void 0, { raw: true });
      if (res.status === 404 || isProxyMissingKey(res))
        return null;
      if (!res.ok)
        throw kvError("GET", key, res);
      return unwrapKvText(res.text ?? (res.json === void 0 ? "" : JSON.stringify(res.json)));
    },
    async put(key, value) {
      const res = await http.request("PUT", kvKey(key), value, { raw: true });
      if (!res.ok)
        throw kvError("PUT", key, res);
    },
    async del(key) {
      const res = await http.request("DELETE", kvKey(key), void 0, { raw: true });
      if (res.status === 404)
        return;
      if (!res.ok)
        throw kvError("DELETE", key, res);
    },
    async list(prefix) {
      const res = await http.request("POST", kvKeys(), { prefix });
      if (!res.ok)
        throw kvError("LIST", prefix, res);
      let body = res.json;
      if (body === void 0 && res.text) {
        try {
          body = JSON.parse(res.text);
        } catch {
          body = void 0;
        }
      }
      return normalizeKeyList(body, prefix);
    }
  };
}
function createFetchKvStore(options) {
  return createHttpKvStore(createFetchHttp(options));
}
function isChunkManifest(v) {
  if (!isObj2(v) || v.chunked !== true)
    return false;
  return (v.encoding === "gzip-base64" || v.encoding === "identity-base64") && Number.isInteger(v.chunks) && v.chunks >= 1 && typeof v.sha === "string" && typeof v.bytes === "number";
}
function isObj2(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
var isStr = (v) => typeof v === "string";
var isNum2 = (v) => typeof v === "number" && Number.isFinite(v);
var isArr = Array.isArray;
function allValues(v, pred) {
  return isObj2(v) && Object.values(v).every(pred);
}
var V1_MIGRATIONS = { 0: (doc) => ({ ...doc, schemaVersion: 1 }) };
function dropBadItems(list, ok, where, warn) {
  const kept = list.filter(ok);
  if (kept.length !== list.length)
    warn(`dropped ${list.length - kept.length} malformed entries from ${where}`);
  return kept;
}
var flowsOk = (v) => allValues(v, isArr);
var SPECS = {
  settings: {
    name: "settings",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.displayTimezone) && isObj2(d.thresholds) && isObj2(d.budgets) && isArr(d.notifications) && isArr(d.excludedObjectKeys) && isObj2(d.humanize) && isObj2(d.demo) && isObj2(d.live) && isObj2(d.presenter) && (d.runtime === void 0 || d.runtime === "backend" || d.runtime === "ui")
  },
  prices: {
    name: "prices",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isArr(d.versions) && d.versions.every((v) => isObj2(v) && isStr(v.effectiveFrom) && isObj2(v.byOutputId))
  },
  snapshot: {
    name: "snapshot",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.sweepAt) && isObj2(d.headline) && isArr(d.flows) && isArr(d.destinations)
  },
  inventory: {
    name: "inventory",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.hash) && allValues(d.byGroup, (g) => isObj2(g) && isArr(g.inputs) && isArr(g.outputs) && isArr(g.pipelines) && isArr(g.routes))
  },
  baselines: {
    name: "baselines",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isObj2(d.byObject) && isObj2(d.rules)
  },
  timeline: {
    name: "timeline",
    latest: 1,
    migrations: V1_MIGRATIONS,
    repair(d, warn) {
      if (!isObj2(d.byGroup))
        return;
      for (const [gid, list] of Object.entries(d.byGroup)) {
        if (isArr(list))
          d.byGroup[gid] = dropBadItems(list, (c) => isObj2(c) && isStr(c.hash), `timeline.byGroup.${gid}`, warn);
      }
    },
    guard: (d) => allValues(d.byGroup, isArr)
  },
  notifyLog: {
    name: "notify/log",
    latest: 1,
    migrations: V1_MIGRATIONS,
    repair(d, warn) {
      if (isArr(d.items))
        d.items = dropBadItems(d.items, (x) => isObj2(x) && isStr(x.endpointId), "notify/log.items", warn);
    },
    guard: (d) => isArr(d.items)
  },
  demoState: {
    name: "demo/state",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isObj2(d.routes) && isObj2(d.trim) && isObj2(d.rates) && isObj2(d.muted) && isNum2(d.measuredLagSec)
  },
  meta: {
    name: "meta",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.installedAt) && isStr(d.collectingSince) && isNum2(d.sweepErrors) && isNum2(d.sweepCount)
  },
  totals: {
    name: "totals",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isObj2(d.byDay)
  },
  rollMinute: {
    name: "roll/min",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.bucketStart) && flowsOk(d.flows)
  },
  rollHour: {
    name: "roll/hour",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.day) && flowsOk(d.flows)
  },
  rollDay: {
    name: "roll/day",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.month) && flowsOk(d.flows)
  },
  incidents: {
    name: "incidents",
    latest: 1,
    migrations: V1_MIGRATIONS,
    repair(d, warn) {
      if (isArr(d.items))
        d.items = dropBadItems(d.items, (x) => isObj2(x) && isStr(x.id), "incidents.items", warn);
    },
    guard: (d) => isArr(d.items)
  }
};
function upgradeDoc(spec, value, key, warn) {
  if (!isObj2(value)) {
    warn(`KV ${key}: ${spec.name} is not a JSON object; treating as missing`);
    return null;
  }
  let doc = value;
  let version2 = doc.schemaVersion === void 0 ? 0 : doc.schemaVersion;
  if (!Number.isInteger(version2) || version2 < 0) {
    warn(`KV ${key}: ${spec.name} has an invalid schemaVersion; treating as missing`, { schemaVersion: doc.schemaVersion });
    return null;
  }
  if (version2 > spec.latest) {
    warn(`KV ${key}: ${spec.name} schemaVersion ${String(version2)} is newer than this build (${spec.latest}); treating as missing`);
    return null;
  }
  while (version2 < spec.latest) {
    const step = spec.migrations?.[version2];
    if (!step) {
      warn(`KV ${key}: no migration for ${spec.name} from schemaVersion ${String(version2)}; treating as missing`);
      return null;
    }
    doc = step(doc);
    version2 = version2 + 1;
  }
  spec.repair?.(doc, (msg, data) => warn(`KV ${key}: ${msg}`, data));
  if (!spec.guard(doc)) {
    warn(`KV ${key}: ${spec.name} failed shape validation; treating as missing`);
    return null;
  }
  return doc;
}
var MAX_LOCK_HOLD_MS = 10 * 6e4;
function lockBinds(lock, now) {
  const expires = Date.parse(lock.expiresAt);
  return expires > now && expires - now <= MAX_LOCK_HOLD_MS;
}
var NOOP_LOGGER = { info: () => void 0, warn: () => void 0, error: () => void 0 };
var CORRUPT = Symbol("corrupt");
async function mapLimit(items2, limit, fn) {
  const out = new Array(items2.length);
  let next = 0;
  const workers = Array.from({ length: Math.max(1, Math.min(limit, items2.length)) }, async () => {
    while (next < items2.length) {
      const i = next++;
      out[i] = await fn(items2[i], i);
    }
  });
  await Promise.all(workers);
  return out;
}
function parseStored(raw) {
  if (raw.trim() === "[object Object]")
    return CORRUPT;
  let v;
  try {
    v = JSON.parse(raw);
  } catch {
    return CORRUPT;
  }
  if (typeof v === "string") {
    const inner = v.trim();
    if (inner.startsWith("{") || inner.startsWith("[")) {
      try {
        return JSON.parse(inner);
      } catch {
      }
    }
  }
  return v;
}
function chunkText(raw) {
  const t = raw.trim();
  if (t.startsWith('"')) {
    const v = JSON.parse(t);
    if (typeof v !== "string")
      throw new Error("chunk is not a string");
    return v;
  }
  return t;
}
function splitEvery(s, size) {
  const parts = [];
  for (let i = 0; i < s.length; i += size)
    parts.push(s.slice(i, i + size));
  return parts.length > 0 ? parts : [""];
}
function createKvDocs(deps) {
  const logger = deps.logger ?? NOOP_LOGGER;
  const threshold = deps.chunkThresholdBytes ?? CHUNK_THRESHOLD_BYTES;
  const chunkChars = deps.chunkChars ?? CHUNK_CHARS;
  const maxChunks = deps.maxChunks ?? MAX_CHUNKS;
  const concurrency = deps.concurrency ?? 4;
  const warn = (msg, data) => logger.warn(msg, data);
  let calls = 0;
  const store = {
    get(k) {
      calls++;
      return deps.kv.get(k);
    },
    put(k, v) {
      calls++;
      return deps.kv.put(k, v);
    },
    del(k) {
      calls++;
      return deps.kv.del(k);
    },
    list(p) {
      calls++;
      return deps.kv.list(p);
    }
  };
  const knownChunks = /* @__PURE__ */ new Map();
  function codecFor(encoding) {
    if (encoding === "identity-base64")
      return identityCodec;
    return deps.codec.encoding === "identity" ? null : deps.codec;
  }
  async function assemble(key, m) {
    const raws = await mapLimit(
      Array.from({ length: m.chunks }, (_, i) => i),
      concurrency,
      (i) => store.get(chunkKey(key, i))
    );
    const missing = raws.findIndex((r) => r === null);
    if (missing >= 0)
      return { reason: `chunk ${missing} of ${m.chunks} is missing` };
    const codec = codecFor(m.encoding);
    if (!codec)
      return { reason: `cannot decode ${m.encoding} with an identity codec` };
    let text;
    try {
      const b64 = raws.map(chunkText).join("");
      text = await codec.gunzip(fromBase64(b64));
    } catch (e) {
      return { reason: `chunks do not decode: ${e instanceof Error ? e.message : String(e)}` };
    }
    if (fnv1a(text) !== m.sha)
      return { reason: "hash mismatch" };
    return { text };
  }
  async function readChunked(key, m, allowRetry) {
    if (!isChunkManifest(m) || m.chunks > maxChunks) {
      warn(`KV ${key}: malformed chunk manifest; treating as missing`, m);
      return CORRUPT;
    }
    knownChunks.set(key, m.chunks);
    const got = await assemble(key, m);
    if ("text" in got) {
      const parsed = parseStored(got.text);
      if (parsed === CORRUPT)
        warn(`KV ${key}: reassembled document is not valid JSON; treating as missing`);
      return parsed;
    }
    if (allowRetry) {
      const again = await store.get(key);
      if (again === null)
        return null;
      const next = parseStored(again);
      if (isObj2(next) && next.chunked === true) {
        if (isChunkManifest(next) && next.sha !== m.sha)
          return readChunked(key, next, false);
      } else if (next !== CORRUPT) {
        knownChunks.set(key, 0);
        return next;
      }
    }
    warn(`KV ${key}: chunked document failed verification (${got.reason}); treating as missing`);
    return CORRUPT;
  }
  async function load(key) {
    const raw = await store.get(key);
    if (raw === null)
      return null;
    const parsed = parseStored(raw);
    if (parsed === CORRUPT) {
      warn(`KV ${key}: stored value is not valid JSON; treating as missing`);
      return CORRUPT;
    }
    if (isObj2(parsed) && parsed.chunked === true)
      return readChunked(key, parsed, true);
    knownChunks.set(key, 0);
    return parsed;
  }
  async function deleteChunkIndexes(key, indexes) {
    if (indexes.length === 0)
      return;
    try {
      await mapLimit(indexes, concurrency, (i) => store.del(chunkKey(key, i)));
    } catch (e) {
      warn(`KV ${key}: could not delete stale chunks (${indexes.join(",")}); they are unreferenced`, e);
    }
  }
  function range(from, to) {
    return Array.from({ length: Math.max(0, to - from) }, (_, i) => from + i);
  }
  async function save(key, doc) {
    const json2 = JSON.stringify(doc);
    if (json2 === void 0)
      throw new TypeError(`KV ${key}: refusing to write a non-JSON value`);
    const bytes = utf8ByteLength(json2);
    if (bytes <= threshold) {
      await store.put(key, json2);
      knownChunks.set(key, 0);
      return;
    }
    const encoding = deps.codec.encoding === "identity" ? "identity-base64" : "gzip-base64";
    const parts = splitEvery(toBase64(await deps.codec.gzip(json2)), chunkChars);
    if (parts.length > maxChunks)
      throw new KvDocTooLarge(key, bytes, parts.length, maxChunks);
    await mapLimit(parts, concurrency, (p, i) => store.put(chunkKey(key, i), JSON.stringify(p)));
    const manifest = {
      schemaVersion: 1,
      chunked: true,
      encoding,
      chunks: parts.length,
      bytes,
      sha: fnv1a(json2),
      updatedAt: new Date(deps.clock.now()).toISOString()
    };
    await store.put(key, JSON.stringify(manifest));
    knownChunks.set(key, parts.length);
  }
  async function getTyped(key, spec) {
    assertValidKey(key);
    const loaded = await load(key);
    if (loaded === null || loaded === CORRUPT)
      return null;
    return upgradeDoc(spec, loaded, key, warn);
  }
  async function putTyped(key, spec, doc) {
    assertValidKey(key);
    if (!isObj2(doc) || doc.schemaVersion !== spec.latest || !spec.guard(doc)) {
      throw new TypeError(`KV ${key}: refusing to write an invalid ${spec.name} document`);
    }
    await save(key, doc);
  }
  function familyKey(prefix, key) {
    return key.startsWith(prefix) ? key : prefix + key.replace(/^\/+/, "");
  }
  function parseLock(v) {
    if (v === null || v === CORRUPT)
      return null;
    if (isObj2(v) && isStr(v.owner) && isStr(v.expiresAt) && Number.isFinite(Date.parse(v.expiresAt))) {
      return { owner: v.owner, expiresAt: v.expiresAt };
    }
    warn(`KV ${KEYS.lock}: malformed lock; treating as free`, v);
    return null;
  }
  const readLock = async () => parseLock(await load(KEYS.lock));
  const writeLock = (lock) => save(KEYS.lock, lock);
  return {
    getSettings: () => getTyped(KEYS.settings, SPECS.settings),
    // D57: whatever the caller built, the stored document holds no webhook URL (rule 4.5; core/settings.ts).
    putSettings: (doc) => putTyped(KEYS.settings, SPECS.settings, storableSettings(doc)),
    getPrices: () => getTyped(KEYS.prices, SPECS.prices),
    putPrices: (doc) => putTyped(KEYS.prices, SPECS.prices, doc),
    getSnapshot: () => getTyped(KEYS.snapshot, SPECS.snapshot),
    putSnapshot: (doc) => putTyped(KEYS.snapshot, SPECS.snapshot, doc),
    getInventory: () => getTyped(KEYS.inventory, SPECS.inventory),
    putInventory: (doc) => putTyped(KEYS.inventory, SPECS.inventory, doc),
    getBaselines: () => getTyped(KEYS.baselines, SPECS.baselines),
    putBaselines: (doc) => putTyped(KEYS.baselines, SPECS.baselines, doc),
    getTimeline: () => getTyped(KEYS.timeline, SPECS.timeline),
    putTimeline: (doc) => putTyped(KEYS.timeline, SPECS.timeline, doc),
    getNotifyLog: () => getTyped(KEYS.notifyLog, SPECS.notifyLog),
    putNotifyLog: (doc) => putTyped(KEYS.notifyLog, SPECS.notifyLog, doc),
    getDemoState: () => getTyped(KEYS.demoState, SPECS.demoState),
    putDemoState: (doc) => putTyped(KEYS.demoState, SPECS.demoState, doc),
    getMeta: () => getTyped(KEYS.meta, SPECS.meta),
    putMeta: (doc) => putTyped(KEYS.meta, SPECS.meta, doc),
    getTotals: () => getTyped(KEYS.totals, SPECS.totals),
    putTotals: (doc) => putTyped(KEYS.totals, SPECS.totals, doc),
    getRollMinute: (key) => getTyped(familyKey(PREFIXES.rollMin, key), SPECS.rollMinute),
    putRollMinute: (key, doc) => putTyped(familyKey(PREFIXES.rollMin, key), SPECS.rollMinute, doc),
    getRollHour: (key) => getTyped(familyKey(PREFIXES.rollHour, key), SPECS.rollHour),
    putRollHour: (key, doc) => putTyped(familyKey(PREFIXES.rollHour, key), SPECS.rollHour, doc),
    getRollDay: (key) => getTyped(familyKey(PREFIXES.rollDay, key), SPECS.rollDay),
    putRollDay: (key, doc) => putTyped(familyKey(PREFIXES.rollDay, key), SPECS.rollDay, doc),
    getIncidents: (key) => getTyped(familyKey(PREFIXES.incidents, key), SPECS.incidents),
    putIncidents: (key, doc) => putTyped(familyKey(PREFIXES.incidents, key), SPECS.incidents, doc),
    async listKeys(prefix) {
      assertValidPrefix(prefix);
      const names = await store.list(prefix);
      return [...new Set(names.map((k) => k.replace(/^\/+/, "")))].filter((k) => k.startsWith(prefix) && !isChunkKey(k)).sort();
    },
    async listKeysWithChunks(prefix) {
      assertValidPrefix(prefix);
      const names = [...new Set((await store.list(prefix)).map((k) => k.replace(/^\/+/, "")))].filter((k) => k.startsWith(prefix));
      const chunks = {};
      const keys = [];
      for (const k of names) {
        if (!isChunkKey(k)) {
          keys.push(k);
          continue;
        }
        const at = k.lastIndexOf("/c/");
        const index = Number(k.slice(at + 3));
        if (Number.isInteger(index) && index >= 0)
          (chunks[k.slice(0, at)] ??= []).push(index);
      }
      for (const list of Object.values(chunks))
        list.sort((a, b) => a - b);
      return { keys: keys.sort(), chunks };
    },
    async del(key, opts) {
      assertValidKey(key);
      if (opts?.listed) {
        await store.del(key);
        await deleteChunkIndexes(key, [...opts.listed]);
        knownChunks.delete(key);
        return;
      }
      let chunks = knownChunks.get(key) ?? 0;
      const raw = await store.get(key);
      if (raw !== null) {
        const parsed = parseStored(raw);
        if (isChunkManifest(parsed))
          chunks = Math.max(chunks, Math.min(parsed.chunks, maxChunks));
        await store.del(key);
      }
      await deleteChunkIndexes(key, range(0, chunks));
      knownChunks.delete(key);
    },
    async acquireLock(owner, ttlMs, opts = {}) {
      if (!owner)
        throw new Error("acquireLock needs a non-empty owner");
      const now = deps.clock.now();
      const current = await readLock();
      if (current && current.owner !== owner && lockBinds(current, now))
        return false;
      await writeLock({ owner, expiresAt: new Date(now + Math.max(0, ttlMs)).toISOString() });
      if (opts.verify === false)
        return true;
      const back = await readLock();
      return back !== null && back.owner === owner;
    },
    async releaseLock(owner) {
      const current = await readLock();
      if (!current || current.owner !== owner)
        return false;
      await writeLock({ owner, expiresAt: new Date(deps.clock.now()).toISOString() });
      return true;
    },
    async renewLock(owner, ttlMs) {
      if (!owner)
        throw new Error("renewLock needs a non-empty owner");
      const now = deps.clock.now();
      const current = await readLock();
      if (!current || current.owner !== owner)
        return false;
      await writeLock({ owner, expiresAt: new Date(now + Math.max(0, ttlMs)).toISOString() });
      if (Date.parse(current.expiresAt) > now)
        return true;
      const back = await readLock();
      return back !== null && back.owner === owner;
    },
    getLock: readLock,
    async getDoc(key, guard) {
      assertValidKey(key);
      const loaded = await load(key);
      if (loaded === null || loaded === CORRUPT)
        return null;
      if (!guard(loaded)) {
        warn(`KV ${key}: document failed its guard; treating as missing`);
        return null;
      }
      return loaded;
    },
    async putDoc(key, doc) {
      assertValidKey(key);
      await save(key, doc);
    },
    calls: () => calls,
    resetCalls() {
      calls = 0;
    }
  };
}

// core/flows.ts
var INTERNAL_TYPES = ["cribl", "cribl_metrics", "criblmetrics", "cribl_internal", "system_metrics", "system_state"];
var DEMO_TAG = "[meter-reader-demo]";
var seg2 = (s) => s === void 0 || s === null || s === "" ? "-" : s;
function makeFlowKey(groupId, inputId, routeId, pipelineId, outputId) {
  return [seg2(groupId), seg2(inputId), seg2(routeId), seg2(pipelineId), seg2(outputId)].join("|");
}
function parseFlowKey(key) {
  const p = typeof key === "string" ? key.split("|") : [];
  if (p.length !== 5)
    return null;
  return { groupId: p[0], inputId: p[1], routeId: p[2], pipelineId: p[3], outputId: p[4] };
}
function objectKey(kind, groupId, id) {
  return `${kind}:${groupId}:${id}`;
}
var KINDS = ["in", "route", "pipe", "out"];
function parseObjectKey(key) {
  const m = typeof key === "string" ? /^([a-z]+):([^:]*):(.+)$/.exec(key) : null;
  if (!m || !KINDS.includes(m[1]))
    return null;
  return { kind: m[1], groupId: m[2], id: m[3] };
}
function flowObjectKeys(flow) {
  const g = flow.groupId;
  return {
    input: flow.inputId !== "-" ? objectKey("in", g, flow.inputId) : void 0,
    route: flow.routeId !== "-" ? objectKey("route", g, flow.routeId) : void 0,
    pipeline: flow.pipelineId !== "-" ? objectKey("pipe", g, flow.pipelineId) : void 0,
    output: flow.outputId !== "-" ? objectKey("out", g, flow.outputId) : void 0
  };
}
var Q = `(['"\`])((?:(?!\\1)[^\\\\]|\\\\.)*)\\1`;
var RE_EQ = new RegExp(`__inputId\\s*===?\\s*${Q}`, "g");
var RE_EQ_REV = new RegExp(`${Q}\\s*===?\\s*__inputId\\b`, "g");
var RE_STARTS = new RegExp(`__inputId\\s*\\.\\s*startsWith\\(\\s*${Q}\\s*\\)`, "g");
var RE_INCLUDES = /\[([^\]]*)\]\s*\.\s*includes\(\s*__inputId\s*\)/g;
var RE_IN = /__inputId\s+in\s+\[([^\]]*)\]/g;
var RE_LIST_ITEM = new RegExp(Q, "g");
function parseStringList(body) {
  const items2 = [];
  const rest = body.replace(RE_LIST_ITEM, (_m, _q, v) => {
    items2.push(v);
    return "";
  });
  return /^[\s,]*$/.test(rest) ? items2 : void 0;
}
function stripOuterParens(s) {
  let out = s.trim();
  for (; ; ) {
    if (!out.startsWith("(") || !out.endsWith(")"))
      return out;
    let depth = 0;
    for (let i = 0; i < out.length; i++) {
      if (out[i] === "(")
        depth++;
      else if (out[i] === ")")
        depth--;
      if (depth === 0 && i < out.length - 1)
        return out;
    }
    out = out.slice(1, -1).trim();
  }
}
function parseRouteFilter(filter) {
  const f = stripOuterParens(filter ?? "");
  if (f === "" || f === "true")
    return { kind: "all" };
  const refs = [];
  let bad = false;
  let rest = f.replace(RE_STARTS, (_m, _q, v) => {
    refs.push({ value: v, prefix: true });
    return " X ";
  }).replace(RE_EQ, (_m, _q, v) => {
    refs.push({ value: v, prefix: false });
    return " X ";
  }).replace(RE_EQ_REV, (_m, _q, v) => {
    refs.push({ value: v, prefix: false });
    return " X ";
  }).replace(RE_INCLUDES, (_m, body) => {
    const items2 = parseStringList(body);
    if (!items2)
      bad = true;
    for (const v of items2 ?? [])
      refs.push({ value: v, prefix: false });
    return " X ";
  }).replace(RE_IN, (_m, body) => {
    const items2 = parseStringList(body);
    if (!items2)
      bad = true;
    for (const v of items2 ?? [])
      refs.push({ value: v, prefix: false });
    return " X ";
  });
  if (bad || refs.length === 0)
    return { kind: "unknown" };
  rest = rest.replace(/\s+/g, "");
  if (rest.includes("__inputId"))
    return { kind: "unknown" };
  for (let prev = ""; prev !== rest; ) {
    prev = rest;
    rest = rest.replace(/\((?:X\|\|)*X\)/g, "X");
  }
  if (/^X(\|\|X)*$/.test(rest))
    return { kind: "inputs", refs, exact: true };
  if (rest.includes("||") || /!\(|!X/.test(rest))
    return { kind: "unknown" };
  return { kind: "inputs", refs, exact: false };
}
function splitInputValue(value) {
  const i = value.indexOf(":");
  return i > 0 ? { type: value.slice(0, i), id: value.slice(i + 1) } : { id: value };
}
function isDemoTagged(obj) {
  return obj.id.startsWith("mrd_") || (obj.description ?? "").includes(DEMO_TAG);
}
function isInternalInput(input) {
  const t = (input.type ?? "").toLowerCase();
  if (INTERNAL_TYPES.includes(t))
    return true;
  return t === "datagen" && !isDemoTagged(input);
}
function isInternalOutput(output) {
  return INTERNAL_TYPES.includes((output.type ?? "").toLowerCase());
}
function resolveRouteOutput(route, group2) {
  let id = route.output || group2.pipelines?.find((p) => p.id === route.pipeline)?.output || "default";
  for (let hops = 0; hops < 3; hops++) {
    const out = group2.outputs?.find((o) => o.id === id);
    const isDefault = out ? out.type === "default" : id === "default";
    if (!isDefault || !out?.defaultId || out.defaultId === id)
      break;
    id = out.defaultId;
  }
  return id;
}
function resolveRefs(refs, inputs2) {
  const out = /* @__PURE__ */ new Map();
  for (const ref of refs) {
    if (ref.prefix) {
      for (const inp of inputs2) {
        const full = `${inp.type}:${inp.id}`;
        if (full.startsWith(ref.value) || !ref.value.includes(":") && inp.id.startsWith(ref.value))
          out.set(inp.id, inp);
      }
      continue;
    }
    const { type, id } = splitInputValue(ref.value);
    const found = inputs2.find((inp) => type !== void 0 ? inp.type === type && inp.id === id : inp.id === id);
    out.set(found?.id ?? id, found ?? { id, type: type ?? "unknown" });
  }
  return [...out.values()];
}
function buildFlows(inventory, settings) {
  const flows = /* @__PURE__ */ new Map();
  const excluded = new Set(settings.excludedObjectKeys ?? []);
  const includeInternal = settings.includeInternal === true;
  for (const [gid, group2] of Object.entries(inventory?.byGroup ?? {})) {
    const inputs2 = group2.inputs ?? [];
    const outputsById = new Map((group2.outputs ?? []).map((o) => [o.id, o]));
    const eligibleInput = (inp) => !inp.disabled && (includeInternal || !isInternalInput(inp));
    const routable = inputs2.filter((inp) => inp.sendToRoutes !== false);
    const emit = (inputId, routeId, pipelineId, outputId, attribution) => {
      const out = outputsById.get(outputId);
      if (out?.disabled)
        return;
      if (out && !includeInternal && isInternalOutput(out))
        return;
      const f = {
        key: makeFlowKey(gid, inputId, routeId, pipelineId, outputId),
        groupId: gid,
        inputId: seg2(inputId),
        routeId: seg2(routeId),
        pipelineId: seg2(pipelineId),
        outputId: seg2(outputId),
        attribution
      };
      const keys = flowObjectKeys(f);
      if ([keys.input, keys.route, keys.pipeline, keys.output].some((k) => k !== void 0 && excluded.has(k)))
        return;
      if (!flows.has(f.key))
        flows.set(f.key, f);
    };
    const fullyClaimed = /* @__PURE__ */ new Set();
    for (const route of group2.routes ?? []) {
      if (route.disabled)
        continue;
      const isFinal = route.final !== false;
      const match = parseRouteFilter(route.filter);
      const outputId = resolveRouteOutput(route, group2);
      const pipelineId = route.pipeline || "-";
      if (match.kind === "unknown") {
        emit("-", route.id, pipelineId, outputId, "route-only");
        continue;
      }
      const selected = match.kind === "all" ? routable : resolveRefs(match.refs, routable).filter((i) => i.sendToRoutes !== false);
      for (const inp of selected) {
        if (fullyClaimed.has(inp.id) || !eligibleInput(inp))
          continue;
        emit(inp.id, route.id, pipelineId, outputId, "route");
      }
      if (isFinal && match.kind === "all")
        break;
      if (isFinal && match.kind === "inputs" && match.exact)
        for (const inp of selected)
          fullyClaimed.add(inp.id);
    }
    for (const inp of inputs2) {
      if (inp.sendToRoutes !== false || !eligibleInput(inp))
        continue;
      for (const c of inp.connections ?? [])
        emit(inp.id, "-", c.pipeline ?? "-", c.output, "proportional");
    }
  }
  return [...flows.values()];
}
function apportion(total, weights) {
  const n = weights.length;
  if (n === 0)
    return [];
  const T = Number.isFinite(total) && total > 0 ? Math.round(total) : 0;
  const w = weights.map((x) => Number.isFinite(x) && x > 0 ? x : 0);
  let W = w.reduce((a, b) => a + b, 0);
  if (W <= 0) {
    w.fill(1);
    W = n;
  }
  const raw = w.map((x) => T * x / W);
  const out = raw.map((x) => Math.floor(x));
  let deficit = T - out.reduce((a, b) => a + b, 0);
  const order = raw.map((x, i) => ({ i, frac: x - Math.floor(x) })).sort((a, b) => b.frac - a.frac || a.i - b.i);
  for (let k = 0; deficit > 0 && k < order.length; k++, deficit--)
    out[order[k].i] += 1;
  return out;
}
function normalizeKeys(rec) {
  const out = /* @__PURE__ */ new Map();
  for (const [k, v] of Object.entries(rec ?? {})) {
    const first = k.indexOf(":");
    if (first < 0)
      continue;
    const gid = k.slice(0, first);
    const rest = k.slice(first + 1);
    const second = rest.indexOf(":");
    const norm2 = second > 0 ? `${gid}:${rest.slice(second + 1)}` : k;
    const prev = out.get(norm2);
    out.set(norm2, prev ? { bytes: prev.bytes + v.bytes, events: prev.events + v.events } : { bytes: v.bytes, events: v.events });
  }
  return out;
}
var ZERO = { bytes: 0, events: 0 };
var INPUT_RECONCILE_TOLERANCE = 0.1;
var DEST_EVENT_TOLERANCE = 0.01;
var PIN_MIN_OUT_SHARE = 0.95;
function stillReduced(w) {
  if (!w || w.attribution !== "route" && w.attribution !== "pipeline")
    return false;
  return w.inB > 0 && w.outB < w.inB * PIN_MIN_OUT_SHARE;
}
function attributeWindow(flows, metrics, options = {}) {
  const estimated = attributeEstimates(flows, metrics);
  if (options.reconcile === false)
    return estimated;
  return reconcileWindow(flows, metrics, estimated, options.passthroughPipelines ?? /* @__PURE__ */ new Set());
}
function reconcileWindow(flows, metrics, estimated, passthrough) {
  const inputs2 = normalizeKeys(metrics.inputs);
  const outputs2 = normalizeKeys(metrics.outputs);
  const out = {};
  for (const [k, w] of Object.entries(estimated))
    out[k] = { ...w };
  const bySource = /* @__PURE__ */ new Map();
  for (const f of flows) {
    if (f.inputId === "-" || !out[f.key])
      continue;
    const k = `${f.groupId}:${f.inputId}`;
    (bySource.get(k) ?? bySource.set(k, []).get(k)).push(f);
  }
  for (const [k, group2] of bySource) {
    const measured = inputs2.get(k);
    if (!measured || measured.bytes <= 0)
      continue;
    const routed = group2.reduce((a, f) => a + out[f.key].inB, 0);
    if (routed <= 0)
      continue;
    if (Math.abs(routed - measured.bytes) > measured.bytes * INPUT_RECONCILE_TOLERANCE)
      continue;
    const inB = apportion(measured.bytes, group2.map((f) => out[f.key].inB));
    const inE = apportion(measured.events, group2.map((f) => out[f.key].inE || out[f.key].inB));
    group2.forEach((f, i) => {
      out[f.key].inB = inB[i];
      out[f.key].inE = inE[i];
    });
  }
  const byDest = /* @__PURE__ */ new Map();
  for (const f of flows) {
    if (!out[f.key])
      continue;
    const k = `${f.groupId}:${f.outputId}`;
    (byDest.get(k) ?? byDest.set(k, []).get(k)).push(f);
  }
  for (const [k, group2] of byDest) {
    const measured = outputs2.get(k);
    if (!measured)
      continue;
    const isPinned = (f) => passthrough.has(`${f.groupId}:${f.pipelineId}`) && !stillReduced(estimated[f.key]);
    const pinned = group2.filter(isPinned);
    const rest = group2.filter((f) => !isPinned(f));
    const estTotal = group2.reduce((a, f) => a + (isPinned(f) ? out[f.key].inB : out[f.key].outB), 0);
    const estEvents = group2.reduce((a, f) => a + (isPinned(f) ? out[f.key].inE : out[f.key].outE), 0);
    const eventsKnown = measured.events > 0 && estEvents > 0;
    const slack = Math.max(1, measured.events * DEST_EVENT_TOLERANCE);
    const sameEvents = eventsKnown && Math.abs(measured.events - estEvents) <= slack;
    const extraEvents = eventsKnown && measured.events - estEvents > slack;
    const inByteBand = estTotal > 0 && measured.bytes <= estTotal * 2 && measured.bytes >= estTotal * 0.5;
    if (!sameEvents && (extraEvents || !inByteBand))
      continue;
    let pinnedBytes = 0;
    for (const f of pinned) {
      out[f.key].outB = out[f.key].inB;
      out[f.key].outE = out[f.key].inE;
      out[f.key].attribution = "reconciled";
      pinnedBytes += out[f.key].inB;
    }
    let remaining = measured.bytes - pinnedBytes;
    if (remaining < 0) {
      const scaled = apportion(measured.bytes, pinned.map((f) => out[f.key].outB));
      pinned.forEach((f, i) => out[f.key].outB = scaled[i]);
      remaining = 0;
    }
    if (rest.length === 0)
      continue;
    const weights = rest.map((f) => out[f.key].outB > 0 ? out[f.key].outB : out[f.key].inB);
    const outB = apportion(remaining, weights);
    const pinnedEvents = pinned.reduce((a, f) => a + out[f.key].outE, 0);
    const outE = apportion(Math.max(0, measured.events - pinnedEvents), rest.map((f) => out[f.key].outE || 1));
    rest.forEach((f, i) => {
      out[f.key].outB = outB[i];
      out[f.key].outE = outE[i];
      out[f.key].attribution = "reconciled";
    });
  }
  return out;
}
function attributeEstimates(flows, metrics) {
  const inputs2 = normalizeKeys(metrics.inputs);
  const outputs2 = normalizeKeys(metrics.outputs);
  const routesIn = metrics.routesIn ?? {};
  const routesOut = metrics.routesOut ?? {};
  const pipesIn = metrics.pipelinesIn ?? {};
  const pipesOut = metrics.pipelinesOut ?? {};
  const routeMode = metrics.has?.routeBytes === true;
  const pipeMode = !routeMode && metrics.has?.pipelineBytes === true;
  const result = {};
  const shared = /* @__PURE__ */ new Map();
  const proportional = [];
  for (const f of flows) {
    if (routeMode && f.routeId !== "-") {
      const k = `r|${f.groupId}:${f.routeId}`;
      (shared.get(k) ?? shared.set(k, []).get(k)).push(f);
    } else if (pipeMode && f.pipelineId !== "-" && f.routeId !== "-") {
      const k = `p|${f.groupId}:${f.pipelineId}`;
      (shared.get(k) ?? shared.set(k, []).get(k)).push(f);
    } else {
      proportional.push(f);
    }
  }
  for (const [k, group2] of shared) {
    const isRoute = k.startsWith("r|");
    const key = k.slice(2);
    const sIn = (isRoute ? routesIn[key] : pipesIn[key]) ?? ZERO;
    const sOut = (isRoute ? routesOut[key] : pipesOut[key]) ?? ZERO;
    const weights = group2.map((f) => f.inputId === "-" ? 0 : inputs2.get(`${f.groupId}:${f.inputId}`)?.bytes ?? 0);
    const inB = apportion(sIn.bytes, weights);
    const outB = apportion(sOut.bytes, weights);
    const inE = apportion(sIn.events, weights);
    const outE = apportion(sOut.events, weights);
    group2.forEach((f, i) => {
      let w = {
        inB: inB[i],
        outB: outB[i],
        inE: inE[i],
        outE: outE[i],
        attribution: f.inputId === "-" ? "route-only" : isRoute ? "route" : "pipeline"
      };
      const input = f.inputId === "-" ? void 0 : inputs2.get(`${f.groupId}:${f.inputId}`);
      if (input && w.inB > input.bytes) {
        const factor = w.inB > 0 ? input.bytes / w.inB : 0;
        w = {
          ...w,
          inB: input.bytes,
          outB: Math.round(w.outB * factor),
          inE: Math.round(w.inE * factor),
          outE: Math.round(w.outE * factor)
        };
      }
      result[f.key] = w;
    });
  }
  const usedIn = /* @__PURE__ */ new Map();
  const usedOut = /* @__PURE__ */ new Map();
  for (const f of flows) {
    const w = result[f.key];
    if (!w)
      continue;
    const ik = `${f.groupId}:${f.inputId}`;
    const ok = `${f.groupId}:${f.outputId}`;
    const ui = usedIn.get(ik) ?? { bytes: 0, events: 0 };
    usedIn.set(ik, { bytes: ui.bytes + w.inB, events: ui.events + w.inE });
    const uo = usedOut.get(ok) ?? { bytes: 0, events: 0 };
    usedOut.set(ok, { bytes: uo.bytes + w.outB, events: uo.events + w.outE });
  }
  const remaining = (m, used, k) => {
    const total = m.get(k) ?? ZERO;
    const u = used.get(k) ?? ZERO;
    return { bytes: Math.max(0, total.bytes - u.bytes), events: Math.max(0, total.events - u.events) };
  };
  const byInput = /* @__PURE__ */ new Map();
  for (const f of proportional) {
    result[f.key] = { inB: 0, outB: 0, inE: 0, outE: 0, attribution: "proportional" };
    if (f.inputId === "-")
      continue;
    const k = `${f.groupId}:${f.inputId}`;
    (byInput.get(k) ?? byInput.set(k, []).get(k)).push(f);
  }
  for (const [k, group2] of byInput) {
    const left = remaining(inputs2, usedIn, k);
    const even = group2.map(() => 1);
    const b = apportion(left.bytes, even);
    const e = apportion(left.events, even);
    group2.forEach((f, i) => {
      result[f.key].inB = b[i];
      result[f.key].inE = e[i];
    });
  }
  const byOutput = /* @__PURE__ */ new Map();
  for (const f of proportional) {
    const k = `${f.groupId}:${f.outputId}`;
    (byOutput.get(k) ?? byOutput.set(k, []).get(k)).push(f);
  }
  for (const [k, group2] of byOutput) {
    const left = remaining(outputs2, usedOut, k);
    const weights = group2.map((f) => result[f.key].inB);
    const b = apportion(left.bytes, weights);
    const e = apportion(left.events, weights);
    group2.forEach((f, i) => {
      result[f.key].outB = b[i];
      result[f.key].outE = e[i];
    });
  }
  return result;
}
function passthroughPipelines(inventory) {
  const set = /* @__PURE__ */ new Set();
  for (const [gid, g] of Object.entries(inventory?.byGroup ?? {})) {
    for (const p of g.pipelines ?? []) {
      if (p.packId || p.id.startsWith("pack:"))
        continue;
      if ((p.functions ?? []).every((fn) => fn.disabled === true))
        set.add(`${gid}:${p.id}`);
    }
  }
  return set;
}

// core/presets.ts
var PRESETS = [
  { id: "splunk_cloud", label: "Splunk Cloud", matchTypes: ["splunk_hec"], milliCentsPerGb: 225e3, billing: "entitlement", monogram: "SC" },
  { id: "splunk_enterprise", label: "Splunk Enterprise", matchTypes: ["splunk", "splunk_lb"], milliCentsPerGb: 2e5, billing: "entitlement", monogram: "SE" },
  { id: "sentinel", label: "Microsoft Sentinel", matchTypes: ["sentinel", "azure_logs"], milliCentsPerGb: 25e4, billing: "entitlement", monogram: "MS" },
  {
    id: "crowdstrike_ngsiem",
    label: "CrowdStrike Falcon Next-Gen SIEM / LogScale",
    matchTypes: ["humio", "humio_hec", "crowdstrike_ngsiem", "crowdstrike_next_gen_siem"],
    milliCentsPerGb: 2e5,
    billing: "entitlement",
    monogram: "CS"
  },
  { id: "datadog", label: "Datadog Logs", matchTypes: ["datadog"], milliCentsPerGb: 18e4, billing: "metered", monogram: "DD" },
  { id: "elastic", label: "Elastic Cloud", matchTypes: ["elastic", "elastic_cloud"], milliCentsPerGb: 35e3, billing: "metered", monogram: "EC" },
  { id: "google_secops", label: "Google SecOps", matchTypes: ["google_chronicle", "chronicle"], milliCentsPerGb: 15e4, billing: "entitlement", monogram: "GS" },
  { id: "sumo", label: "Sumo Logic", matchTypes: ["sumo_logic"], milliCentsPerGb: 25e4, billing: "entitlement", monogram: "SL" },
  { id: "newrelic", label: "New Relic", matchTypes: ["newrelic", "newrelic_events"], milliCentsPerGb: 4e4, billing: "metered", monogram: "NR" },
  { id: "s3", label: "Amazon S3", matchTypes: ["s3"], milliCentsPerGb: 2300, billing: "storage", monogram: "S3" },
  { id: "azure_blob", label: "Azure Blob", matchTypes: ["azure_blob"], milliCentsPerGb: 1800, billing: "storage", monogram: "AB" },
  { id: "cribl_lake", label: "Cribl Lake", matchTypes: ["cribl_lake"], milliCentsPerGb: 5e3, billing: "storage", monogram: "CL" },
  { id: "databricks", label: "Databricks", matchTypes: ["databricks", "databricks_zerobus"], milliCentsPerGb: 5e3, billing: "metered", monogram: "DB" },
  { id: "snowflake", label: "Snowflake", matchTypes: ["snowflake", "snowflake_streaming"], milliCentsPerGb: 3400, billing: "metered", monogram: "SF" },
  { id: "internal", label: "Internal / free", matchTypes: ["devnull", "cribl_tcp", "cribl_http", "router"], milliCentsPerGb: 0, billing: "metered", monogram: "IF" }
];
var FREE_OUTPUT_TYPES = ["devnull", "cribl_tcp", "cribl_http", "router", "default"];
function isFreeOutputType(outputType2) {
  return outputType2 !== void 0 && FREE_OUTPUT_TYPES.includes(outputType2.trim().toLowerCase());
}
var byId = new Map(PRESETS.map((p) => [p.id, p]));
function suggestPreset(outputType2, host) {
  const t = (outputType2 ?? "").trim().toLowerCase();
  if (t === "splunk" && host && /(^|\.)splunkcloud\.com$/i.test(host.trim().replace(/:\d+$/, "")))
    return "splunk_cloud";
  for (const p of PRESETS) {
    if (p.matchTypes.includes(t))
      return p.id;
  }
  return "internal";
}
var norm = (s) => s.trim().toLowerCase().replace(/[\s-]+/g, "_");
function presetFromDescription(description) {
  const m = /\bpriced\s+(?:with|as|at)\s+(?:the\s+)?(.+?)\s+preset\b/i.exec(description ?? "");
  if (!m)
    return void 0;
  const wanted = norm(m[1]);
  return PRESETS.find((p) => p.id === wanted || norm(p.label) === wanted)?.id;
}
var NAME_HINTS = [
  [["splunk", "siem"], "splunk_cloud"],
  [["sentinel"], "sentinel"],
  [["crowdstrike", "logscale", "humio"], "crowdstrike_ngsiem"],
  [["datadog", "analytics"], "datadog"],
  [["elastic", "elasticsearch"], "elastic"],
  [["chronicle", "secops"], "google_secops"],
  [["sumo", "sumologic"], "sumo"],
  [["newrelic"], "newrelic"],
  [["s3", "archive"], "s3"],
  [["blob"], "azure_blob"],
  [["lake"], "cribl_lake"],
  [["databricks"], "databricks"],
  [["snowflake"], "snowflake"]
];
function presetFromName(id) {
  const words = new Set((id ?? "").toLowerCase().split(/[^a-z0-9]+/).filter(Boolean));
  return NAME_HINTS.find(([hints]) => hints.some((w) => words.has(w)))?.[1];
}
function suggestPresetFor(o) {
  const described = presetFromDescription(o.description);
  if (described)
    return described;
  const byType = suggestPreset(o.type ?? "", o.host);
  if (byType !== "internal")
    return byType;
  return presetFromName(o.id) ?? "internal";
}
function isDemoTagged2(o) {
  return (o.description ?? "").includes(DEMO_TAG);
}
function isFreeOutput(o) {
  const hint = typeof o === "string" || o === void 0 ? { type: o } : o;
  return isFreeOutputType(hint.type) && !isDemoTagged2(hint) && suggestPresetFor(hint) === "internal";
}
function isUnpricedPreset(id, outputType2) {
  if (id === void 0)
    return true;
  if (id !== "internal")
    return false;
  return !isFreeOutputType(outputType2);
}
var DAYS_PER_MONTH = 365 / 12;

// core/net.ts
function criblCostCents(costCentsPerMonth) {
  return costCentsPerMonth !== void 0 && Number.isFinite(costCentsPerMonth) && costCentsPerMonth > 0 ? costCentsPerMonth : void 0;
}
function criblCostPerMinuteM(costCentsPerMonth) {
  return costCentsPerMonth * 1e3 * 12 / MINUTES_PER_YEAR;
}
function netOfCribl(savedM, minutes, costCentsPerMonth) {
  const cents = criblCostCents(costCentsPerMonth);
  if (cents === void 0 || !Number.isFinite(savedM) || !(minutes > 0) || !Number.isFinite(minutes))
    return null;
  const perMinute = criblCostPerMinuteM(cents);
  const exact = perMinute * minutes;
  const costM = Math.round(exact);
  const out = { costM, netM: savedM - costM, minutes, costPerDayM: perMinute * 1440 };
  if (exact > 0)
    out.paybackX = savedM / exact;
  return out;
}
function meteredSpan(periodStartMs, toMs, collectingSinceMs) {
  const since = collectingSinceMs !== void 0 && Number.isFinite(collectingSinceMs) ? collectingSinceMs : Number.NEGATIVE_INFINITY;
  const fromMs = Math.max(periodStartMs, since);
  return { fromMs, minutes: Math.max(0, toMs - fromMs) / 6e4, sinceCollecting: fromMs > periodStartMs };
}
function mtdNetOfCribl(mtdSavedM, sweepMs, tz, collectingSinceMs, costCentsPerMonth) {
  if (!Number.isFinite(sweepMs))
    return null;
  return netOfCribl(mtdSavedM, meteredSpan(localMonthStartMs(sweepMs, tz), sweepMs, collectingSinceMs).minutes, costCentsPerMonth);
}

// core/pricing.ts
function outputPriceKey(groupId, outputId) {
  return `${groupId}:${outputId}`;
}
function emptyPrices(nowIso) {
  return { schemaVersion: 1, updatedAt: nowIso, versions: [] };
}
var sortedCache = /* @__PURE__ */ new WeakMap();
function sortedVersions(prices) {
  const versions = prices?.versions ?? [];
  const hit = sortedCache.get(versions);
  if (hit && hit.n === versions.length)
    return hit.sorted;
  const sorted = versions.map((v, i) => ({ t: fromIso(v.effectiveFrom), v, i })).filter((x) => !Number.isNaN(x.t)).sort((a, b) => a.t - b.t || a.i - b.i).map(({ t, v }) => ({ t, v }));
  sortedCache.set(versions, { n: versions.length, sorted });
  return sorted;
}
function entryIn(version2, groupId, outputId) {
  return version2.byOutputId[outputPriceKey(groupId, outputId)] ?? version2.byOutputId[outputId];
}
function priceEntryAt(prices, groupId, outputId, tMs) {
  const sorted = sortedVersions(prices);
  for (let i = sorted.length - 1; i >= 0; i--) {
    if (sorted[i].t > tMs)
      continue;
    const e = entryIn(sorted[i].v, groupId, outputId);
    if (e)
      return e;
  }
  for (let i = 0; i < sorted.length; i++) {
    const e = entryIn(sorted[i].v, groupId, outputId);
    if (e)
      return sorted[i].t > tMs ? e : void 0;
  }
  return void 0;
}
function effectivePrices(prices, groupId, outputId, tMs, outputType2) {
  const entry = priceEntryAt(prices, groupId, outputId, tMs);
  const paidMcPerGb = entry?.milliCentsPerGb ?? 0;
  const counterfactual = entry?.counterfactual ?? { kind: "same" };
  let whpMcPerGb;
  let counterfactualUnpriced = false;
  switch (counterfactual.kind) {
    case "other": {
      if (counterfactual.outputId === outputId) {
        whpMcPerGb = paidMcPerGb;
        break;
      }
      const target = priceEntryAt(prices, groupId, counterfactual.outputId, tMs);
      whpMcPerGb = target?.milliCentsPerGb ?? 0;
      counterfactualUnpriced = !target;
      break;
    }
    case "none":
      whpMcPerGb = 0;
      break;
    default:
      whpMcPerGb = paidMcPerGb;
  }
  const anyPrice = (prices?.versions ?? []).length > 0;
  const type = typeof outputType2 === "string" ? outputType2 : outputType2?.type;
  const unpricedSelf = !entry ? !(anyPrice && isFreeOutput(outputType2)) : entry.milliCentsPerGb === 0 && isUnpricedPreset(entry.preset, type);
  return { paidMcPerGb, whpMcPerGb, counterfactual, unpriced: unpricedSelf || counterfactualUnpriced, counterfactualUnpriced };
}
function priceMinute(bytes, paidMcPerGb, whpMcPerGb, counterfactual = "same") {
  const kind = typeof counterfactual === "string" ? counterfactual : counterfactual.kind;
  const inB = Number.isFinite(bytes.inB) && bytes.inB > 0 ? bytes.inB : 0;
  const outB = Number.isFinite(bytes.outB) && bytes.outB > 0 ? bytes.outB : 0;
  const paidPrice = Number.isFinite(paidMcPerGb) && paidMcPerGb > 0 ? paidMcPerGb : 0;
  const whpPrice = Number.isFinite(whpMcPerGb) && whpMcPerGb > 0 ? whpMcPerGb : 0;
  const paidM = Math.round(outB * paidPrice / 1e9);
  if (kind === "none")
    return { whpM: 0, paidM, savedM: 0 };
  const whpM = Math.round(inB * whpPrice / 1e9);
  return { whpM, paidM, savedM: Math.max(0, whpM - paidM) };
}
function isDiversion(counterfactual, outputId) {
  return counterfactual?.kind === "other" && counterfactual.outputId !== outputId;
}
function addedCost(m) {
  return m.whpM > 0 && m.paidM > m.whpM ? m.paidM - m.whpM : 0;
}
var INFLATION_NOISE = 0.01;
function ratio(savedM, whpM) {
  if (!(whpM > 0) || !Number.isFinite(savedM))
    return 0;
  return Math.min(1, Math.max(0, savedM / whpM));
}
var zero = () => ({ whpM: 0, paidM: 0, savedM: 0, minutes: 0 });
function addDay(acc, d) {
  if (!d)
    return;
  acc.whpM += d.whpM;
  acc.paidM += d.paidM;
  acc.savedM += d.savedM;
  acc.minutes += d.minutes;
}
function computeHeadline(totals, nowMs, tz, collectingSinceMs, criblCostCentsPerMonth, meteredThroughMs) {
  const byDay = totals?.byDay ?? {};
  const todayKey = localDayKey(nowMs, tz);
  const monthKey = localMonthKey(nowMs, tz);
  const today = zero();
  addDay(today, byDay[todayKey]);
  const mtd = zero();
  const d30 = zero();
  const d30FirstKey = addDaysToKey(todayKey, -29);
  for (const [key, d] of Object.entries(byDay)) {
    if (key > todayKey)
      continue;
    if (key.startsWith(monthKey))
      addDay(mtd, d);
    if (key >= d30FirstKey)
      addDay(d30, d);
  }
  const since = Number.isFinite(collectingSinceMs) ? collectingSinceMs : nowMs;
  const sinceKey = localDayKey(since, tz);
  const firstWholeKey = localMidnightMs(since, tz) === since ? sinceKey : addDaysToKey(sinceKey, 1);
  const yesterdayKey = addDaysToKey(todayKey, -1);
  const wholeDays = firstWholeKey <= yesterdayKey ? daysBetweenKeys(firstWholeKey, yesterdayKey) + 1 : 0;
  let annualizedM = 0;
  let annualizedFromDays = 0;
  const recent = zero();
  const firstKey = sinceKey > d30FirstKey ? sinceKey : d30FirstKey;
  for (const [key, d] of Object.entries(byDay))
    if (key >= firstKey && key <= todayKey)
      addDay(recent, d);
  if (recent.minutes > 0) {
    annualizedM = Math.round(recent.savedM / recent.minutes * MINUTES_PER_YEAR);
    const n = Math.min(30, wholeDays);
    annualizedFromDays = n >= 1 ? n : recent.minutes / 1440;
  }
  const headline = {
    todayM: today.savedM,
    mtdM: mtd.savedM,
    d30M: d30.savedM,
    annualizedM,
    annualizedFromDays,
    whpMtdM: mtd.whpM,
    paidMtdM: mtd.paidM,
    ratioMtd: ratio(mtd.savedM, mtd.whpM),
    whpTodayM: today.whpM,
    paidTodayM: today.paidM,
    whp30dM: d30.whpM,
    paid30dM: d30.paidM
  };
  const through = Number.isFinite(meteredThroughMs) ? Math.min(meteredThroughMs, nowMs) : nowMs;
  const heldMin = (startMs) => Math.max(0, Math.floor((through - startMs) / MINUTE_MS));
  headline.minutesMtd = mtd.minutes;
  headline.expectedMinutesMtd = heldMin(localMonthStartMs(nowMs, tz));
  headline.minutesToday = today.minutes;
  headline.expectedMinutesToday = heldMin(localMidnightMs(nowMs, tz));
  headline.minutes30d = d30.minutes;
  headline.expectedMinutes30d = heldMin(localDayStartMs(d30FirstKey, tz));
  const net = mtdNetOfCribl(mtd.savedM, nowMs, tz, collectingSinceMs, criblCostCentsPerMonth);
  if (net) {
    headline.netMtdM = net.netM;
    if (net.paybackX !== void 0)
      headline.paybackX = net.paybackX;
  }
  return headline;
}
var BUDGET_SETTLED_MIN = 1440;
var BUDGET_SETTLED_MONTH_SHARE = 0.05;
var BUDGET_EARLY_MIN = 3 * 1440;
function meteredMinutesInMonth(totals, monthKey) {
  let n = 0;
  for (const [day, d] of Object.entries(totals?.byDay ?? {}))
    if (day.startsWith(monthKey))
      n += Number.isFinite(d?.minutes) ? d.minutes : 0;
  return n;
}
function budgetPace(input) {
  const monthMin = minutesInMonth(input.nowMs, input.tz);
  const monthStart = localMonthStartMs(input.nowMs, input.tz);
  const metered = Number.isFinite(input.meteredMinutes) ? Math.max(0, input.meteredMinutes) : 0;
  let elapsedMin;
  let basis;
  if (metered > 0) {
    elapsedMin = Math.min(metered, monthMin);
    basis = "metered";
  } else {
    const since = Number.isFinite(input.collectingSinceMs) ? Math.max(monthStart, input.collectingSinceMs) : monthStart;
    elapsedMin = Math.max(0, (input.nowMs - since) / MINUTE_MS);
    basis = "elapsed";
  }
  const paid = Number.isFinite(input.paidMtdM) ? Math.max(0, input.paidMtdM) : 0;
  const projectedM = elapsedMin > 0 ? paid / Math.max(1, elapsedMin) * monthMin : 0;
  const pace = {
    projectedM,
    elapsedMin,
    basis,
    settled: elapsedMin >= Math.min(BUDGET_SETTLED_MIN, BUDGET_SETTLED_MONTH_SHARE * monthMin),
    early: elapsedMin < BUDGET_EARLY_MIN
  };
  const budgetM = (input.budgetCentsPerMonth ?? 0) * 1e3;
  if (budgetM > 0)
    pace.pct = projectedM / budgetM * 100;
  return pace;
}

// core/adapters/metrics.ts
var MINUTE_MS2 = 6e4;
var MAX_INFERRED_WIDTH_S = 3600;
var AGGS = {
  inputs: ['sum("total.in_bytes").as("inB")', 'sum("total.in_events").as("inE")'],
  outputs: ['sum("total.out_bytes").as("outB")', 'sum("total.out_events").as("outE")'],
  routes: ['sum("route.in_bytes").as("inB")', 'sum("route.out_bytes").as("outB")', 'sum("route.in_events").as("inE")', 'sum("route.out_events").as("outE")'],
  pipelines: ['sum("pipe.in_events").as("inE")', 'sum("pipe.out_events").as("outE")']
};
var SPLITS = {
  inputs: ["__worker_group", "input"],
  outputs: ["__worker_group", "output"],
  routes: ["__worker_group", "route", "name"],
  pipelines: ["__worker_group", "id"]
};
function groupWhere(groupIds) {
  if (groupIds.length === 0)
    throw new Error("groupWhere needs at least one worker group");
  const lit = (g) => `'${g.replace(/\\/g, "\\\\").replace(/'/g, "\\'")}'`;
  const terms = groupIds.map((g) => `__worker_group==${lit(g)}`);
  return terms.length === 1 ? terms[0] : `(${terms.join(" || ")})`;
}
function alignDown(ms) {
  return Math.floor(ms / MINUTE_MS2) * MINUTE_MS2;
}
function buildWindowQueries(groupIds, windowStartMs, windowEndMs, timeWindowSeconds = 60, opts = {}) {
  const where = groupWhere(groupIds);
  const earliest = alignDown(windowStartMs);
  const latest = alignDown(windowEndMs);
  const body = (name) => ({
    where,
    earliest,
    latest,
    aggs: { aggregations: [...AGGS[name]], splitBys: [...SPLITS[name]], timeWindowSeconds }
  });
  const q = { inputs: body("inputs"), outputs: body("outputs"), routes: body("routes") };
  if (opts.withPipelines)
    q.pipelines = body("pipelines");
  return q;
}
var MetricsQueryError = class extends Error {
  constructor(query, status, detail2) {
    super(`metrics ${query} query failed: HTTP ${status}${detail2 ? ` ${detail2.slice(0, 200)}` : ""}`);
    this.name = "MetricsQueryError";
    this.query = query;
    this.status = status;
  }
};
function num(v) {
  if (typeof v === "number")
    return Number.isFinite(v) ? v : void 0;
  if (typeof v === "string" && v.trim() !== "") {
    const n = Number(v);
    return Number.isFinite(n) ? n : void 0;
  }
  return void 0;
}
var count = (v) => Math.max(0, Math.round(num(v) ?? 0));
var nonEmpty = (v) => typeof v === "string" && v.length > 0;
function resultsOf(res) {
  const body = res.json !== null && typeof res.json === "object" ? res.json : {};
  const rows = Array.isArray(body.results) ? body.results.filter((r) => r !== null && typeof r === "object") : [];
  const info = body.info !== null && typeof body.info === "object" ? body.info : {};
  const w = num(info.timeWindowSeconds);
  return { rows, declaredWidth: w !== void 0 && w > 0 ? w : void 0 };
}
function rowTiming(row, fallbackWidth) {
  const start = num(row.starttime) ?? num(row._time);
  if (start === void 0)
    return null;
  const end = num(row.endtime);
  return { startSec: start, widthSec: end !== void 0 && end > start ? end - start : fallbackWidth };
}
function splitDimension(value, known) {
  const at = value.indexOf(":");
  if (at < 0)
    return { type: "", id: value, variant: false };
  const type = value.slice(0, at);
  const rest = value.slice(at + 1);
  const segs = rest.split(":");
  if (known && known.size > 0) {
    if (known.has(rest))
      return { type, id: rest, variant: false };
    for (let k = segs.length - 1; k >= 1; k--) {
      const candidate = segs.slice(0, k).join(":");
      if (known.has(candidate))
        return { type, id: candidate, variant: true };
    }
  }
  return { type, id: segs[0], variant: segs.length > 1 };
}
var add = (x, y) => ({ bytes: x.bytes + y.bytes, events: x.events + y.events });
function parseEndpointRows(rows, dim, bytesAlias, eventsAlias, groups, fallbackWidth, types, knownIds) {
  const buckets = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const gid = row.__worker_group;
    const value = row[dim];
    if (!nonEmpty(gid) || !nonEmpty(value) || !groups.has(gid))
      continue;
    const timing = rowTiming(row, fallbackWidth);
    if (!timing)
      continue;
    const { type, id, variant } = splitDimension(value, knownIds.get(gid));
    const series = `${gid}:${id}`;
    if (type && !types[series])
      types[series] = type;
    const k = `${timing.startSec}|${series}`;
    let b = buckets.get(k);
    if (!b) {
      b = { ...timing, series, exact: null, sub: null };
      buckets.set(k, b);
    }
    b.widthSec = Math.max(b.widthSec, timing.widthSec);
    const be = { bytes: count(row[bytesAlias]), events: count(row[eventsAlias]) };
    if (variant)
      b.sub = b.sub ? add(b.sub, be) : be;
    else
      b.exact = b.exact ? add(b.exact, be) : be;
  }
  return [...buckets.values()].map((b) => ({ startSec: b.startSec, widthSec: b.widthSec, series: b.series, a: b.exact ?? b.sub }));
}
function parseRouteRows(rows, groups, fallbackWidth, names) {
  let sawBytes = false;
  const buckets = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const gid = row.__worker_group;
    const routeId = row.route;
    if (!nonEmpty(gid) || !nonEmpty(routeId) || !groups.has(gid))
      continue;
    const timing = rowTiming(row, fallbackWidth);
    if (!timing)
      continue;
    const series = `${gid}:${routeId}`;
    const hasName = nonEmpty(row.name);
    if (hasName && !names[series])
      names[series] = row.name;
    if (num(row.inB) !== void 0 || num(row.outB) !== void 0)
      sawBytes = true;
    const k = `${timing.startSec}|${series}`;
    let b = buckets.get(k);
    if (!b) {
      b = { ...timing, series, named: null, unnamed: null };
      buckets.set(k, b);
    }
    b.widthSec = Math.max(b.widthSec, timing.widthSec);
    const pair = [
      { bytes: count(row.inB), events: count(row.inE) },
      { bytes: count(row.outB), events: count(row.outE) }
    ];
    const slot = hasName ? "named" : "unnamed";
    const prev = b[slot];
    b[slot] = prev ? [add(prev[0], pair[0]), add(prev[1], pair[1])] : pair;
  }
  const samples = [...buckets.values()].map((b) => {
    const [a, out] = b.named ?? b.unnamed;
    return { startSec: b.startSec, widthSec: b.widthSec, series: b.series, a, b: out };
  });
  return { samples, sawBytes };
}
function parsePipelineRows(rows, groups, fallbackWidth) {
  const buckets = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const gid = row.__worker_group;
    const id = row.id;
    if (!nonEmpty(gid) || !nonEmpty(id) || !groups.has(gid))
      continue;
    const timing = rowTiming(row, fallbackWidth);
    if (!timing)
      continue;
    const series = `${gid}:${id}`;
    const k = `${timing.startSec}|${series}`;
    const inE = { bytes: 0, events: count(row.inE) };
    const outE = { bytes: 0, events: count(row.outE) };
    const prev = buckets.get(k);
    if (prev) {
      prev.a = add(prev.a, inE);
      prev.b = add(prev.b, outE);
      prev.widthSec = Math.max(prev.widthSec, timing.widthSec);
    } else
      buckets.set(k, { ...timing, series, a: inE, b: outE });
  }
  return [...buckets.values()];
}
function inferBucketWidths(declared) {
  const starts = [...declared.keys()].sort((x, y) => x - y);
  const eff = /* @__PURE__ */ new Map();
  for (let i = 0; i < starts.length; i++) {
    const s = starts[i];
    const w = declared.get(s);
    const gNext = i + 1 < starts.length ? starts[i + 1] - s : void 0;
    const gPrev = i > 0 ? s - starts[i - 1] : void 0;
    const gAfter = i + 2 < starts.length ? starts[i + 2] - starts[i + 1] : void 0;
    const coarse = (g) => g !== void 0 && g > w && g % w === 0 && g <= MAX_INFERRED_WIDTH_S && s % g === 0;
    let width = w;
    if (coarse(gNext) && (gPrev === gNext || gAfter === gNext))
      width = gNext;
    else if (gNext === void 0 && coarse(gPrev) && eff.get(starts[i - 1]) === gPrev)
      width = gPrev;
    eff.set(s, width);
  }
  return eff;
}
function splitInt(total, n) {
  const base = Math.floor(total / n);
  let rem = total - base * n;
  return Array.from({ length: n }, () => base + (rem-- > 0 ? 1 : 0));
}
function iso(ms) {
  return new Date(ms).toISOString();
}
async function fetchMetrics(http, groupIds, startMs, endMs, opts = {}) {
  const rangeStart = alignDown(startMs);
  const rangeEnd = alignDown(endMs);
  const result = {
    windows: [],
    inputTypes: {},
    outputTypes: {},
    routeNames: {},
    hasRouteBytes: false,
    coarse: false,
    calls: 0,
    errors: []
  };
  if (rangeEnd <= rangeStart || groupIds.length === 0)
    return result;
  const requested = opts.timeWindowSeconds ?? 60;
  const queries = buildWindowQueries(groupIds, rangeStart, rangeEnd, requested, { withPipelines: opts.withPipelines });
  const names = ["inputs", "outputs", "routes"];
  if (queries.pipelines)
    names.push("pipelines");
  const responses = await Promise.all(
    names.map((n) => http.request("POST", metricsQuery(), queries[n], opts.timeoutMs ? { timeoutMs: opts.timeoutMs } : void 0))
  );
  result.calls = responses.length;
  const byName = new Map(names.map((n, i) => [n, responses[i]]));
  for (const n of ["inputs", "outputs"]) {
    const res = byName.get(n);
    if (!res.ok)
      throw new MetricsQueryError(n, res.status, res.text ?? (res.json === void 0 ? void 0 : JSON.stringify(res.json)));
  }
  const groups = new Set(groupIds);
  const inputsRes = resultsOf(byName.get("inputs"));
  const outputsRes = resultsOf(byName.get("outputs"));
  const knownInputs = /* @__PURE__ */ new Map();
  const knownOutputs = /* @__PURE__ */ new Map();
  for (const [gid, g] of Object.entries(opts.inventory?.byGroup ?? {})) {
    knownInputs.set(gid, new Set(g.inputs.map((i) => i.id)));
    knownOutputs.set(gid, new Set(g.outputs.map((o) => o.id)));
  }
  const inputSamples = parseEndpointRows(inputsRes.rows, "input", "inB", "inE", groups, inputsRes.declaredWidth ?? requested, result.inputTypes, knownInputs);
  const outputSamples = parseEndpointRows(outputsRes.rows, "output", "outB", "outE", groups, outputsRes.declaredWidth ?? requested, result.outputTypes, knownOutputs);
  let routeSamples = null;
  const routesRaw = byName.get("routes");
  if (routesRaw.ok) {
    const r = resultsOf(routesRaw);
    const parsed = parseRouteRows(r.rows, groups, r.declaredWidth ?? requested, result.routeNames);
    routeSamples = parsed.samples;
    result.hasRouteBytes = parsed.sawBytes;
  } else {
    result.errors.push({ query: "routes", status: routesRaw.status, message: (routesRaw.text ?? "").slice(0, 200) });
  }
  let pipelineSamples = null;
  const pipesRaw = byName.get("pipelines");
  if (pipesRaw) {
    if (pipesRaw.ok) {
      const p = resultsOf(pipesRaw);
      pipelineSamples = parsePipelineRows(p.rows, groups, p.declaredWidth ?? requested);
    } else {
      result.errors.push({ query: "pipelines", status: pipesRaw.status, message: (pipesRaw.text ?? "").slice(0, 200) });
    }
  }
  const windows = /* @__PURE__ */ new Map();
  for (let m = rangeStart; m < rangeEnd; m += MINUTE_MS2) {
    const w = {
      windowStart: iso(m),
      windowEnd: iso(m + MINUTE_MS2),
      inputs: {},
      outputs: {},
      has: { routeBytes: result.hasRouteBytes, pipelineBytes: false },
      coarse: false,
      bucketSeconds: 60
    };
    if (routeSamples) {
      w.routesIn = {};
      w.routesOut = {};
    }
    if (pipelineSamples) {
      w.pipelinesIn = {};
      w.pipelinesOut = {};
    }
    windows.set(m, w);
  }
  const declared = /* @__PURE__ */ new Map();
  const everySample = [...inputSamples, ...outputSamples, ...routeSamples ?? [], ...pipelineSamples ?? []];
  for (const s of everySample)
    declared.set(s.startSec, Math.max(declared.get(s.startSec) ?? 0, s.widthSec));
  const effective = inferBucketWidths(declared);
  const place = (samples, a, b) => {
    for (const s of samples) {
      const width = Math.max(s.widthSec, effective.get(s.startSec) ?? s.widthSec);
      const bucketStart = s.startSec * 1e3;
      if (width <= 60) {
        const w = windows.get(alignDown(bucketStart));
        if (!w)
          continue;
        accumulate(w, a, s.series, s.a);
        if (b && s.b)
          accumulate(w, b, s.series, s.b);
        continue;
      }
      const from = Math.max(Math.ceil(bucketStart / MINUTE_MS2) * MINUTE_MS2, rangeStart);
      const to = Math.min(bucketStart + width * 1e3, rangeEnd);
      const minutes = [];
      for (let m = from; m < to; m += MINUTE_MS2)
        minutes.push(m);
      if (minutes.length === 0)
        continue;
      const spread2 = (be) => {
        const bytes = splitInt(be.bytes, minutes.length);
        const events = splitInt(be.events, minutes.length);
        return minutes.map((_, i) => ({ bytes: bytes[i], events: events[i] }));
      };
      const partsA = spread2(s.a);
      const partsB = b && s.b ? spread2(s.b) : null;
      minutes.forEach((m, i) => {
        const w = windows.get(m);
        w.coarse = true;
        w.bucketSeconds = Math.max(w.bucketSeconds, width);
        accumulate(w, a, s.series, partsA[i]);
        if (b && partsB)
          accumulate(w, b, s.series, partsB[i]);
      });
    }
  };
  place(inputSamples, "inputs");
  place(outputSamples, "outputs");
  if (routeSamples)
    place(routeSamples, "routesIn", "routesOut");
  if (pipelineSamples)
    place(pipelineSamples, "pipelinesIn", "pipelinesOut");
  result.windows = [...windows.values()];
  result.coarse = result.windows.some((w) => w.coarse);
  return result;
}
function accumulate(w, target, series, be) {
  const map = w[target];
  const prev = map[series];
  map[series] = prev ? add(prev, be) : { bytes: be.bytes, events: be.events };
}

// core/adapters/config.ts
var ConfigApiError = class extends Error {
  constructor(path, status, detail2) {
    super(`config read ${path} failed: HTTP ${status}${detail2 ? ` ${detail2.slice(0, 200)}` : ""}`);
    this.name = "ConfigApiError";
    this.status = status;
    this.path = path;
  }
};
var isObj3 = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
var str = (v) => typeof v === "string" && v.length > 0 ? v : void 0;
var bool = (v) => typeof v === "boolean" ? v : void 0;
function itemsOf(body) {
  const list = Array.isArray(body) ? body : isObj3(body) ? body.items : void 0;
  return Array.isArray(list) ? list.filter(isObj3) : [];
}
function withDefined(base, extras) {
  const out = base;
  for (const [k, v] of Object.entries(extras))
    if (v !== void 0)
      out[k] = v;
  return base;
}
var byId2 = (a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
function normalizeInputs(body) {
  const out = [];
  for (const it of itemsOf(body)) {
    const id = str(it.id);
    if (!id)
      continue;
    const connections = Array.isArray(it.connections) ? it.connections.filter(isObj3).map((c) => withDefined({ output: str(c.output) ?? "" }, { pipeline: str(c.pipeline) })).filter((c) => c.output.length > 0) : void 0;
    out.push(
      withDefined(
        { id, type: str(it.type) ?? "unknown" },
        {
          disabled: bool(it.disabled),
          description: str(it.description),
          pipeline: str(it.pipeline),
          connections: connections && connections.length > 0 ? connections : void 0,
          sendToRoutes: bool(it.sendToRoutes)
        }
      )
    );
  }
  return out.sort(byId2);
}
function normalizeOutputs(body) {
  const out = [];
  for (const it of itemsOf(body)) {
    const id = str(it.id);
    if (!id)
      continue;
    const type = str(it.type) ?? "unknown";
    out.push(
      withDefined(
        { id, type },
        {
          disabled: bool(it.disabled),
          description: str(it.description),
          pipeline: str(it.pipeline),
          defaultId: type === "default" ? str(it.defaultId) : void 0
        }
      )
    );
  }
  return out.sort(byId2);
}
function normalizePipelines(body) {
  const out = [];
  for (const it of itemsOf(body)) {
    const id = str(it.id);
    if (!id)
      continue;
    const conf = isObj3(it.conf) ? it.conf : {};
    const functions = (Array.isArray(conf.functions) ? conf.functions.filter(isObj3) : []).map(
      (f) => withDefined(
        { id: str(f.id) ?? "unknown" },
        { description: str(f.description), disabled: bool(f.disabled), filter: str(f.filter) }
      )
    );
    const pack = /^pack:(.+)$/.exec(id);
    const packId = pack ? pack[1] : conf.pack === true ? id : void 0;
    out.push(withDefined({ id, functions }, { description: str(conf.description), output: str(conf.output), packId }));
  }
  return out.sort(byId2);
}
function normalizeRoutes(body) {
  const tables = itemsOf(body);
  const table = tables.find((t) => t.id === "default") ?? tables[0];
  if (!table)
    return { routes: [] };
  const routes2 = [];
  for (const r of Array.isArray(table.routes) ? table.routes.filter(isObj3) : []) {
    const id = str(r.id);
    if (!id)
      continue;
    routes2.push(
      withDefined(
        { id, filter: typeof r.filter === "string" ? r.filter : "true", pipeline: str(r.pipeline) ?? "" },
        {
          name: str(r.name),
          output: str(r.output),
          final: bool(r.final),
          disabled: bool(r.disabled),
          description: str(r.description)
        }
      )
    );
  }
  return { routes: routes2, routeTableId: str(table.id) };
}
function inventoryHash(byGroup) {
  return fnv1a(stableStringify(byGroup));
}
async function getOk(http, path) {
  const res = await http.request("GET", path);
  if (!res.ok)
    throw new ConfigApiError(path, res.status, res.text ?? (res.json === void 0 ? void 0 : JSON.stringify(res.json)));
  return res.json;
}
async function fetchGroupInventory(http, groupId) {
  const [inputs2, outputs2, pipelines2, routes2] = await Promise.all([
    getOk(http, inputs(groupId)),
    getOk(http, outputs(groupId)),
    getOk(http, pipelines(groupId)),
    getOk(http, routes(groupId))
  ]);
  const r = normalizeRoutes(routes2);
  return withDefined(
    {
      inputs: normalizeInputs(inputs2),
      outputs: normalizeOutputs(outputs2),
      pipelines: normalizePipelines(pipelines2),
      routes: r.routes
    },
    { routeTableId: r.routeTableId }
  );
}
function workerGroupIds(body) {
  const ids = [];
  for (const g of itemsOf(body)) {
    const id = str(g.id);
    if (!id || id === "default_search" || g.isFleet === true || g.isSearch === true)
      continue;
    if (g.type === "stream" || g.type === void 0)
      ids.push(id);
  }
  return ids;
}

// core/timeline.ts
var MAX_COMMITS_PER_GROUP = 200;
function commitTimeMs(c) {
  const d = c.deployedAt ? fromIso(c.deployedAt) : Number.NaN;
  return Number.isNaN(d) ? fromIso(c.committedAt) : d;
}
function sameHash(a, b) {
  if (!a || !b)
    return false;
  if (a === b)
    return true;
  const [s, l] = a.length <= b.length ? [a, b] : [b, a];
  return s.length >= 7 && l.startsWith(s);
}
function mergeCommit(a, b) {
  const demo = a.source === "demo" ? a : b.source === "demo" ? b : void 0;
  const api = b.source === "api" ? b : a.source === "api" ? a : void 0;
  const hash = a.hash.length >= b.hash.length ? a.hash : b.hash;
  const files = [.../* @__PURE__ */ new Set([...a.files ?? [], ...b.files ?? []])];
  const out = {
    hash,
    message: (demo ?? api ?? b).message || a.message,
    author: demo?.author || b.author || a.author,
    committedAt: (api ?? b).committedAt || a.committedAt,
    groupId: b.groupId,
    files,
    source: demo ? "demo" : b.source
  };
  const deployedAt = demo?.deployedAt ?? b.deployedAt ?? a.deployedAt;
  if (deployedAt)
    out.deployedAt = deployedAt;
  const routeTable = mergeRouteTable(a.routeTable, b.routeTable);
  if (routeTable)
    out.routeTable = routeTable;
  return out;
}
function mergeRouteTable(a, b) {
  if (!a || !b)
    return a ?? b;
  const out = { ids: [.../* @__PURE__ */ new Set([...a.ids, ...b.ids])], names: [.../* @__PURE__ */ new Set([...a.names, ...b.names])] };
  const filters = [.../* @__PURE__ */ new Set([...a.filters ?? [], ...b.filters ?? []])];
  if (filters.length > 0)
    out.filters = filters;
  if (a.unresolved || b.unresolved)
    out.unresolved = true;
  return out;
}
function mergeCommits(doc, groupId, commits, nowIso) {
  const byGroup = { ...doc?.byGroup ?? {} };
  const list = [...byGroup[groupId] ?? []];
  for (const incoming of commits) {
    const c = { ...incoming, groupId, files: incoming.files ?? [] };
    const i = list.findIndex((x) => sameHash(x.hash, c.hash));
    if (i >= 0)
      list[i] = mergeCommit(list[i], c);
    else
      list.push(c);
  }
  list.sort((a, b) => commitTimeMs(b) - commitTimeMs(a) || (a.hash < b.hash ? -1 : a.hash > b.hash ? 1 : 0));
  byGroup[groupId] = list.slice(0, MAX_COMMITS_PER_GROUP);
  return { schemaVersion: 1, updatedAt: nowIso, byGroup };
}
function allCommits(doc) {
  return Object.values(doc?.byGroup ?? {}).flat().sort((a, b) => commitTimeMs(b) - commitTimeMs(a));
}
function basename(path) {
  const i = path.lastIndexOf("/");
  return i >= 0 ? path.slice(i + 1) : path;
}
var isRouteTable = (p) => {
  const b = basename(p);
  return b === "route.yml" || b === "routes.yml";
};
var touchesPipeline = (p, pipelineId) => !!pipelineId && pipelineId !== "-" && p.includes(`pipelines/${pipelineId}/`);
function filesTouchObject(files, key, pipelineIdForRoute) {
  const parsed = parseObjectKey(key);
  if (!parsed || !files?.length)
    return "none";
  const { kind, id } = parsed;
  switch (kind) {
    case "pipe":
      return files.some((p) => touchesPipeline(p, id)) ? "object" : "none";
    case "route":
      if (files.some((p) => touchesPipeline(p, pipelineIdForRoute)))
        return "object";
      return files.some(isRouteTable) ? "table" : "none";
    case "in":
      return files.some((p) => basename(p) === "inputs.yml") ? "table" : "none";
    case "out":
      return files.some((p) => basename(p) === "outputs.yml") ? "table" : "none";
    default:
      return "none";
  }
}
function isGroupRouteTable(path) {
  return typeof path === "string" && isRouteTable(path) && !/(?:^|\/)default\/(?!cribl\/)[^/]+\/pipelines\/routes?\.yml$/.test(path);
}
var isDiffObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
var ENTRY_LINE = /^\s{0,4}-\s+id:\s*(.+?)\s*$/;
var TOP_LINE = /^\S/;
var NAME_LINE = /^\s{2,6}name:\s*(.+?)\s*$/;
var FILTER_LINE = /^\s{2,6}filter:\s*(.+?)\s*$/;
var TRIVIAL_FILTER = /^(?:true|)$/;
var unquote = (v) => v.replace(/^(['"])(.*)\1$/, "$2");
function routeTableEdits(diffJson) {
  const ids = /* @__PURE__ */ new Set();
  const names = /* @__PURE__ */ new Set();
  const filters = /* @__PURE__ */ new Set();
  let unresolved = false;
  let touched = false;
  for (const f of Array.isArray(diffJson) ? diffJson.filter(isDiffObj) : []) {
    if (!isGroupRouteTable(f.newName) && !isGroupRouteTable(f.oldName))
      continue;
    touched = true;
    const blocks = Array.isArray(f.blocks) ? f.blocks.filter(isDiffObj) : [];
    const lineCount = blocks.reduce((n, b) => n + (Array.isArray(b.lines) ? b.lines.length : 0), 0);
    const changedCount = (typeof f.addedLines === "number" ? f.addedLines : 0) + (typeof f.deletedLines === "number" ? f.deletedLines : 0);
    if (f.isTooBig === true || lineCount === 0 && changedCount > 0) {
      unresolved = true;
      continue;
    }
    for (const b of blocks) {
      let seg3 = { top: false, changed: false, names: [] };
      const close = () => {
        if (!seg3.changed || seg3.top)
          return;
        if (seg3.id !== void 0)
          ids.add(seg3.id);
        else if (seg3.names.length > 0)
          for (const n of seg3.names)
            names.add(n);
        else if (seg3.filter !== void 0 && !TRIVIAL_FILTER.test(seg3.filter))
          filters.add(seg3.filter);
        else
          unresolved = true;
      };
      for (const l of Array.isArray(b.lines) ? b.lines.filter(isDiffObj) : []) {
        const raw = typeof l.content === "string" ? l.content : "";
        const text = /^[ +-]/.test(raw) ? raw.slice(1) : raw;
        const changed = l.type === "insert" || l.type === "delete";
        const entry = ENTRY_LINE.exec(text);
        if (entry) {
          close();
          seg3 = { top: false, changed, id: unquote(entry[1]), names: [] };
          continue;
        }
        if (TOP_LINE.test(text)) {
          close();
          seg3 = { top: true, changed: false, names: [] };
          continue;
        }
        const name = NAME_LINE.exec(text);
        if (name && !seg3.names.includes(unquote(name[1])))
          seg3.names.push(unquote(name[1]));
        const filter = FILTER_LINE.exec(text);
        if (filter && seg3.filter === void 0)
          seg3.filter = unquote(filter[1]);
        if (changed)
          seg3.changed = true;
      }
      close();
    }
  }
  if (!touched)
    return void 0;
  const out = { ids: [...ids], names: [...names] };
  if (filters.size > 0)
    out.filters = [...filters];
  if (unresolved)
    out.unresolved = true;
  return out;
}
function routeEntryChanged(edits, route) {
  if (!edits)
    return false;
  if (edits.ids.includes(route.id))
    return true;
  if (edits.names.some((n) => n === route.id || route.name !== void 0 && route.name !== "" && n === route.name))
    return true;
  const filter = route.filter?.trim();
  return filter !== void 0 && !TRIVIAL_FILTER.test(filter) && (edits.filters ?? []).includes(filter);
}
function messageNamesObject(message, ids) {
  if (!message)
    return false;
  for (const id of ids) {
    if (!id || id === "-")
      continue;
    let from = 0;
    for (; ; ) {
      const i = message.indexOf(id, from);
      if (i < 0)
        break;
      const before = i === 0 ? "" : message[i - 1];
      const after = message[i + id.length] ?? "";
      if (!/[A-Za-z0-9_.-]/.test(before) && !/[A-Za-z0-9_-]/.test(after))
        return true;
      from = i + 1;
    }
  }
  return false;
}
function toRef(c, match) {
  const ref = { hash: c.hash, message: c.message, author: c.author, committedAt: c.committedAt, groupId: c.groupId, match };
  if (c.deployedAt)
    ref.deployedAt = c.deployedAt;
  return ref;
}
function matchCommit(commits, key, opts) {
  const parsed = parseObjectKey(key);
  const groupId = opts.groupId ?? parsed?.groupId;
  const inWindow = commits.filter((c) => (groupId === void 0 || c.groupId === groupId) && commitTimeMs(c) >= opts.sinceMs && commitTimeMs(c) <= opts.untilMs).sort((a, b) => commitTimeMs(b) - commitTimeMs(a));
  if (inWindow.length === 0)
    return void 0;
  const pipelineId = parsed?.kind === "pipe" ? parsed.id : opts.pipelineId;
  const ids = [parsed?.id, parsed?.kind === "route" ? opts.pipelineId : opts.routeId];
  const object = inWindow.find((c) => filesTouchObject(c.files, key, pipelineId) === "object");
  if (object)
    return toRef(object, "files");
  const named = inWindow.find((c) => messageNamesObject(c.message, ids));
  if (named)
    return toRef(named, "message");
  const route = parsed?.kind === "route" ? { id: parsed.id, ...opts.routeName !== void 0 ? { name: opts.routeName } : {}, ...opts.routeFilter !== void 0 ? { filter: opts.routeFilter } : {} } : void 0;
  const table = inWindow.find((c) => filesTouchObject(c.files, key, pipelineId) === "table" && (!route || routeEntryChanged(c.routeTable, route)));
  if (table)
    return toRef(table, "files");
  return toRef(inWindow[0], "nearby");
}

// core/adapters/version.ts
var VersionApiError = class extends Error {
  constructor(code, status, message, commit) {
    super(message);
    this.name = "VersionApiError";
    this.code = code;
    this.status = status;
    if (commit !== void 0)
      this.commit = commit;
  }
};
var isObj4 = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
var str2 = (v) => typeof v === "string" && v.length > 0 ? v : void 0;
function items(body) {
  const list = Array.isArray(body) ? body : isObj4(body) ? body.items : void 0;
  return Array.isArray(list) ? list.filter(isObj4) : [];
}
function detail(res) {
  const t = res.text ?? (res.json === void 0 ? "" : JSON.stringify(res.json));
  return t.slice(0, 200);
}
function parseGitDate(raw) {
  if (typeof raw === "number" && Number.isFinite(raw)) {
    const ms2 = raw < 1e12 ? raw * 1e3 : raw;
    return new Date(ms2).toISOString();
  }
  if (typeof raw !== "string" || raw.trim() === "")
    return null;
  const s = raw.trim();
  const m = /^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2}(?:\.\d+)?)\s*(Z|[+-]\d{2}:?\d{2})?$/.exec(s);
  let ms;
  if (m) {
    let zone = m[3] ?? "Z";
    if (zone !== "Z" && !zone.includes(":"))
      zone = `${zone.slice(0, 3)}:${zone.slice(3)}`;
    ms = Date.parse(`${m[1]}T${m[2]}${zone}`);
  } else
    ms = Date.parse(s);
  return Number.isFinite(ms) ? new Date(ms).toISOString() : null;
}
function filesFromDiff(diffJson) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  const push = (p) => {
    const path = str2(p);
    if (!path || path === "/dev/null" || seen.has(path))
      return;
    seen.add(path);
    out.push(path);
  };
  for (const d of Array.isArray(diffJson) ? diffJson.filter(isObj4) : []) {
    push(d.newName);
    push(d.oldName);
  }
  return out;
}
function filesFromTree(body) {
  const first = items(body)[0];
  const roots = first && Array.isArray(first.items) ? first.items : void 0;
  const out = [];
  const walk = (nodes, prefix) => {
    if (!Array.isArray(nodes))
      return;
    for (const n of nodes.filter(isObj4)) {
      const name = str2(n.name);
      if (!name)
        continue;
      const path = prefix ? `${prefix}/${name}` : name;
      if (Array.isArray(n.children) && n.children.length > 0)
        walk(n.children, path);
      else
        out.push(path);
    }
  };
  walk(roots, "");
  return [...new Set(out)];
}
var SHOW_DIFF_LINES = 200;
async function fetchFiles(http, groupId, hash) {
  const show = await http.request("GET", versionShow(groupId, hash, SHOW_DIFF_LINES));
  if (show.ok) {
    const first = items(show.json)[0];
    if (first) {
      const routeTable = routeTableEdits(first.diffJson);
      return { files: filesFromDiff(first.diffJson), ...routeTable ? { routeTable } : {} };
    }
  }
  const res = await http.request("GET", versionFiles(groupId, hash));
  const files = res.ok ? filesFromTree(res.json) : [];
  return files.some(isGroupRouteTable) ? { files, routeTable: { ids: [], names: [], unresolved: true } } : { files };
}
async function fetchCommits(http, groupId, count2 = 50, opts = {}) {
  const res = await http.request("GET", versionLog(groupId, count2));
  if (!res.ok)
    throw new VersionApiError("log_failed", res.status, `version log for ${groupId} failed: HTTP ${res.status} ${detail(res)}`);
  const cachedFiles = /* @__PURE__ */ new Map();
  for (const c of opts.cached ?? [])
    if (c.files.length > 0)
      cachedFiles.set(c.hash, c.routeTable ? { files: c.files, routeTable: c.routeTable } : { files: c.files });
  const commits = [];
  for (const row of items(res.json)) {
    const hash = str2(row.hash);
    const committedAt = parseGitDate(row.date);
    if (!hash || !committedAt)
      continue;
    const cached = cachedFiles.get(hash);
    const commit = {
      hash,
      message: typeof row.message === "string" ? row.message : "",
      author: str2(row.author_name) ?? str2(row.author_email) ?? "unknown",
      committedAt,
      groupId,
      files: cached?.files ?? [],
      source: "api"
    };
    if (cached?.routeTable)
      commit.routeTable = cached.routeTable;
    commits.push(commit);
  }
  if (opts.withFiles) {
    let budget = Math.max(0, opts.maxShow ?? 5);
    const neverRead = commits.filter((c) => c.files.length === 0);
    const routeEditsUnread = commits.filter((c) => c.files.length > 0 && c.routeTable === void 0 && c.files.some(isGroupRouteTable));
    for (const c of [...neverRead, ...routeEditsUnread]) {
      if (budget === 0)
        break;
      budget--;
      const read = await fetchFiles(http, groupId, c.hash);
      if (read.files.length > 0 || c.files.length === 0)
        c.files = read.files;
      if (read.routeTable)
        c.routeTable = read.routeTable;
    }
  }
  return commits;
}

// core/adapters/webhook.ts
var WEBHOOK_TIMEOUT_MS = 1e4;
var WEBHOOK_BACKOFF_MS = [2e3, 8e3];
function ipv4(host) {
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(host))
    return void 0;
  const o = host.split(".").map(Number);
  return o.every((n) => n <= 255) ? o : void 0;
}
function publicIpv4(o) {
  const [a, b] = o;
  if (a === 0 || a === 10 || a === 127 || a >= 224)
    return false;
  if (a === 100 && b >= 64 && b <= 127)
    return false;
  if (a === 169 && b === 254)
    return false;
  if (a === 172 && b >= 16 && b <= 31)
    return false;
  if (a === 192 && (b === 168 || b === 0 && o[2] === 0))
    return false;
  if (a === 198 && (b === 18 || b === 19))
    return false;
  return true;
}
function isPublicWebhookHost(hostname) {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  if (host === "")
    return false;
  if (host.startsWith("[")) {
    const v6 = host.slice(1, -1);
    if (v6 === "::" || v6 === "::1")
      return false;
    if (/^f[cd][0-9a-f]{0,2}:/.test(v6) || /^fe[89ab][0-9a-f]?:/.test(v6))
      return false;
    const mapped = /^::ffff:(?:([0-9a-f]{1,4}):([0-9a-f]{1,4})|(\d{1,3}(?:\.\d{1,3}){3}))$/.exec(v6);
    if (mapped) {
      const o2 = mapped[3] ? ipv4(mapped[3]) : [parseInt(mapped[1], 16) >> 8, parseInt(mapped[1], 16) & 255, parseInt(mapped[2], 16) >> 8, parseInt(mapped[2], 16) & 255];
      return o2 !== void 0 && publicIpv4(o2);
    }
    return true;
  }
  const o = ipv4(host);
  if (o)
    return publicIpv4(o);
  if (!host.includes("."))
    return false;
  return !/(^|\.)(localhost|local|internal|home\.arpa|lan)$/.test(host);
}
function hostnameOf(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return void 0;
  }
}
function classifyStatus(status) {
  if (status >= 200 && status < 300)
    return { ok: true, retry: false };
  if (status === 0)
    return { ok: false, retry: true, error: "network_error" };
  if (status === 403)
    return { ok: false, retry: false, error: "host_not_authorized" };
  if (status >= 500)
    return { ok: false, retry: true, error: `http_${status}` };
  return { ok: false, retry: false, error: `http_${status}` };
}
function redactUrls(text) {
  return text.replace(/https?:\/\/[^\s'"<>)]+/gi, (u) => hostnameOf(u) ?? "a URL");
}
async function deliver(p) {
  const sleep = p.sleep ?? defaultSleep;
  const backoff = p.backoffMs ?? WEBHOOK_BACKOFF_MS;
  const timeoutMs = p.timeoutMs ?? WEBHOOK_TIMEOUT_MS;
  const body = typeof p.body === "string" ? p.body : JSON.stringify(p.body);
  const logs = [];
  const log = (attempt, at, status, error, detail2) => {
    const entry = { endpointId: p.endpointId, event: p.event, status, attempt, at: new Date(at).toISOString(), kind: p.kind ?? "notify" };
    if (p.incidentId !== void 0)
      entry.incidentId = p.incidentId;
    if (error !== void 0)
      entry.error = error;
    if (detail2 !== void 0)
      entry.detail = redactUrls(detail2);
    logs.push(entry);
  };
  if (!/^https:\/\/[^\s/]+/i.test(p.url)) {
    log(1, p.clock.now(), 0, "invalid_url", "webhook URLs must be https://");
    return logs;
  }
  if (urlHasCredentials(p.url)) {
    log(1, p.clock.now(), 0, "invalid_url", "webhook URLs must not carry credentials");
    return logs;
  }
  const hostname = hostnameOf(p.url);
  if (hostname === void 0 || !isPublicWebhookHost(hostname)) {
    log(1, p.clock.now(), 0, "host_not_authorized", "webhook URLs must name a public host");
    return logs;
  }
  if (p.sender.allows && !p.sender.allows(p.url)) {
    log(1, p.clock.now(), 0, "host_not_authorized", "the host is not on this runtime's webhook host list");
    return logs;
  }
  for (let attempt = 1; attempt <= backoff.length + 1; attempt++) {
    const at = p.clock.now();
    let status = 0;
    let transportError;
    try {
      const res = await p.sender.post(p.url, body, timeoutMs);
      status = res.status;
      transportError = res.error;
    } catch (e) {
      transportError = e instanceof Error ? e.message : String(e);
    }
    const verdict = classifyStatus(status);
    log(attempt, at, status, verdict.error, status === 0 ? transportError : void 0);
    if (verdict.ok || !verdict.retry || attempt > backoff.length)
      break;
    await sleep(backoff[attempt - 1]);
  }
  return logs;
}
function isTimeoutAttempt(l) {
  return l.status === 0 && /^timeout\b/i.test(l.detail ?? "");
}
function lastAttempt(logs) {
  return logs[logs.length - 1];
}
function createFetchWebhookSender(fetchFn, opts = {}) {
  const allowHosts = opts.allowHosts?.map((h) => h.trim().toLowerCase()).filter(Boolean);
  return {
    ...allowHosts && allowHosts.length > 0 ? { allows: (url) => allowHosts.includes((hostnameOf(url) ?? "").toLowerCase()) } : {},
    async post(url, body, timeoutMs) {
      const controller = typeof AbortController === "function" ? new AbortController() : void 0;
      const init = { method: "POST", headers: { "content-type": "application/json" }, body, redirect: "error" };
      if (controller)
        init.signal = controller.signal;
      let timer;
      const timedOut = new Promise((resolve) => {
        timer = setTimeout(() => resolve("timeout"), timeoutMs);
      });
      try {
        const exchange = (async () => {
          const res = await Reflect.apply(fetchFn, globalThis, [url, init]);
          await res.text().catch(() => "");
          return res.status;
        })();
        exchange.catch(() => void 0);
        const outcome = await Promise.race([exchange, timedOut]);
        if (outcome === "timeout") {
          controller?.abort();
          return { status: 0, error: `timeout after ${timeoutMs} ms` };
        }
        return { status: outcome };
      } catch (e) {
        return { status: 0, error: e instanceof Error ? e.message : String(e) };
      } finally {
        if (timer !== void 0)
          clearTimeout(timer);
      }
    }
  };
}

// core/adapters/cribl-notify.ts
var BELL_PATH = "/system/messages";
var SEARCH_NOTIFY_PATH = "/search/notifications";
var SEARCH_GROUP = "default_search";
var RELAY_SAVED_SEARCH_ID = "meter_reader_alert_relay";
var RELAY_NOTIFICATION_PREFIX = "meter_reader_relay_";
var SEARCH_NOTIFICATION_ID_PREFIX = "SEARCH_NOTIFICATION_";
var savedSearchPath = (id = RELAY_SAVED_SEARCH_ID) => `/m/${SEARCH_GROUP}/search/saved/${encodeURIComponent(id)}`;
var SAVED_SEARCHES_PATH = `/m/${SEARCH_GROUP}/search/saved`;
async function call(http, method, path, body) {
  try {
    return await http.request(method, path, body);
  } catch (e) {
    const name = e instanceof Error ? e.name : "";
    const message = e instanceof Error ? e.message : String(e);
    const thrown = name === "BudgetExceeded" ? "budget" : name === "RateLimited" ? "rate_limited" : "network_error";
    return { status: 0, ok: false, thrown, message };
  }
}
function errorMessage(res) {
  const j = res.json;
  const m = typeof j?.message === "string" ? j.message : typeof res.text === "string" ? res.text : void 0;
  if (!m)
    return void 0;
  const flat = m.replace(/\s+/g, " ").trim();
  return flat.length > 160 ? `${flat.slice(0, 159)}\u2026` : flat;
}
function classifyCribl(res, conflictOk = false) {
  const s = res.status;
  if (res.thrown)
    return { status: 0, ok: false, error: res.thrown, retry: res.thrown === "network_error", ...res.message ? { detail: res.message } : {} };
  if (s >= 200 && s < 300)
    return { status: s, ok: true, retry: false };
  if (s === 409 && conflictOk)
    return { status: s, ok: true, retry: false, detail: "already exists" };
  const detail2 = errorMessage(res);
  const withDetail = (o) => detail2 ? { ...o, detail: detail2 } : o;
  if (s === 0)
    return withDetail({ status: 0, ok: false, error: "network_error", retry: true });
  if (s === 401 || s === 403)
    return withDetail({ status: s, ok: false, error: "not_permitted", retry: false });
  if (s === 404 || s === 405)
    return withDetail({ status: s, ok: false, error: "not_available", retry: false });
  if (s === 400)
    return withDetail({ status: s, ok: false, error: "invalid_request", retry: false });
  if (s === 429)
    return withDetail({ status: s, ok: false, error: "rate_limited", retry: false });
  return withDetail({ status: s, ok: false, error: `http_${s}`, retry: s >= 500 });
}
var BELL_SEVERITY = { high: "error", medium: "warn", info: "info" };
async function postBell(http, msg) {
  const out = classifyCribl(await call(http, "POST", BELL_PATH, msg), true);
  return out.status === 409 ? { ...out, detail: "already in the bell" } : out;
}
function relayNotificationId(targetId) {
  return `${RELAY_NOTIFICATION_PREFIX}${targetId.replace(/[^A-Za-z0-9_-]/g, "_")}`;
}
function relayEventId(notificationId, suffix) {
  return `${SEARCH_NOTIFICATION_ID_PREFIX}${notificationId}_${suffix.replace(/[^A-Za-z0-9_.-]/g, "_")}`;
}
async function relayState(http, targetId) {
  const res = await call(http, "GET", savedSearchPath());
  if (res.status === 404)
    return { state: "missing", savedSearch: false, notification: false };
  const out = classifyCribl(res);
  if (!out.ok)
    return { state: "error", status: out.status, error: out.error ?? "network_error", ...out.detail ? { detail: out.detail } : {} };
  const saved = res.json?.items?.[0];
  const wanted = relayNotificationId(targetId);
  const found = (saved?.schedule?.notifications?.items ?? []).some((n) => n?.id === wanted);
  return found ? { state: "ready", notificationId: wanted } : { state: "missing", savedSearch: true, notification: false };
}
function forwardBody(m) {
  const notificationId = relayNotificationId(m.targetId);
  const body = {
    id: relayEventId(notificationId, m.suffix),
    notificationId,
    savedQueryId: RELAY_SAVED_SEARCH_ID,
    group: SEARCH_GROUP,
    title: m.title,
    severity: BELL_SEVERITY[m.severity],
    message: m.message,
    _raw: m.message,
    now: m.now,
    _time: m.now
  };
  if (m.payload)
    body.meter_reader = m.payload;
  return body;
}
async function forwardViaTarget(http, m) {
  const res = await call(http, "POST", SEARCH_NOTIFY_PATH, forwardBody(m));
  const out = classifyCribl(res);
  if (res.status === 500)
    return { ...out, error: "relay_missing", retry: false };
  return { ...out, retry: false };
}

// core/format.ts
var MC_PER_CENT = 1e3;
var MC_PER_DOLLAR = 1e5;
var MINUS = "\u2212";
function groupThousands(n) {
  const s = String(Math.trunc(Math.abs(n)));
  let out = "";
  for (let i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 === 0)
      out += ",";
    out += s[i];
  }
  return out;
}
function roundHalfUp(x) {
  return Math.floor(x + 0.5);
}
function fmtDollars(mc) {
  if (!Number.isFinite(mc))
    return "$0";
  const dollars = roundHalfUp(Math.abs(mc) / MC_PER_DOLLAR);
  const body = `$${groupThousands(dollars)}`;
  return mc < 0 && dollars > 0 ? `${MINUS}${body}` : body;
}
function fmtDollarsCents(mc) {
  if (!Number.isFinite(mc))
    return "$0.00";
  const cents = roundHalfUp(Math.abs(mc) / MC_PER_CENT);
  const body = `$${groupThousands(Math.floor(cents / 100))}.${String(cents % 100).padStart(2, "0")}`;
  return mc < 0 && cents > 0 ? `${MINUS}${body}` : body;
}
function fmtPct(ratio2) {
  if (!Number.isFinite(ratio2))
    return "0%";
  const pct = roundHalfUp(Math.abs(ratio2) * 100);
  const text = pct >= 1e3 ? pct.toLocaleString("en-US") : String(pct);
  return ratio2 < 0 && pct > 0 ? `${MINUS}${text}%` : `${text}%`;
}
function fmtDuration(sec) {
  const total = Number.isFinite(sec) && sec > 0 ? Math.round(sec) : 0;
  const h = Math.floor(total / 3600);
  const m = Math.floor(total % 3600 / 60);
  const s = total % 60;
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${ss}` : `${m}:${ss}`;
}
var NBSP = "\xA0";
function fmtDurationShort(sec) {
  const total = Number.isFinite(sec) && sec > 0 ? Math.round(sec) : 0;
  const u = (n, unit) => `${n}${NBSP}${unit}`;
  if (total < 60)
    return u(total, "s");
  const d = Math.floor(total / 86400);
  const h = Math.floor(total % 86400 / 3600);
  const m = Math.floor(total % 3600 / 60);
  const s = total % 60;
  if (d > 0)
    return h > 0 ? `${u(d, "d")} ${u(h, "h")}` : u(d, "d");
  if (h > 0)
    return m > 0 ? `${u(h, "h")} ${u(m, "min")}` : u(h, "h");
  return s > 0 ? `${u(m, "min")} ${u(s, "s")}` : u(m, "min");
}
function perYear(mcPerDay) {
  return mcPerDay * 365;
}
function mcToDollarInput(mc) {
  const v = Math.max(0, Math.round(mc));
  const whole = Math.floor(v / MC_PER_DOLLAR);
  const rest = v % MC_PER_DOLLAR;
  let frac = String(rest).padStart(5, "0").replace(/0+$/, "");
  if (frac.length < 2)
    frac = frac.padEnd(2, "0");
  return `${whole}.${frac}`;
}
function roundToDollarsM(mc) {
  if (!Number.isFinite(mc))
    return 0;
  const dollars = roundHalfUp(Math.abs(mc) / MC_PER_DOLLAR);
  return (mc < 0 ? -dollars : dollars) * MC_PER_DOLLAR || 0;
}
function roundToCentsM(mc) {
  if (!Number.isFinite(mc))
    return 0;
  const cents = roundHalfUp(Math.abs(mc) / MC_PER_CENT);
  return (mc < 0 ? -cents : cents) * MC_PER_CENT || 0;
}
function footMoney(m, unit = "dollars") {
  const round = unit === "cents" ? roundToCentsM : roundToDollarsM;
  const whpM = round(m.whpM);
  const savedM = round(m.savedM);
  const paidM = round(m.paidM);
  const foots = Math.abs(m.whpM - m.paidM - m.savedM) < (unit === "cents" ? MC_PER_CENT : MC_PER_DOLLAR) / 2;
  return { whpM, paidM: foots ? Math.max(0, whpM - savedM) : paidM, savedM };
}

// core/humanize.ts
var DEMO_LABELS = {
  mrd_pay_sample: "Payments API sampling",
  mrd_win_xml_pack: "Windows XML pack",
  mrd_win_docs_reduce: "Windows XML reduction (aggressive)",
  mrd_k8s_noise: "Kubernetes noise filter",
  mrd_passthrough: "Passthrough (no reduction)",
  mrd_pan_pack: "Palo Alto pack",
  mrd_vpc_pack: "VPC Flow aggregation",
  // the rig's destinations, as demo/rig/destinations.json labels them (P1-I04: never slugs beside prose sources)
  mrd_siem_prod: "SIEM (prod)",
  mrd_siem_apps: "SIEM (apps)",
  mrd_analytics: "Analytics",
  mrd_archive_s3: "Archive (S3)",
  mrd_windows_dc: "Windows DC security events",
  mrd_windows_workstations: "Windows workstation events",
  mrd_pan_firewall: "Palo Alto firewall",
  mrd_vpc_flow: "AWS VPC Flow Logs",
  mrd_payments_api: "Payments API",
  mrd_k8s_prod: "Kubernetes prod"
};
var HUMANIZE_DICTIONARY = {
  win: "Windows",
  fw: "firewall",
  k8s: "Kubernetes",
  agg: "aggregation",
  dedupe: "duplicate suppression",
  trim: "trimming",
  sample: "sampling",
  pay: "Payments",
  api: "API",
  dc: "DC",
  pan: "Palo Alto",
  vpc: "VPC",
  siem: "SIEM",
  s3: "S3",
  devnull: "DevNull",
  // Cribl's built-in destination, spelled as the Ledger and Cribl's own UI spell it
  xml: "XML",
  json: "JSON",
  ocsf: "OCSF",
  to: "to",
  for: "for",
  cdn: "CDN",
  docs: "docs",
  reduce: "reduction",
  noise: "noise filter",
  prod: "prod"
};
function stripPrefix(id) {
  return id.replace(/^mrd?_/i, "");
}
function packLabel(packId) {
  const words = packId.replace(/^(?:cribl|cc)[-_]/i, "").split(/[_\-\s]+/).filter((t) => t.length > 0).map((t) => HUMANIZE_DICTIONARY[t.toLowerCase()] ?? t[0].toUpperCase() + t.slice(1));
  return words.length > 0 ? `${words.join(" ")} pack` : packId;
}
function capitalizeFirst(s) {
  return s.length === 0 ? s : s[0].toUpperCase() + s.slice(1);
}
function humanize(id, overrides) {
  if (typeof id !== "string" || id.length === 0)
    return "";
  const stripped = stripPrefix(id);
  const override = overrides?.[id] ?? overrides?.[stripped];
  if (override !== void 0 && override.trim() !== "")
    return override;
  const demo = DEMO_LABELS[id];
  if (demo !== void 0)
    return demo;
  const pack = /^pack:(.+)$/i.exec(id);
  if (pack)
    return packLabel(pack[1]);
  const tokens = (stripped || id).split(/[_\-\s]+/).filter((t) => t.length > 0).map((t) => HUMANIZE_DICTIONARY[t.toLowerCase()] ?? t);
  if (tokens.length === 0)
    return id;
  return capitalizeFirst(tokens.join(" "));
}
function displayAuthor(author) {
  const a = typeof author === "string" ? author.trim() : "";
  if (a === "")
    return "unknown";
  const client = /^([^@\s]+)@clients$/i.exec(a);
  if (client) {
    const id = client[1].replace(/[^A-Za-z0-9]/g, "");
    return id.length >= 12 ? `API client \xB7\xB7${id.slice(-4)}` : "API client";
  }
  return a;
}

// core/baseline.ts
function emptyBaseline() {
  return { mean: 0, variance: 0, samples: 0, warm: [] };
}
function isWarm(b, warmupSamples) {
  return (b?.samples ?? 0) >= Math.max(1, warmupSamples);
}
function sigma(b) {
  return Math.sqrt(Math.max(0, b?.variance ?? 0));
}
function updateBaseline(b, x, alpha, warmupSamples) {
  const base = b ?? emptyBaseline();
  if (!Number.isFinite(x))
    return base;
  const w = Math.max(1, Math.floor(warmupSamples));
  if (base.samples < w) {
    const warm = [...base.warm ?? [], x];
    const n = warm.length;
    const mean2 = warm.reduce((s, v) => s + v, 0) / n;
    const variance2 = n >= 2 ? warm.reduce((s, v) => s + (v - mean2) ** 2, 0) / (n - 1) : 0;
    const samples = base.samples + 1;
    return { mean: mean2, variance: variance2, samples, warm: samples >= w ? [] : warm };
  }
  const a = Math.min(1, Math.max(0, alpha));
  const diff = x - base.mean;
  const mean = base.mean + a * diff;
  const variance = (1 - a) * (base.variance + a * diff * diff);
  return { mean, variance, samples: base.samples + 1, warm: [] };
}

// core/incidents.ts
var MAX_INCIDENTS = 500;
var INCIDENTS_PREFIX = "incidents/";
var RECOVERY_POINTS = 5;
var SEVERITY_RANK = { info: 0, medium: 1, high: 2 };
function severityRank(s) {
  return s === void 0 ? -1 : SEVERITY_RANK[s] ?? -1;
}
function fnv1a2(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function incidentId(type, objectKey2, openedAtMs) {
  const h = fnv1a2(`${type}|${objectKey2}|${Math.round(openedAtMs)}`);
  return `inc_${(h & 16777215).toString(16).padStart(6, "0")}`;
}
function incidentsDocKey(ms) {
  return `${INCIDENTS_PREFIX}${utcDayKey(ms)}`;
}
function titleFor(incident) {
  switch (incident.type) {
    case "regression":
      return `Savings dropped: ${incident.label}`;
    case "spike":
      return `Cost spike: ${incident.label}`;
    case "budget":
      return `Over budget pace: ${incident.label}`;
    case "goodnews":
      return `Savings improved: ${incident.label}`;
    default:
      return incident.label;
  }
}
function isOpen(i) {
  return !i.closedAt;
}
function incidentReadings(inc) {
  const { before, after } = inc;
  if (!inc.closedAt || inc.type === "goodnews")
    return { before, after, legacy: false };
  if (inc.recoveredTo !== void 0)
    return { before, after, recoveredTo: inc.recoveredTo, legacy: false };
  const recoveredSide = inc.type === "regression" ? (before - after) * 100 <= RECOVERY_POINTS : after < before;
  if (!recoveredSide)
    return { before, after, legacy: false };
  return { before, recoveredTo: after, legacy: true };
}
function shouldNotify(incident, endpoint, nowMs, cooldownMinutes, prevSeverity) {
  if (!endpoint.enabled)
    return false;
  if (severityRank(incident.severity) < severityRank(endpoint.minSeverity ?? "medium"))
    return false;
  if (!incident.lastNotifiedAt)
    return true;
  if (incident.closedAt)
    return true;
  if (prevSeverity !== void 0 && severityRank(incident.severity) > severityRank(prevSeverity))
    return true;
  const last = fromIso(incident.lastNotifiedAt);
  return Number.isNaN(last) || nowMs - last >= cooldownMinutes * 6e4;
}
function recency(i) {
  const t = fromIso(i.closedAt ?? i.openedAt);
  return Number.isNaN(t) ? 0 : t;
}
function mergeIncidentUpdates(docItems, opened, updated, closed) {
  const byId3 = /* @__PURE__ */ new Map();
  for (const i of docItems ?? [])
    byId3.set(i.id, i);
  for (const i of [...opened, ...updated, ...closed])
    byId3.set(i.id, i);
  let items2 = [...byId3.values()];
  if (items2.length > MAX_INCIDENTS) {
    const drop = items2.slice().sort((a, b) => Number(isOpen(a)) - Number(isOpen(b)) || recency(a) - recency(b)).slice(0, items2.length - MAX_INCIDENTS);
    const dropIds = new Set(drop.map((i) => i.id));
    items2 = items2.filter((i) => !dropIds.has(i.id));
  }
  return items2.sort((a, b) => fromIso(b.openedAt) - fromIso(a.openedAt) || (a.id < b.id ? -1 : 1));
}
var MEMBER_MUTE_MS = 24 * 60 * 6e4;

// core/rollups.ts
var MAX_MINUTE_ROWS = 60;
var MAX_HOUR_ROWS = 24;
var MAX_DAY_ROWS = 31;
var MINUTE_PREFIX = "roll/min/";
var HOUR_PREFIX = "roll/hour/";
var DAY_PREFIX = "roll/day/";
function minuteDocKey(ms) {
  return `${MINUTE_PREFIX}${utcHourKey(ms)}`;
}
function hourDocKey(ms) {
  return `${HOUR_PREFIX}${utcDayKey(ms)}`;
}
function dayDocKey(ms) {
  return `${DAY_PREFIX}${utcMonthKey(ms)}`;
}
function emptyMinuteDoc(bucketStartIso) {
  return { schemaVersion: 1, bucketStart: bucketStartIso, flows: {} };
}
function upsertSorted(rows, row, cap) {
  const out = (rows ?? []).filter((r) => r.t !== row.t);
  const tRow = fromIso(row.t);
  let i = out.length;
  while (i > 0 && fromIso(out[i - 1].t) > tRow)
    i--;
  out.splice(i, 0, row);
  return out.length > cap ? out.slice(out.length - cap) : out;
}
function upsertMinuteRows(doc, bucketStartIso, rows) {
  const base = doc ?? emptyMinuteDoc(bucketStartIso);
  const flows = { ...base.flows };
  for (const [key, row] of Object.entries(rows))
    flows[key] = upsertSorted(flows[key], row, MAX_MINUTE_ROWS);
  return { ...base, flows };
}
function foldHourRows(minuteDoc) {
  const out = {};
  const t = minuteDoc.bucketStart;
  for (const [key, rows] of Object.entries(minuteDoc.flows)) {
    const h = { t, inB: 0, outB: 0, whpM: 0, paidM: 0, savedM: 0, samples: 0 };
    for (const r of rows) {
      h.inB += r.inB;
      h.outB += r.outB;
      h.whpM += r.whpM;
      h.paidM += r.paidM;
      h.savedM += r.savedM;
      h.samples += 1;
    }
    out[key] = h;
  }
  return out;
}
function upsertHourRows(hourDoc, dayKey, rows) {
  const base = hourDoc ?? { schemaVersion: 1, day: dayKey, flows: {} };
  const flows = { ...base.flows };
  for (const [key, row] of Object.entries(rows))
    flows[key] = upsertSorted(flows[key], row, MAX_HOUR_ROWS);
  return { ...base, flows };
}
function foldDayRows(hourDoc) {
  const out = {};
  const t = `${hourDoc.day}T00:00:00.000Z`;
  for (const [key, rows] of Object.entries(hourDoc.flows)) {
    const d = { t, inB: 0, outB: 0, whpM: 0, paidM: 0, savedM: 0 };
    for (const r of rows) {
      d.inB += r.inB;
      d.outB += r.outB;
      d.whpM += r.whpM;
      d.paidM += r.paidM;
      d.savedM += r.savedM;
    }
    out[key] = d;
  }
  return out;
}
function upsertDayRows(dayDoc, monthKey, rows) {
  const base = dayDoc ?? { schemaVersion: 1, month: monthKey, flows: {} };
  const flows = { ...base.flows };
  for (const [key, row] of Object.entries(rows))
    flows[key] = upsertSorted(flows[key], row, MAX_DAY_ROWS);
  return { ...base, flows };
}
var MIN_KEY = /^roll\/min\/(\d{4}-\d{2}-\d{2}T\d{2})$/;
var HOUR_KEY = /^roll\/hour\/(\d{4}-\d{2}-\d{2})$/;
var DAY_KEY = /^roll\/day\/(\d{4})-(\d{2})$/;
var INCIDENT_KEY = /^incidents\/(\d{4}-\d{2}-\d{2})$/;
function expiredKeys(allKeys, nowMs) {
  const out = [];
  const now = new Date(nowMs);
  const nowMonthIndex = now.getUTCFullYear() * 12 + now.getUTCMonth();
  for (const key of allKeys) {
    let m = MIN_KEY.exec(key);
    if (m) {
      const start = fromIso(`${m[1]}:00:00.000Z`);
      if (nowMs - start > 25 * HOUR_MS)
        out.push(key);
      continue;
    }
    m = HOUR_KEY.exec(key);
    if (m) {
      if (nowMs - fromIso(`${m[1]}T00:00:00.000Z`) > 32 * DAY_MS)
        out.push(key);
      continue;
    }
    m = DAY_KEY.exec(key);
    if (m) {
      const idx = Number(m[1]) * 12 + (Number(m[2]) - 1);
      if (nowMonthIndex - idx >= 13)
        out.push(key);
      continue;
    }
    m = INCIDENT_KEY.exec(key);
    if (m && nowMs - fromIso(`${m[1]}T00:00:00.000Z`) > 31 * DAY_MS)
      out.push(key);
  }
  return out;
}
function emptyTotals(nowIso) {
  return { schemaVersion: 1, updatedAt: nowIso, byDay: {} };
}
function addMinuteToTotals(totals, localDay, row, replacedRow, nowIso) {
  const base = totals ?? emptyTotals(nowIso ?? row.t ?? "");
  const prev = base.byDay[localDay] ?? { whpM: 0, paidM: 0, savedM: 0, minutes: 0 };
  const next = {
    whpM: prev.whpM + row.whpM - (replacedRow?.whpM ?? 0),
    paidM: prev.paidM + row.paidM - (replacedRow?.paidM ?? 0),
    savedM: prev.savedM + row.savedM - (replacedRow?.savedM ?? 0),
    minutes: prev.minutes + (replacedRow ? 0 : 1)
  };
  return { ...base, updatedAt: nowIso ?? base.updatedAt, byDay: { ...base.byDay, [localDay]: next } };
}
function addOutputMinuteToTotals(totals, localMonth, outputKey, row, replacedRow) {
  const base = totals ?? emptyTotals("");
  const months = { ...base.byOutputMonth ?? {} };
  const month = { ...months[localMonth] ?? {} };
  const prev = month[outputKey] ?? { whpM: 0, paidM: 0, savedM: 0 };
  month[outputKey] = {
    whpM: prev.whpM + row.whpM - (replacedRow?.whpM ?? 0),
    paidM: prev.paidM + row.paidM - (replacedRow?.paidM ?? 0),
    savedM: prev.savedM + row.savedM - (replacedRow?.savedM ?? 0)
  };
  months[localMonth] = month;
  return { ...base, byOutputMonth: months };
}
function outputMonthTotals(totals, localMonth, outputKey) {
  return totals?.byOutputMonth?.[localMonth]?.[outputKey] ?? { whpM: 0, paidM: 0, savedM: 0 };
}
function pruneTotals(totals, keepDays = 400) {
  const days = Object.keys(totals.byDay).sort().reverse();
  const out = { ...totals, byDay: {} };
  for (const k of days.slice(0, Math.max(0, keepDays)))
    out.byDay[k] = totals.byDay[k];
  if (totals.byOutputMonth) {
    const months = Object.keys(totals.byOutputMonth).sort().reverse().slice(0, 13);
    out.byOutputMonth = {};
    for (const m of months)
      out.byOutputMonth[m] = totals.byOutputMonth[m];
  }
  return out;
}
function poolMinuteRows(lists) {
  const byMinute = /* @__PURE__ */ new Map();
  for (const rows of lists) {
    for (const r of rows ?? []) {
      const acc = byMinute.get(r.t);
      if (!acc) {
        byMinute.set(r.t, { ...r });
        continue;
      }
      acc.inB += r.inB;
      acc.outB += r.outB;
      acc.inE += r.inE;
      acc.outE += r.outE;
      acc.whpM += r.whpM;
      acc.paidM += r.paidM;
      acc.savedM += r.savedM;
    }
  }
  return [...byMinute.values()].sort((a, b) => fromIso(a.t) - fromIso(b.t));
}
function mergeRowsByFlow(docs) {
  const out = {};
  for (const d of docs) {
    if (!d)
      continue;
    for (const [key, rows] of Object.entries(d.flows))
      (out[key] ??= []).push(...rows);
  }
  for (const rows of Object.values(out))
    rows.sort((a, b) => fromIso(a.t) - fromIso(b.t));
  return out;
}
function sparkline(rows, points, metric = "ratio") {
  const n = Math.max(0, Math.floor(points));
  if (n === 0 || rows.length === 0)
    return [];
  const sorted = [...rows].sort((a, b) => fromIso(a.t) - fromIso(b.t));
  const buckets = Math.min(n, sorted.length);
  const out = [];
  for (let b = 0; b < buckets; b++) {
    const from = Math.floor(b * sorted.length / buckets);
    const to = Math.floor((b + 1) * sorted.length / buckets);
    let whp = 0;
    let saved = 0;
    for (let i = from; i < to; i++) {
      whp += sorted[i].whpM;
      saved += sorted[i].savedM;
    }
    out.push(metric === "savedM" ? saved : ratio(saved, whp));
  }
  return out;
}

// core/range.ts
var RELATIVE_PRESETS = [
  { key: "1h", hours: 1 },
  { key: "6h", hours: 6 },
  { key: "24h", hours: 24 },
  { key: "7d", hours: 7 * 24 },
  { key: "30d", hours: 30 * 24 }
];
var MINUTE_REACH_MS = 24 * HOUR_MS;
var HOUR_REACH_MS = 31 * DAY_MS;
var DOC_CAPS = { minute: 26, hour: 33, day: 14 };
var WEEK_MS = 7 * DAY_MS;
var COMMIT_COMPARE_MS = 24 * HOUR_MS;
var COMPARE_DOC_CAP = Math.max(...Object.values(DOC_CAPS));

// core/strings.ts
function fill(template, values = {}) {
  return template.replace(/\{(\w+)\}/g, (m, k) => k in values ? String(values[k]) : m);
}
function plural(n, forms) {
  return n === 1 ? forms.one : forms.other;
}
var RECEIPT_STRINGS = {
  weeklyTitle: "Meter Reader \u2014 weekly receipt",
  periodTitle: "Meter Reader \u2014 receipt",
  savedLastWeek: "Saved by Cribl, last week",
  savedFor: "Saved by Cribl, {period}",
  saved: "Saved by Cribl",
  wouldHavePaid: "Would have paid {amount}",
  paid: "Paid {amount}",
  savedPct: "{pct} saved",
  vs: "vs. {what}: {sign}{pct}%",
  priorWeek: "prior week",
  openAlertsNone: "Open alerts: none",
  openAlertsList: "Open alerts: {n} ({titles})",
  openAlertsCount: "Open alerts: {n}",
  openThisWeek: "Open this week on the Receipt:",
  /** WeeklyReceipt.sentLate: nothing was metering at Monday 12:00 UTC, so the week's first sweep sent it. */
  sentLate: "Sent late: nothing was metering at Monday 12:00 UTC, so it went out with the first metering since.",
  /** a flow with no pipeline and no route */
  otherLine: "Other",
  topSaversRates: "Top savers, per day at current rates",
  perDaySuffix: "/day",
  netAfterCribl: "Net after Cribl {amount}",
  netAfterCriblYear: "Net after Cribl {amount} a year",
  paidForItself: "Paid for itself {multiple}",
  annualizedFrom: "annualized from {basis}",
  lastDays: { one: "the last {n} day", other: "the last {n} days" },
  todaySoFar: "today so far",
  asOf: "as of {date}",
  rangeRate: "\u2248 {amount} a day at this rate",
  periods: {
    mtd: "month to date",
    today: "today",
    "30d": "last 30 days",
    annualized: "annualized run rate"
  },
  // P1-F02: measured (bytes dropped) vs assumed (credited at another destination's price).
  divertedTag: " (diverted)",
  byReduction: "Saved by reduction {amount}",
  byDiversion: "by diversion {amount}",
  // P0-23: the Basis block.
  basis: "Basis",
  basisPrice: "{label}: {price}",
  typicalList: "typical list",
  presetTypicalList: "{preset} typical list",
  customPrice: "custom price",
  creditedUnpriced: "credited $0 until {label} has a price",
  creditedAt: "credited at {label}'s {price}",
  neverSavings: "never counted as savings",
  morePriced: { one: "and {n} more priced destination", other: "and {n} more priced destinations" },
  noMoney: "No destination carried money",
  unpricedExcluded: { one: "{n} destination unpriced, excluded", other: "{n} destinations unpriced, excluded" },
  metered: "Metered {metered} of {expected} {unit} ({pct})",
  meteredUnder1: "under 1%",
  units: { minute: "minute", minutes: "minutes", day: "day", days: "days" },
  // P2-W13: Copy receipt for a comparison (receiptTextForComparison).
  comparisonTitle: "Meter Reader \u2014 receipt comparison",
  thisRange: "This range",
  comparedPerDay: "Compared per day, at each window's own rate:",
  comparedPerDayWhy: "they were metered for different lengths.",
  aDaySuffix: " a day",
  nothingToCompare: "Nothing was metered to compare with.",
  // A comparison window with nothing metered: its money is unknown, never $0 (review W2, P0-18's class).
  notMetered: "not metered",
  change: "Change",
  windowWouldHavePaid: "{name}: would have paid {amount}",
  windowPaid: "  paid {amount} \xB7 {pct} saved"
};
var PAYLOAD_STRINGS = {
  testTitle: "Meter Reader test notification",
  eventTitle: "Meter Reader {event}",
  testPrefix: "Test: ",
  recoveredPrefix: "Recovered: ",
  newNormalPrefix: "New normal: ",
  closedPrefix: "Closed: ",
  // P1-F07: what a member did with it.
  memberClosed: {
    accepted: "Accepted as the new normal: ",
    muted: "Muted: ",
    excluded: "Alerts stopped: "
  },
  closedBy: " by {by}",
  closedAsNewNormal: "Closed as the new normal",
  recovered: "Recovered",
  weeklyFallback: "{glyph} Meter Reader weekly receipt \xB7 {label} \xB7 Saved by Cribl {amount}",
  weeklyHeader: "{glyph} Weekly receipt \xB7 {label}",
  openReceipt: "Open the Receipt",
  openLedger: "Open in Ledger",
  openLedgerAt: "Open in Ledger: {link}",
  incidentFallback: "{glyph} {title} \xB7 {money}",
  // The money line of every alert channel (the bell, a notification target, Slack, ServiceNow), worded by the rule the
  // incident card follows (src/copy/en.ts incidents.impact, D62; rules round 2 carried it to the channels): only an
  // open regression is projected to a year, as what it costs if left; a spike is a day while it lasts; a recovered
  // incident is a day while it lasted, for how long and what it came to; good news keeps its year; budget pace, none.
  impact: {
    open: "{perDay} a day \xB7 {perYear} a year if left",
    spike: "{perDay} a day above normal while it lasts",
    closed: "{perDay} a day above normal while it lasted \xB7 {duration} \xB7 \u2248 {realized} in all",
    closedNoDuration: "{perDay} a day above normal while it lasted",
    perDayPerYear: "{perDay} a day \xB7 {perYear} a year",
    overBudget: "{perDay} a day over budget"
  },
  demoProfile: " \xB7 1-minute confirmation (demo profile). Default is 3.",
  noChange: "No configuration change found nearby",
  nearby: " (nearby change; it may not be the cause)",
  perHour: "{amount}/hour",
  pctOfBudget: "{pct}% of budget",
  caughtIn: "caught in {duration}",
  caughtOnCatchUp: "caught on catch-up",
  caughtOnCatchUpAfter: "caught on catch-up, {duration} after the change",
  // The Slack field grid.
  fields: {
    commit: "Commit",
    by: "By",
    openFor: "Open for",
    extraPerDay: "Extra per day",
    wasCostingExtra: "Was costing extra per day",
    perYear: "Per year",
    perYearIfLeft: "Per year if left",
    lostWhileOpen: "Lost while open",
    costWhileOpen: "Extra cost while open",
    baseline: "Baseline",
    peak: "Peak",
    now: "Now",
    overBudgetPerDay: "Over budget per day",
    peakProjection: "Peak projection",
    projected: "Projected",
    threshold: "Threshold",
    savingPerDay: "Saving per day",
    before: "Before",
    after: "After",
    lostPerDay: "Lost per day",
    wasLosingPerDay: "Was losing per day",
    recoveredTo: "Recovered to"
  },
  // The plain-text alert (ServiceNow's description, logs).
  plain: {
    ratio: "Savings ratio {drop}{back} \xB7 {money}",
    cost: "Cost {rise}{back} \xB7 {money}",
    budget: "{pace}{back} \xB7 {perDay} a day over",
    before: "{value} before",
    recoveredTo: " \xB7 recovered to {value}",
    projected: "Projected {value}",
    threshold: "Threshold {pct}%",
    commit: 'Commit {hash} "{message}" by {author}',
    opened: "Opened {at}",
    closed: " \xB7 {closed} {at}"
  },
  servicenowWeekly: "Meter Reader weekly receipt {label}",
  // "Send a test alert": the SPEC 12.1 example incident every test payload carries.
  testSample: {
    label: "Payments API sampling",
    commitMessage: "demo: break the trim on mrd_pay_sample"
  }
};
var CREDIT_STRINGS = {
  builder: "Steve Koelpin",
  /** The sign-off on a receipt and on an alert message. */
  signature: "Meter Reader by Steve Koelpin"
};

// core/receipt.ts
var RECEIPT_WIDTH = 48;
var RECEIPT_MAX_BASIS_PRICES = 8;
var MIN_LEADER_DOTS = 4;
var perGb = (mc) => `$${mcToDollarInput(mc)}/GB`;
var int = (n) => Math.round(n).toLocaleString("en-US");
function wrapWords(text, width = RECEIPT_WIDTH, indent = "  ") {
  const out = [];
  let line = "";
  for (const word of text.split(" ").filter(Boolean)) {
    const lead = out.length === 0 ? "" : indent;
    if (line === "")
      line = `${lead}${word}`;
    else if (line.length + 1 + word.length <= width)
      line += ` ${word}`;
    else {
      out.push(line);
      line = `${indent}${word}`;
    }
  }
  if (line !== "")
    out.push(line);
  return out.map((l) => truncate(l, width));
}
function namesPreset(label, presetLabel) {
  const a = label.trim().toLowerCase();
  const b = presetLabel.trim().toLowerCase();
  return a.length > 0 && (a === b || b.startsWith(`${a} `) || a.startsWith(`${b} `));
}
function basisPriceText(p) {
  const preset = p.source === "preset" && p.presetLabel ? namesPreset(p.label, p.presetLabel) ? RECEIPT_STRINGS.typicalList : fill(RECEIPT_STRINGS.presetTypicalList, { preset: p.presetLabel }) : void 0;
  const source = preset ? `, ${preset}` : p.source === "custom" ? `, ${RECEIPT_STRINGS.customPrice}` : "";
  let text = `${fill(RECEIPT_STRINGS.basisPrice, { label: p.label, price: perGb(p.milliCentsPerGb) })}${source}`;
  if (p.creditedAt) {
    const c = p.creditedAt;
    const amount = c.whpM !== void 0 ? `: ${fmtDollars(c.whpM)}` : "";
    text += c.unpriced ? `; ${fill(RECEIPT_STRINGS.creditedUnpriced, { label: c.label })}` : `; ${fill(RECEIPT_STRINGS.creditedAt, { label: c.label, price: perGb(c.milliCentsPerGb) })}${amount}`;
  } else if (p.noSavings)
    text += `; ${RECEIPT_STRINGS.neverSavings}`;
  return text;
}
function coverageLine(c) {
  const metered = Math.min(Math.max(0, c.metered), c.expected);
  const floorPct = Math.floor(metered / c.expected * 100);
  const pct = metered >= c.expected ? fmtPct(1) : metered > 0 && floorPct === 0 ? RECEIPT_STRINGS.meteredUnder1 : fmtPct(floorPct / 100);
  const unit = c.unit === "days" ? plural(c.expected, { one: RECEIPT_STRINGS.units.day, other: RECEIPT_STRINGS.units.days }) : plural(c.expected, { one: RECEIPT_STRINGS.units.minute, other: RECEIPT_STRINGS.units.minutes });
  return fill(RECEIPT_STRINGS.metered, { metered: int(metered), expected: int(c.expected), unit, pct });
}
function basisBlock(b) {
  const out = ["", RECEIPT_STRINGS.basis];
  const shown = b.prices.slice(0, RECEIPT_MAX_BASIS_PRICES);
  for (const p of shown)
    out.push(...wrapWords(basisPriceText(p)));
  const more = b.prices.length - shown.length;
  if (more > 0)
    out.push(fill(plural(more, RECEIPT_STRINGS.morePriced), { n: more }));
  if (b.prices.length === 0)
    out.push(RECEIPT_STRINGS.noMoney);
  if (b.unpricedCount > 0)
    out.push(fill(plural(b.unpricedCount, RECEIPT_STRINGS.unpricedExcluded), { n: b.unpricedCount }));
  if (b.coverage)
    out.push(coverageLine(b.coverage));
  return out;
}
function truncate(s, max) {
  if (max <= 0)
    return "";
  return s.length <= max ? s : `${s.slice(0, Math.max(0, max - 1))}\u2026`;
}
function wrapSegments(segments, width = RECEIPT_WIDTH) {
  const out = [];
  let line = "";
  for (const seg3 of segments) {
    if (line === "")
      line = seg3;
    else if (line.length + 3 + seg3.length <= width)
      line += ` \xB7 ${seg3}`;
    else {
      out.push(line);
      line = seg3;
    }
  }
  if (line !== "")
    out.push(line);
  return out.map((l) => truncate(l, width));
}
function alertLines(alerts, width = RECEIPT_WIDTH) {
  if (alerts.length === 0)
    return [RECEIPT_STRINGS.openAlertsNone];
  const one = fill(RECEIPT_STRINGS.openAlertsList, { n: alerts.length, titles: alerts.map((a) => a.title).join("; ") });
  if (one.length <= width)
    return [one];
  return [fill(RECEIPT_STRINGS.openAlertsCount, { n: alerts.length }), ...alerts.map((a) => truncate(`  ${a.title}`, width))];
}
function receiptSignOff(width = RECEIPT_WIDTH) {
  const sig = CREDIT_STRINGS.signature;
  return ["", `${" ".repeat(Math.max(0, Math.floor((width - sig.length) / 2)))}${sig}`];
}
function spread(left, right, width = RECEIPT_WIDTH) {
  const gap = width - left.length - right.length;
  if (gap >= 2)
    return [`${left}${" ".repeat(gap)}${right}`];
  return [truncate(left, width), right.padStart(width)];
}
function renderReceipt(b) {
  const suffix = b.lineSuffix ?? "";
  const amounts = [...b.lines.map((l) => `${fmtDollars(l.savedM)}${suffix}`), fmtDollars(b.savedM)];
  const field2 = Math.max(8, ...amounts.map((a) => a.length + 2));
  const out = [...spread(b.title, b.rangeLabel)];
  if (b.linesHeader && b.lines.length > 0)
    out.push(truncate(b.linesHeader, RECEIPT_WIDTH));
  for (const l of b.lines) {
    const amount = `${fmtDollars(l.savedM)}${suffix}`.padStart(field2);
    const room = RECEIPT_WIDTH - field2 - 1 - MIN_LEADER_DOTS;
    const tag = l.diverted ? DIVERTED_TAG : "";
    const label = `${truncate(l.label, room - tag.length)}${tag}`;
    const dots = RECEIPT_WIDTH - label.length - 1 - field2;
    out.push(`${label} ${".".repeat(dots)}${amount}`);
  }
  out.push("-".repeat(RECEIPT_WIDTH));
  out.push(...spread(b.totalLabel, fmtDollars(b.savedM)));
  out.push(...wrapSegments(b.summary));
  if (b.divertedM !== void 0 && b.divertedM > 0)
    out.push(...wrapSegments(splitSegments(b.savedM, b.divertedM)));
  if (b.net && b.net.length > 0)
    out.push(...wrapSegments(b.net));
  if (b.trend)
    out.push(b.trend);
  if (b.note)
    out.push(...wrapWords(b.note, RECEIPT_WIDTH, ""));
  out.push(...alertLines(b.openAlerts));
  if (b.basis)
    out.push(...basisBlock(b.basis));
  if (b.link)
    out.push("", RECEIPT_STRINGS.openThisWeek, b.link);
  out.push(...receiptSignOff());
  return out.join("\n");
}
var DIVERTED_TAG = RECEIPT_STRINGS.divertedTag;
function splitSegments(savedM, divertedM) {
  const d = Math.min(Math.max(0, divertedM), Math.max(0, savedM));
  const shown = footMoney({ whpM: savedM, paidM: savedM - d, savedM: d });
  return [fill(RECEIPT_STRINGS.byReduction, { amount: fmtDollars(shown.paidM) }), fill(RECEIPT_STRINGS.byDiversion, { amount: fmtDollars(shown.savedM) })];
}
function summarySegments(whpM, paidM, savedM, r) {
  const shown = footMoney({ whpM, paidM, savedM });
  return [fill(RECEIPT_STRINGS.wouldHavePaid, { amount: fmtDollars(shown.whpM) }), fill(RECEIPT_STRINGS.paid, { amount: fmtDollars(shown.paidM) }), fill(RECEIPT_STRINGS.savedPct, { pct: fmtPct(r) })];
}
function trendLine(trendPct, what) {
  if (trendPct === void 0)
    return void 0;
  const sign = trendPct > 0 ? "+" : trendPct < 0 ? "\u2212" : "";
  return fill(RECEIPT_STRINGS.vs, { what, sign, pct: Math.abs(trendPct) });
}
function receiptText(r) {
  return renderReceipt({
    title: RECEIPT_STRINGS.weeklyTitle,
    rangeLabel: r.label,
    lines: r.lines,
    totalLabel: RECEIPT_STRINGS.savedLastWeek,
    savedM: r.savedM,
    summary: summarySegments(r.whpM, r.paidM, r.savedM, r.ratio),
    ...r.divertedM !== void 0 ? { divertedM: r.divertedM } : {},
    trend: trendLine(r.trendPct, RECEIPT_STRINGS.priorWeek),
    ...r.sentLate ? { note: RECEIPT_STRINGS.sentLate } : {},
    openAlerts: r.openIncidents,
    ...r.basis ? { basis: r.basis } : {},
    ...r.link ? { link: r.link } : {}
  });
}
var PERIOD_CAPTIONS = RECEIPT_STRINGS.periods;

// core/detector.ts
var DEMO_PROFILE_NOTE = "demo-profile";
var BUDGET_INTERVAL_MS = 60 * MINUTE_MS;
var SPIKE_SIGMA_FLOOR_SHARE = 0.15;
var SPIKE_SIGMA_FLOOR_M = 1e5;
var SPIKE_OPEN_WEIGHT = 0.25;
var SPIKE_NEW_NORMAL_MINUTES = 60;
var SPIKE_LEVEL_BAND = 0.1;
var SPIKE_LEVEL_MISSES = 3;
var SPIKE_HIGH_MULTIPLE = 2;
var SPIKE_REPEAT_MS = 24 * 60 * MINUTE_MS;
var NEW_NORMAL_NOTE = "new-normal";
function spikeSigma(b, mean = b?.mean ?? 0) {
  return Math.max(sigma(b), SPIKE_SIGMA_FLOOR_SHARE * Math.abs(mean), SPIKE_SIGMA_FLOOR_M);
}
function isDemoProfile(settings) {
  return settings.demo?.enabled === true && settings.demo?.profile === true;
}
var DEFAULT_REGRESSION_MIN_CENTS_PER_DAY = 500;
function effectiveThresholds(settings) {
  const t = { ...settings.thresholds };
  if (isDemoProfile(settings)) {
    t.regressionMinutes = 1;
    t.spikeMinutes = 1;
    t.recoveryMinutes = 1;
  }
  return t;
}
function shouldEvaluateBudget(baselines, nowMs, settings) {
  if (isDemoProfile(settings))
    return true;
  const last = baselines?.budgetEvaluatedAt ? fromIso(baselines.budgetEvaluatedAt) : Number.NaN;
  return Number.isNaN(last) || nowMs - last >= BUDGET_INTERVAL_MS;
}
function emptyBaselines(nowIso) {
  return { schemaVersion: 1, updatedAt: nowIso, byObject: {}, rules: {} };
}
function objectContext(key, inventory) {
  const p = parseObjectKey(key);
  if (!p)
    return {};
  const routes2 = inventory?.byGroup?.[p.groupId]?.routes ?? [];
  if (p.kind === "route") {
    const r = routes2.find((x) => x.id === p.id);
    return {
      routeId: p.id,
      pipelineId: r?.pipeline,
      ...typeof r?.name === "string" ? { routeName: r.name } : {},
      ...typeof r?.filter === "string" ? { routeFilter: r.filter } : {}
    };
  }
  if (p.kind === "pipe")
    return { pipelineId: p.id, routeId: routes2.find((r) => r.pipeline === p.id)?.id };
  return {};
}
var clamp01 = (x) => Math.min(1, Math.max(0, x));
var round1 = (x) => Math.round(x * 10) / 10;
var secondsBetween = (fromMs, toMs) => Math.max(0, Math.round((toMs - fromMs) / 1e3));
function detect(input) {
  const { settings, nowMs } = input;
  const th = effectiveThresholds(settings);
  const demoProfile = isDemoProfile(settings);
  const nowIso = toIso(nowMs);
  const minuteStart = input.minuteStartMs ?? minuteFloor(nowMs) - MINUTE_MS;
  const windowMs = th.regressionCommitWindowMin * MINUTE_MS;
  const notes = () => demoProfile ? [DEMO_PROFILE_NOTE] : [];
  const commits = input.commits ?? [];
  const byObject = { ...input.baselines?.byObject ?? {} };
  const rules = { ...input.baselines?.rules ?? {} };
  let budgetEvaluatedAt = input.baselines?.budgetEvaluatedAt;
  const open = /* @__PURE__ */ new Map();
  for (const i of input.openIncidents ?? [])
    if (!i.closedAt)
      open.set(`${i.type}|${i.objectKey}`, i);
  const excluded = new Set(settings.excludedObjectKeys ?? []);
  const memberMute = (key) => {
    const m = settings.mutes?.[key];
    return m && fromIso(m.until) > nowMs ? m : void 0;
  };
  const isMuted = (key) => {
    const until = input.muted?.[key];
    return until !== void 0 && fromIso(until) > nowMs || memberMute(key) !== void 0;
  };
  const opened = [];
  const updated = [];
  const closed = [];
  const unmatchedRegressions = [];
  const between = (openedAt) => {
    const at = openedAt ? fromIso(openedAt) : Number.NaN;
    return Number.isFinite(at) && nowMs - at < SPIKE_REPEAT_MS ? { streak: 0, recoveryStreak: 0, lastOpenedAt: openedAt } : void 0;
  };
  const setRule = (k, rs) => {
    if (rs)
      rules[k] = rs;
    else if (k in rules)
      delete rules[k];
  };
  for (const [k, inc] of [...open]) {
    const mute = excluded.has(inc.objectKey) ? void 0 : memberMute(inc.objectKey);
    if (!excluded.has(inc.objectKey) && !mute)
      continue;
    const reason = excluded.has(inc.objectKey) ? "excluded" : "muted";
    closed.push({ ...inc, closedAt: nowIso, closedReason: reason, ...mute?.by ? { closedBy: mute.by } : {} });
    open.delete(k);
    setRule(k, inc.type === "spike" ? between(inc.openedAt) : void 0);
  }
  const feed = (key, x) => {
    byObject[key] = updateBaseline(byObject[key] ?? emptyBaseline(), x, th.ewmaAlpha, th.warmupSamples);
  };
  const fresh = () => ({ streak: 0, recoveryStreak: 0 });
  if (input.learnOnly) {
    for (const [key, pt] of Object.entries(input.ratioSeries ?? {})) {
      if (excluded.has(key) || isMuted(key) || pt.x === null || !Number.isFinite(pt.x))
        continue;
      feed(key, clamp01(pt.x));
    }
    for (const [key, pt] of Object.entries(input.costSeries ?? {})) {
      if (excluded.has(key) || isMuted(key))
        continue;
      const x = Number.isFinite(pt.x) ? pt.x : 0;
      if (x > 0 || isWarm(byObject[key], th.warmupSamples))
        feed(key, x);
    }
    const learned = { schemaVersion: 1, updatedAt: nowIso, byObject, rules };
    if (budgetEvaluatedAt !== void 0)
      learned.budgetEvaluatedAt = budgetEvaluatedAt;
    return { baselines: learned, opened, updated, closed, unmatchedRegressions };
  }
  for (const [key, pt] of Object.entries(input.ratioSeries ?? {})) {
    if (excluded.has(key) || pt.x === null || !Number.isFinite(pt.x))
      continue;
    const x = clamp01(pt.x);
    const regKey = `regression|${key}`;
    const goodKey = `goodnews|${key}`;
    const openReg = open.get(regKey);
    if (openReg) {
      const rs2 = { ...rules[regKey] ?? fresh() };
      const baselineRatio = rs2.frozenBaseline ?? openReg.before;
      const floorM = (th.regressionMinCentsPerDay ?? DEFAULT_REGRESSION_MIN_CENTS_PER_DAY) * 1e3;
      const whpNow = pt.whpPerDayM || 0;
      const belowFloor = whpNow > 0 && (baselineRatio - x) * whpNow < floorM;
      const inBand = (baselineRatio - x) * 100 <= RECOVERY_POINTS;
      rs2.recoveryStreak = inBand || belowFloor ? rs2.recoveryStreak + 1 : 0;
      if (rs2.recoveryStreak >= th.recoveryMinutes) {
        closed.push(inBand ? { ...openReg, closedAt: nowIso, recoveredTo: x } : { ...openReg, closedAt: nowIso, notes: [...openReg.notes, "below-floor"] });
        delete rules[regKey];
      } else {
        rules[regKey] = rs2;
        if (x < openReg.after - 5e-3) {
          const impact = Math.max(openReg.impactPerDayM, Math.max(0, Math.round((baselineRatio - x) * whpNow)));
          updated.push({ ...openReg, after: x, impactPerDayM: impact });
        }
      }
      continue;
    }
    if (isMuted(key))
      continue;
    const b = byObject[key];
    if (!isWarm(b, th.warmupSamples)) {
      feed(key, x);
      continue;
    }
    const mean = b.mean;
    const ctx = objectContext(key, input.inventory);
    let counting = false;
    const rs = { ...rules[regKey] ?? fresh() };
    const regBase = rs.streak > 0 && rs.frozenBaseline !== void 0 ? rs.frozenBaseline : mean;
    const regMinM = (th.regressionMinCentsPerDay ?? DEFAULT_REGRESSION_MIN_CENTS_PER_DAY) * 1e3;
    const whpPerDay = pt.whpPerDayM || 0;
    const regQualifies = (regBase - x) * 100 >= th.regressionPoints && (whpPerDay <= 0 || (regBase - x) * whpPerDay >= regMinM);
    if (regQualifies) {
      counting = true;
      if (rs.streak === 0) {
        rs.frozenBaseline = mean;
        rs.firstQualifyingAt = toIso(minuteStart);
      }
      rs.streak += 1;
      if (rs.streak >= th.regressionMinutes) {
        const baselineRatio = rs.frozenBaseline ?? mean;
        const firstMs = fromIso(rs.firstQualifyingAt ?? toIso(minuteStart));
        const commit = matchCommit(commits, key, { sinceMs: firstMs - windowMs, untilMs: nowMs, ...ctx });
        const inc = {
          id: incidentId("regression", key, nowMs),
          type: "regression",
          severity: commit ? "high" : "medium",
          objectKey: key,
          label: pt.label,
          openedAt: nowIso,
          cause: commit ? "commit" : "unknown",
          before: baselineRatio,
          after: x,
          impactPerDayM: Math.max(0, Math.round((baselineRatio - x) * (pt.whpPerDayM || 0))),
          caughtInSec: commit ? secondsBetween(commitTimeMs(commit), nowMs) : secondsBetween(firstMs, nowMs),
          notes: notes(),
          deliveries: []
        };
        if (pt.outputId !== void 0)
          inc.outputId = pt.outputId;
        if (commit)
          inc.commit = commit;
        else
          unmatchedRegressions.push(inc.id);
        opened.push(inc);
        rules[regKey] = { streak: 0, recoveryStreak: 0, frozenBaseline: baselineRatio, firstQualifyingAt: rs.firstQualifyingAt };
      } else {
        rules[regKey] = rs;
      }
    } else if (rules[regKey]) {
      delete rules[regKey];
    }
    if (goodNewsActive(settings) && !regQualifies && !open.has(goodKey)) {
      const gs = { ...rules[goodKey] ?? fresh() };
      const goodBase = gs.streak > 0 && gs.frozenBaseline !== void 0 ? gs.frozenBaseline : mean;
      if ((x - goodBase) * 100 >= th.goodNewsPoints) {
        if (gs.streak === 0) {
          gs.frozenBaseline = mean;
          gs.firstQualifyingAt = toIso(minuteStart);
        }
        gs.streak += 1;
        counting = true;
        rules[goodKey] = gs;
        if (gs.streak >= th.regressionMinutes) {
          const firstMs = fromIso(gs.firstQualifyingAt ?? toIso(minuteStart));
          const commit = matchCommit(commits, key, { sinceMs: firstMs - windowMs, untilMs: nowMs, ...ctx });
          delete rules[goodKey];
          if (commit) {
            const before = gs.frozenBaseline ?? mean;
            const inc = {
              id: incidentId("goodnews", key, nowMs),
              type: "goodnews",
              severity: "info",
              objectKey: key,
              label: pt.label,
              openedAt: nowIso,
              closedAt: nowIso,
              cause: "commit",
              commit,
              before,
              after: x,
              impactPerDayM: Math.max(0, Math.round((x - before) * (pt.whpPerDayM || 0))),
              caughtInSec: secondsBetween(commitTimeMs(commit), nowMs),
              notes: notes(),
              deliveries: []
            };
            if (pt.outputId !== void 0)
              inc.outputId = pt.outputId;
            opened.push(inc);
            byObject[key] = emptyBaseline();
            continue;
          }
          counting = false;
        }
      } else if (rules[goodKey]) {
        delete rules[goodKey];
      }
    }
    if (!counting)
      feed(key, x);
  }
  const minDeltaM = th.spikeMinCentsPerHour * 1e3;
  const feedSlowly = (key, x) => {
    byObject[key] = updateBaseline(byObject[key] ?? emptyBaseline(), x, th.ewmaAlpha * SPIKE_OPEN_WEIGHT, th.warmupSamples);
  };
  for (const [key, pt] of Object.entries(input.costSeries ?? {})) {
    if (excluded.has(key))
      continue;
    const x = Number.isFinite(pt.x) ? pt.x : 0;
    const spikeKey = `spike|${key}`;
    const b = byObject[key];
    const openSpike = open.get(spikeKey);
    if (openSpike) {
      const rs = { ...rules[spikeKey] ?? fresh() };
      const before = rs.frozenBaseline ?? openSpike.before;
      const muted = isMuted(key);
      rs.recoveryStreak = x <= before + spikeSigma(b, before) ? rs.recoveryStreak + 1 : 0;
      if (rs.recoveryStreak >= th.recoveryMinutes) {
        closed.push({ ...openSpike, closedAt: nowIso, recoveredTo: x });
        setRule(spikeKey, between(openSpike.openedAt));
        if (!muted)
          feedSlowly(key, x);
        continue;
      }
      const band = (level) => Math.max(SPIKE_LEVEL_BAND * Math.abs(level), SPIKE_SIGMA_FLOOR_M);
      if (rs.level === void 0 || !(rs.levelMinutes && rs.levelMinutes > 0)) {
        rs.level = x;
        rs.levelMinutes = 1;
        rs.levelMisses = 0;
      } else if (Math.abs(x - rs.level) <= band(rs.level)) {
        const n = rs.levelMinutes + 1;
        rs.level += (x - rs.level) / n;
        rs.levelMinutes = n;
        rs.levelMisses = 0;
      } else if ((rs.levelMisses ?? 0) + 1 >= SPIKE_LEVEL_MISSES) {
        rs.level = x;
        rs.levelMinutes = 1;
        rs.levelMisses = 0;
      } else {
        rs.levelMisses = (rs.levelMisses ?? 0) + 1;
      }
      if (!muted && rs.levelMinutes >= SPIKE_NEW_NORMAL_MINUTES) {
        closed.push({ ...openSpike, closedAt: nowIso, notes: [...openSpike.notes, NEW_NORMAL_NOTE] });
        byObject[key] = { mean: rs.level, variance: b?.variance ?? 0, samples: Math.max(b?.samples ?? 0, th.warmupSamples), warm: [] };
        setRule(spikeKey, between(openSpike.openedAt));
        continue;
      }
      rules[spikeKey] = rs;
      if (!muted)
        feedSlowly(key, x);
      if (openSpike.severity === "medium" && before > 0 && x >= SPIKE_HIGH_MULTIPLE * before) {
        updated.push({
          ...openSpike,
          severity: "high",
          after: Math.max(openSpike.after, x),
          impactPerDayM: Math.max(openSpike.impactPerDayM, Math.round((x - before) * 24))
        });
      }
      continue;
    }
    if (isMuted(key))
      continue;
    if (!isWarm(b, th.warmupSamples)) {
      if (x > 0)
        feed(key, x);
      continue;
    }
    const mean = b.mean;
    const sd = spikeSigma(b);
    const prior = rules[spikeKey];
    if (x > mean + th.spikeSigma * sd && x - mean >= minDeltaM) {
      feedSlowly(key, x);
      if (!demoProfile && between(prior?.lastOpenedAt))
        continue;
      const rs = { ...prior ?? fresh() };
      if (rs.streak === 0) {
        rs.frozenBaseline = mean;
        rs.firstQualifyingAt = toIso(minuteStart);
      }
      rs.streak += 1;
      if (rs.streak >= th.spikeMinutes) {
        const before = rs.frozenBaseline ?? mean;
        const firstMs = fromIso(rs.firstQualifyingAt ?? toIso(minuteStart));
        const found = matchCommit(commits, key, { sinceMs: firstMs - windowMs, untilMs: nowMs });
        const commit = found && found.match !== "nearby" ? found : void 0;
        const inc = {
          id: incidentId("spike", key, nowMs),
          type: "spike",
          // Under twice the baseline the money moved, but not dramatically: a warning, not a page.
          severity: before > 0 && x < SPIKE_HIGH_MULTIPLE * before ? "medium" : "high",
          objectKey: key,
          label: pt.label,
          openedAt: nowIso,
          cause: commit ? "commit" : "unknown",
          before,
          after: x,
          impactPerDayM: Math.max(0, Math.round((x - before) * 24)),
          caughtInSec: commit ? secondsBetween(commitTimeMs(commit), nowMs) : secondsBetween(firstMs, nowMs),
          notes: notes(),
          deliveries: []
        };
        if (pt.outputId !== void 0)
          inc.outputId = pt.outputId;
        if (commit)
          inc.commit = commit;
        opened.push(inc);
        rules[spikeKey] = { streak: 0, recoveryStreak: 0, frozenBaseline: before, firstQualifyingAt: rs.firstQualifyingAt, lastOpenedAt: nowIso };
      } else {
        rules[spikeKey] = rs;
      }
      continue;
    }
    setRule(spikeKey, between(prior?.lastOpenedAt));
    feed(key, x);
  }
  if (input.evaluateBudget) {
    budgetEvaluatedAt = nowIso;
    const tz = settings.displayTimezone || "UTC";
    const monthDays = daysInMonth(nowMs, tz);
    for (const [key, pt] of Object.entries(input.budgetSeries ?? {})) {
      if (excluded.has(key))
        continue;
      const budgetM = pt.budgetCentsPerMonth * 1e3;
      if (!(budgetM > 0))
        continue;
      const pace = budgetPace({
        paidMtdM: pt.paidMtdM,
        budgetCentsPerMonth: pt.budgetCentsPerMonth,
        nowMs,
        tz,
        meteredMinutes: input.budgetMinutesMtd,
        collectingSinceMs: input.collectingSinceMs
      });
      if (!(pace.elapsedMin >= 1))
        continue;
      const { projectedM } = pace;
      const pct = pace.pct ?? 0;
      const mayAlert = demoProfile || pace.settled;
      let severity = pct >= th.budgetAlertPct ? "high" : pct >= th.budgetWarnPct ? "medium" : void 0;
      if (severity === "high" && !demoProfile && pace.early)
        severity = "medium";
      const impactPerDayM = Math.max(0, Math.round((projectedM - budgetM) / monthDays));
      const threshold = severity === "high" ? th.budgetAlertPct : th.budgetWarnPct;
      const openBudget = open.get(`budget|${key}`);
      if (openBudget) {
        if (pct < th.budgetWarnPct - 5) {
          closed.push({ ...openBudget, closedAt: nowIso, recoveredTo: round1(pct) });
        } else if (mayAlert && severity && severityRank(severity) > severityRank(openBudget.severity) && !isMuted(key)) {
          updated.push({ ...openBudget, severity, before: threshold, after: round1(pct), impactPerDayM });
        }
        continue;
      }
      if (!mayAlert || !severity || isMuted(key))
        continue;
      const inc = {
        id: incidentId("budget", key, nowMs),
        type: "budget",
        severity,
        objectKey: key,
        label: pt.label,
        openedAt: nowIso,
        before: threshold,
        after: round1(pct),
        impactPerDayM,
        notes: notes(),
        deliveries: []
      };
      const p = parseObjectKey(key);
      if (p?.kind === "out")
        inc.outputId = p.id;
      opened.push(inc);
    }
  }
  const baselines = { schemaVersion: 1, updatedAt: nowIso, byObject, rules };
  if (budgetEvaluatedAt !== void 0)
    baselines.budgetEvaluatedAt = budgetEvaluatedAt;
  return { baselines, opened, updated, closed, unmatchedRegressions };
}
function rematchIncidents(incidents, commits, inventory, windowMin) {
  const upgraded = [];
  const out = incidents.map((inc) => {
    if (inc.closedAt || inc.cause === "commit" || inc.type !== "regression" && inc.type !== "spike")
      return inc;
    const openedMs = fromIso(inc.openedAt);
    if (Number.isNaN(openedMs))
      return inc;
    const firstMs = openedMs - (inc.caughtInSec ?? 0) * 1e3;
    const found = matchCommit(commits, inc.objectKey, { sinceMs: firstMs - windowMin * MINUTE_MS, untilMs: openedMs, ...objectContext(inc.objectKey, inventory) });
    const commit = inc.type === "spike" && found?.match === "nearby" ? void 0 : found;
    if (!commit)
      return inc;
    upgraded.push(inc.id);
    return {
      ...inc,
      cause: "commit",
      commit,
      severity: inc.type === "regression" && inc.severity === "medium" ? "high" : inc.severity,
      caughtInSec: secondsBetween(commitTimeMs(commit), openedMs)
    };
  });
  return { incidents: out, upgraded };
}

// core/payloads.ts
var KIND_NAMES = { in: "input", route: "route", pipe: "pipeline", out: "output" };
var CATCH_UP_NOTE = "catch-up";
function isCatchUp(i) {
  return (i.notes ?? []).includes(CATCH_UP_NOTE);
}
function caughtInSeconds(i) {
  if (i.caughtInSec === void 0)
    return void 0;
  const opened = fromIso(i.openedAt);
  const detected = i.detectedAt ? fromIso(i.detectedAt) : Number.NaN;
  const late = Number.isFinite(opened) && Number.isFinite(detected) && detected > opened ? (detected - opened) / 1e3 : 0;
  return Math.round(i.caughtInSec + late);
}
function ledgerLink(linkBase, objectKey2) {
  const base = (linkBase ?? "").replace(/\/+$/, "");
  return `${base}/ledger?object=${encodeURIComponent(objectKey2).replace(/%3A/gi, ":")}`;
}
function toCanonicalIncident(i, linkBase, labels) {
  const parsed = parseObjectKey(i.objectKey);
  const id = parsed?.id ?? i.objectKey;
  const isRatio = i.type === "regression" || i.type === "goodnews";
  const reading = (value) => isRatio ? { ratio: value } : { value };
  const r = incidentReadings(i);
  const out = {
    id: i.id,
    type: i.type,
    severity: i.severity,
    title: titleFor({ type: i.type, label: i.label || humanize(id, labels) }),
    object: {
      kind: parsed ? KIND_NAMES[parsed.kind] : "route",
      id,
      label: i.label || humanize(id, labels),
      group: parsed?.groupId ?? ""
    },
    before: reading(r.before),
    after: r.after === void 0 ? {} : reading(r.after),
    impact: { perDayMillicents: i.impactPerDayM, perDay: fmtDollars(i.impactPerDayM), perYear: fmtDollars(perYear(i.impactPerDayM)) },
    openedAt: i.openedAt,
    link: ledgerLink(linkBase, i.objectKey),
    notes: [...i.notes ?? []]
  };
  if (r.recoveredTo !== void 0)
    out.recoveredTo = reading(r.recoveredTo);
  if (i.outputId)
    out.object.destination = i.outputId;
  if (i.cause)
    out.cause = i.cause;
  if (i.commit) {
    out.commit = { hash: i.commit.hash, message: i.commit.message, author: displayAuthor(i.commit.author), match: i.commit.match };
    if (i.commit.deployedAt)
      out.commit.deployedAt = i.commit.deployedAt;
  }
  const caught = caughtInSeconds(i);
  if (caught !== void 0)
    out.caughtInSeconds = caught;
  if (i.closedAt)
    out.closedAt = i.closedAt;
  if (i.closedAt && i.closedReason)
    out.closedReason = i.closedReason;
  if (i.closedAt && i.closedBy)
    out.closedBy = i.closedBy;
  return out;
}
function canonicalPayload(event, opts) {
  const p = {
    schemaVersion: 1,
    app: "meter-reader",
    event,
    sentAt: opts.sentAt ?? (/* @__PURE__ */ new Date()).toISOString(),
    workspace: opts.workspace
  };
  if (opts.incident)
    p.incident = toCanonicalIncident(opts.incident, opts.linkBase, opts.labels);
  if (opts.receipt)
    p.receipt = opts.receipt;
  return p;
}
var clip = (s, max) => s.length <= max ? s : `${s.slice(0, max - 1)}\u2026`;
var esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
var escCode = (s) => esc(s).replace(/\u0060/g, "'");
var field = (label, value) => ({ type: "mrkdwn", text: clip(`*${label}*
${value}`, 2e3) });
function closedAsNewNormal(i) {
  return (i.notes ?? []).includes(NEW_NORMAL_NOTE);
}
var MEMBER_CLOSED_PREFIX = PAYLOAD_STRINGS.memberClosed;
function closedPrefix(i) {
  if (i.closedReason)
    return MEMBER_CLOSED_PREFIX[i.closedReason] ?? PAYLOAD_STRINGS.closedPrefix;
  return closedAsNewNormal(i) ? PAYLOAD_STRINGS.newNormalPrefix : PAYLOAD_STRINGS.recoveredPrefix;
}
function closedByText(i) {
  return i.closedReason && i.closedBy ? fill(PAYLOAD_STRINGS.closedBy, { by: i.closedBy }) : "";
}
function slackGlyph(p) {
  if (p.event === "receipt.weekly")
    return ":receipt:";
  const i = p.incident;
  if (!i)
    return ":large_blue_circle:";
  if ((p.event === "incident.closed" || i.closedAt) && (closedAsNewNormal(i) || i.closedReason))
    return ":large_blue_circle:";
  if (p.event === "incident.closed" || i.closedAt || i.type === "goodnews")
    return ":large_green_circle:";
  if (i.severity === "high")
    return ":red_circle:";
  if (i.severity === "medium")
    return ":large_orange_circle:";
  return ":large_blue_circle:";
}
function commitText(i) {
  if (!i.commit)
    return PAYLOAD_STRINGS.noChange;
  const nearby = i.commit.match === "nearby" ? PAYLOAD_STRINGS.nearby : "";
  return `\`${i.commit.hash.slice(0, 7)}\` ${esc(clip(i.commit.message, 150))}${nearby}`;
}
function perHour(value) {
  return fill(PAYLOAD_STRINGS.perHour, { amount: fmtDollars(value ?? 0) });
}
var pctOfBudget = (value) => fill(PAYLOAD_STRINGS.pctOfBudget, { pct: Math.round(value ?? 0) });
var F = PAYLOAD_STRINGS.fields;
function openSeconds(i) {
  const opened = fromIso(i.openedAt);
  const closed = i.closedAt ? fromIso(i.closedAt) : Number.NaN;
  return Number.isFinite(opened) && Number.isFinite(closed) && closed >= opened ? (closed - opened) / 1e3 : void 0;
}
function endedByItself(i) {
  return !!i.closedAt && !i.closedReason;
}
function realizedImpactM(i) {
  const sec = openSeconds(i);
  if (sec === void 0 || sec > 86400)
    return void 0;
  return Math.round(Math.max(0, i.impact.perDayMillicents) * sec / 86400);
}
function fmtRealized(mc) {
  return mc < 100 * MC_PER_DOLLAR ? fmtDollarsCents(mc) : fmtDollars(mc);
}
function impactPhrase(i) {
  const M = PAYLOAD_STRINGS.impact;
  const money = { perDay: i.impact.perDay, perYear: i.impact.perYear };
  if (i.type === "budget")
    return fill(M.overBudget, money);
  if (i.type === "goodnews")
    return fill(M.perDayPerYear, money);
  if (endedByItself(i)) {
    const sec = openSeconds(i);
    const realized = realizedImpactM(i);
    return sec === void 0 || realized === void 0 ? fill(M.closedNoDuration, money) : fill(M.closed, { ...money, duration: fmtDurationShort(sec), realized: fmtRealized(realized) });
  }
  return fill(i.type === "spike" ? M.spike : M.open, money);
}
function incidentFields(i, closed) {
  const commitPair = [field(F.commit, commitText(i)), field(F.by, i.commit ? esc(displayAuthor(i.commit.author)) : "\u2014")];
  const open = closed ? openSeconds(i) : void 0;
  const recovered = closed && !i.closedReason;
  const openFor = open !== void 0 ? [field(F.openFor, fmtDuration(open))] : [];
  const realized = recovered ? realizedImpactM(i) : void 0;
  const cameTo = (label) => realized !== void 0 ? [field(label, `\u2248 ${fmtRealized(realized)}`)] : [];
  switch (i.type) {
    case "spike":
      return [
        field(recovered ? F.wasCostingExtra : F.extraPerDay, i.impact.perDay),
        ...cameTo(F.costWhileOpen),
        ...commitPair,
        field(F.baseline, perHour(i.before.value)),
        ...i.after.value !== void 0 ? [field(recovered ? F.peak : F.now, perHour(i.after.value))] : [],
        ...i.recoveredTo ? [field(F.now, perHour(i.recoveredTo.value))] : [],
        ...openFor
      ];
    case "budget":
      return [
        field(F.overBudgetPerDay, i.impact.perDay),
        ...i.after.value !== void 0 ? [field(recovered ? F.peakProjection : F.projected, pctOfBudget(i.after.value))] : [],
        field(F.threshold, `${Math.round(i.before.value ?? 0)}%`),
        ...i.recoveredTo ? [field(F.now, pctOfBudget(i.recoveredTo.value))] : [],
        ...openFor
      ];
    case "goodnews":
      return [
        field(F.savingPerDay, i.impact.perDay),
        field(F.perYear, i.impact.perYear),
        ...commitPair,
        field(F.before, fmtPct(i.before.ratio ?? 0)),
        field(F.after, fmtPct(i.after.ratio ?? 0))
      ];
    default:
      return [
        field(recovered ? F.wasLosingPerDay : F.lostPerDay, i.impact.perDay),
        ...recovered ? cameTo(F.lostWhileOpen) : [field(closed ? F.perYear : F.perYearIfLeft, i.impact.perYear)],
        ...commitPair,
        field(F.before, fmtPct(i.before.ratio ?? 0)),
        ...i.after.ratio !== void 0 ? [field(F.after, fmtPct(i.after.ratio))] : [],
        ...i.recoveredTo ? [field(F.recoveredTo, fmtPct(i.recoveredTo.ratio ?? 0))] : [],
        ...openFor
      ];
  }
}
function caughtLine(i) {
  if (isCatchUp(i))
    return i.caughtInSeconds !== void 0 ? fill(PAYLOAD_STRINGS.caughtOnCatchUpAfter, { duration: fmtDuration(i.caughtInSeconds) }) : PAYLOAD_STRINGS.caughtOnCatchUp;
  return i.caughtInSeconds !== void 0 ? fill(PAYLOAD_STRINGS.caughtIn, { duration: fmtDuration(i.caughtInSeconds) }) : "";
}
function localTime(iso2, tz) {
  const t = iso2 ? fromIso(iso2) : Number.NaN;
  if (Number.isNaN(t))
    return "";
  return `${formatLocalTime(t, tz)}${tz === "UTC" ? " UTC" : ""}`;
}
function slackPayload(canonical, opts = {}) {
  const tz = opts.tz ?? "UTC";
  const glyph = slackGlyph(canonical);
  if (canonical.event === "receipt.weekly" && canonical.receipt) {
    const r = canonical.receipt;
    return {
      text: esc(fill(PAYLOAD_STRINGS.weeklyFallback, { glyph, label: r.label, amount: fmtDollars(r.savedM) })),
      blocks: [
        { type: "header", text: { type: "plain_text", text: clip(fill(PAYLOAD_STRINGS.weeklyHeader, { glyph, label: r.label }), 150), emoji: true } },
        { type: "section", text: { type: "mrkdwn", text: `\`\`\`
${clip(escCode(receiptText(r)), 2990)}
\`\`\`` } },
        // P0-23: the week on the Receipt, as the incident cards open the Ledger.
        ...r.link ? [{ type: "actions", elements: [{ type: "button", text: { type: "plain_text", text: PAYLOAD_STRINGS.openReceipt }, url: r.link, action_id: "open_receipt" }] }] : []
      ]
    };
  }
  const i = canonical.incident;
  if (!i) {
    const text = canonical.event === "test" ? PAYLOAD_STRINGS.testTitle : fill(PAYLOAD_STRINGS.eventTitle, { event: canonical.event });
    return { text: esc(`${glyph} ${text}`), blocks: [{ type: "section", text: { type: "mrkdwn", text: esc(`${glyph} ${text}`) } }] };
  }
  const recovered = canonical.event === "incident.closed" || !!i.closedAt;
  const prefix = canonical.event === "test" ? PAYLOAD_STRINGS.testPrefix : recovered && i.type !== "goodnews" ? closedPrefix(i) : "";
  const title = `${prefix}${i.title}`;
  const destination = i.object.destination ? humanize(i.object.destination, opts.labels) : i.object.group;
  const when = recovered && i.closedAt ? localTime(i.closedAt, tz) : localTime(i.openedAt, tz);
  const context = [CREDIT_STRINGS.signature, destination, `${when}${recovered ? closedByText(i) : ""}`, recovered ? "" : caughtLine(i)].filter((s) => s).join(" \xB7 ");
  const notes = i.notes.includes("demo-profile") ? PAYLOAD_STRINGS.demoProfile : "";
  return {
    // The top-level text is the notification fallback: Slack reads &, < and > as control characters there too.
    text: esc(fill(PAYLOAD_STRINGS.incidentFallback, { glyph, title, money: impactPhrase(i) })),
    blocks: [
      { type: "header", text: { type: "plain_text", text: clip(`${glyph} ${title}`, 150), emoji: true } },
      { type: "section", fields: incidentFields(i, recovered) },
      { type: "context", elements: [{ type: "mrkdwn", text: esc(`${context}${notes}`) }] },
      { type: "actions", elements: [{ type: "button", text: { type: "plain_text", text: PAYLOAD_STRINGS.openLedger }, url: i.link, action_id: "open_in_ledger" }] }
    ]
  };
}
function incidentPlainText(i) {
  const P = PAYLOAD_STRINGS.plain;
  const money = { money: impactPhrase(i) };
  const lines = [i.title];
  if (i.type === "regression" || i.type === "goodnews") {
    const drop = i.after.ratio !== void 0 ? `${fmtPct(i.before.ratio ?? 0)} \u2192 ${fmtPct(i.after.ratio)}` : fill(P.before, { value: fmtPct(i.before.ratio ?? 0) });
    const back = i.recoveredTo ? fill(P.recoveredTo, { value: fmtPct(i.recoveredTo.ratio ?? 0) }) : "";
    lines.push(fill(P.ratio, { drop, back, ...money }));
  } else if (i.type === "spike") {
    const rise = i.after.value !== void 0 ? `${perHour(i.before.value)} \u2192 ${perHour(i.after.value)}` : fill(P.before, { value: perHour(i.before.value) });
    const back = i.recoveredTo ? fill(P.recoveredTo, { value: perHour(i.recoveredTo.value) }) : "";
    lines.push(fill(P.cost, { rise, back, ...money }));
  } else {
    const pace = i.after.value !== void 0 ? fill(P.projected, { value: pctOfBudget(i.after.value) }) : fill(P.threshold, { pct: Math.round(i.before.value ?? 0) });
    const back = i.recoveredTo ? fill(P.recoveredTo, { value: pctOfBudget(i.recoveredTo.value) }) : "";
    lines.push(fill(P.budget, { pace, back, perDay: i.impact.perDay }));
  }
  lines.push(i.commit ? fill(P.commit, { hash: i.commit.hash.slice(0, 7), message: i.commit.message, author: displayAuthor(i.commit.author) }) : PAYLOAD_STRINGS.noChange);
  const line = caughtLine(i);
  const caught = line ? `${line[0].toUpperCase()}${line.slice(1)} \xB7 ` : "";
  const closedWord = i.closedReason ? `${closedPrefix(i).replace(/: $/, "")}${closedByText(i)}` : closedAsNewNormal(i) ? PAYLOAD_STRINGS.closedAsNewNormal : PAYLOAD_STRINGS.recovered;
  lines.push(`${caught}${fill(P.opened, { at: i.openedAt })}${i.closedAt ? fill(P.closed, { closed: closedWord, at: i.closedAt }) : ""}`);
  lines.push(fill(PAYLOAD_STRINGS.openLedgerAt, { link: i.link }));
  lines.push(CREDIT_STRINGS.signature);
  return lines.join("\n");
}
var URGENCY = { high: 1, medium: 2, info: 3 };
function servicenowPayload(canonical) {
  if (canonical.receipt) {
    return {
      short_description: fill(PAYLOAD_STRINGS.servicenowWeekly, { label: canonical.receipt.label }),
      description: receiptText(canonical.receipt),
      urgency: 3,
      u_meter_reader: canonical.receipt
    };
  }
  if (canonical.incident) {
    const i = canonical.incident;
    const recovered = canonical.event === "incident.closed" || !!i.closedAt;
    return {
      short_description: `${recovered && i.type !== "goodnews" ? closedPrefix(i) : ""}${i.title}`,
      description: incidentPlainText(i),
      urgency: URGENCY[i.severity] ?? 3,
      u_meter_reader: i
    };
  }
  const title = fill(PAYLOAD_STRINGS.eventTitle, { event: canonical.event });
  return { short_description: title, description: title, urgency: 3, u_meter_reader: { event: canonical.event } };
}
function genericPayload(canonical) {
  return canonical;
}
function payloadFor(format, canonical, opts = {}) {
  switch (format) {
    case "slack":
      return slackPayload(canonical, opts);
    case "servicenow":
      return servicenowPayload(canonical);
    default:
      return genericPayload(canonical);
  }
}

// core/delivery.ts
function channelOf(ep) {
  return ep.channel === "cribl-bell" || ep.channel === "cribl-target" ? ep.channel : "webhook";
}
var BELL_ENDPOINT_ID = "cribl-bell";
function defaultBellEndpoint() {
  return {
    id: BELL_ENDPOINT_ID,
    name: "Cribl notifications",
    url: "",
    host: "",
    format: "generic",
    minSeverity: "medium",
    weeklyReceipt: true,
    enabled: true,
    channel: "cribl-bell"
  };
}
function resolveEndpoints(stored) {
  const list = [...stored ?? []];
  if (!list.some((e) => channelOf(e) === "cribl-bell"))
    list.push({ ...defaultBellEndpoint(), implicit: true });
  return list;
}
function deliveryOrder(endpoints) {
  const rank = (e) => e.implicit ? 2 : channelOf(e) === "webhook" ? 1 : 0;
  return endpoints.map((e, i) => ({ e, i })).sort((a, b) => rank(a.e) - rank(b.e) || a.i - b.i).map((x) => x.e);
}
function isRecovered(c, i) {
  return c.event === "incident.closed" || !!i.closedAt;
}
function commitLine(i) {
  if (!i.commit)
    return "no configuration change found nearby";
  const nearby = i.commit.match === "nearby" ? " (nearby change)" : "";
  return `commit ${i.commit.hash.slice(0, 7)} by ${displayAuthor(i.commit.author)}${nearby}`;
}
function renderAlert(c) {
  if (c.event === "receipt.weekly" && c.receipt) {
    const r = c.receipt;
    const f = footMoney({ whpM: r.whpM, paidM: r.paidM, savedM: r.savedM });
    return {
      title: `Weekly receipt \xB7 ${r.label}`,
      line: `Saved by Cribl ${fmtDollars(f.savedM)} \xB7 would have paid ${fmtDollars(f.whpM)} \xB7 paid ${fmtDollars(f.paidM)} \xB7 ${fmtPct(r.ratio)} saved \xB7 ${CREDIT_STRINGS.signature}`,
      text: receiptText(r),
      severity: "info"
    };
  }
  const i = c.incident;
  if (!i) {
    const title2 = c.event === "test" ? "Meter Reader test notification" : `Meter Reader ${c.event}`;
    return { title: title2, line: title2, text: title2, severity: "info" };
  }
  const recovered = isRecovered(c, i);
  const prefix = c.event === "test" ? "Test: " : recovered && i.type !== "goodnews" ? closedPrefix(i) : "";
  const title = `${prefix}${i.title}`;
  const money = impactPhrase(i);
  const caught = !recovered && isCatchUp(i) ? ` \xB7 ${caughtLine(i)}` : "";
  const line = `${i.type === "budget" ? money : `${money} \xB7 ${commitLine(i)}`}${caught} \xB7 ${CREDIT_STRINGS.signature}`;
  const body = incidentPlainText(i).split("\n").slice(1);
  return {
    title,
    line,
    text: [title, ...body].join("\n"),
    severity: recovered || i.type === "goodnews" ? "info" : i.severity
  };
}
function bellMessageId(c) {
  const sent = fromIso(c.sentAt);
  const stamp = Number.isNaN(sent) ? "0" : String(sent);
  if (c.event === "receipt.weekly" && c.receipt)
    return `meter-reader-receipt-${c.receipt.periodStart.slice(0, 10)}`;
  const i = c.incident;
  if (!i)
    return `meter-reader-${c.event.replace(/\W/g, "-")}-${stamp}`;
  if (c.event === "test")
    return `meter-reader-test-${stamp}`;
  return `meter-reader-${i.id}-${isRecovered(c, i) ? "closed" : i.severity}`;
}
var BELL_ALREADY_STATUS = 208;
var BELL_UNAVAILABLE_DETAIL = "Cribl notification API unavailable";
function createDeliveryRouter(deps) {
  const sleep = deps.sleep ?? defaultSleep;
  const relays = /* @__PURE__ */ new Map();
  let bellUnavailable;
  const deliveredAlerts = /* @__PURE__ */ new Set();
  const alertKey = (req) => req.incidentId !== void 0 && req.event !== "receipt.weekly" && req.event !== "test" ? `${req.incidentId}|${req.event}` : void 0;
  const logEntry = (req, attempt, at, out) => {
    const entry = {
      endpointId: req.endpoint.id,
      event: req.event,
      status: out.status,
      attempt,
      at: new Date(at).toISOString(),
      kind: "notify"
    };
    if (req.incidentId !== void 0)
      entry.incidentId = req.incidentId;
    if (out.error !== void 0)
      entry.error = out.error;
    if (out.detail !== void 0)
      entry.detail = out.detail;
    return entry;
  };
  const bellSkipped = (req, at, out) => {
    const key = alertKey(req);
    if (key === void 0 || deliveredAlerts.has(key))
      return [];
    return [logEntry(req, 1, at, { status: out.status, ...out.error !== void 0 ? { error: out.error } : {}, detail: out.detail ?? BELL_UNAVAILABLE_DETAIL })];
  };
  async function bell(req) {
    const ep = req.endpoint;
    if (ep.implicit && bellUnavailable)
      return bellSkipped(req, deps.clock.now(), bellUnavailable);
    const r = renderAlert(req.canonical);
    const msg = {
      id: bellMessageId(req.canonical),
      severity: BELL_SEVERITY[r.severity],
      title: r.title,
      text: r.line,
      time: deps.clock.now()
    };
    const backoff = req.backoffMs ?? WEBHOOK_BACKOFF_MS;
    const logs = [];
    for (let attempt = 1; attempt <= backoff.length + 1; attempt++) {
      const at = deps.clock.now();
      const out = await postBell(deps.http, msg);
      if (ep.implicit && (out.error === "not_available" || out.error === "not_permitted")) {
        bellUnavailable = out;
        deps.logger?.info("delivery: default bell skipped", { status: out.status, error: out.error });
        return bellSkipped(req, at, out);
      }
      const logged = out.ok && out.status === 409 ? { status: BELL_ALREADY_STATUS, detail: "already in the bell (409)" } : out;
      logs.push(logEntry(req, attempt, at, logged));
      if (out.ok || !out.retry || attempt > backoff.length)
        break;
      await sleep(backoff[attempt - 1]);
    }
    return logs;
  }
  async function target(req) {
    const targetId = req.endpoint.criblTargetId ?? "";
    const at = deps.clock.now();
    if (!targetId)
      return [logEntry(req, 1, at, { status: 0, error: "target_missing", detail: "no Cribl notification target chosen" })];
    let state = relays.get(targetId);
    if (!state) {
      state = relayState(deps.http, targetId);
      relays.set(targetId, state);
    }
    const s = await state;
    if (s.state === "missing") {
      return [logEntry(req, 1, at, { status: 404, error: "relay_missing", detail: "connect this target in Settings \u2192 Where to send alerts" })];
    }
    if (s.state === "error")
      return [logEntry(req, 1, at, { status: s.status, error: s.error, ...s.detail ? { detail: s.detail } : {} })];
    const r = renderAlert(req.canonical);
    const sendAt = deps.clock.now();
    const out = await forwardViaTarget(deps.http, {
      targetId,
      suffix: `${req.incidentId ?? "mr"}_${req.event}_${sendAt}`,
      title: r.title,
      severity: r.severity,
      message: r.text,
      now: sendAt,
      payload: req.canonical
    });
    return [logEntry(req, 1, sendAt, out)];
  }
  async function webhook(req) {
    const ep = req.endpoint;
    const opts = {};
    if (req.tz !== void 0)
      opts.tz = req.tz;
    if (req.labels !== void 0)
      opts.labels = req.labels;
    return deliver({
      sender: deps.webhook,
      url: ep.url,
      body: payloadFor(ep.format, req.canonical, opts),
      clock: deps.clock,
      sleep,
      endpointId: ep.id,
      event: req.event,
      ...req.incidentId !== void 0 ? { incidentId: req.incidentId } : {},
      ...req.backoffMs !== void 0 ? { backoffMs: req.backoffMs } : {}
    });
  }
  const route = (req) => {
    switch (channelOf(req.endpoint)) {
      case "cribl-bell":
        return bell(req);
      case "cribl-target":
        return target(req);
      default:
        return webhook(req);
    }
  };
  return {
    async deliver(req) {
      try {
        const logs = await route(req);
        const key = alertKey(req);
        if (key !== void 0 && logs.some((l) => l.status >= 200 && l.status < 300))
          deliveredAlerts.add(key);
        return logs;
      } catch (e) {
        return [logEntry(req, 1, deps.clock.now(), { status: 0, error: "network_error", detail: e instanceof Error ? e.message : String(e) })];
      }
    }
  };
}

// core/env-webhooks.ts
function webhookDescriptor(e) {
  return { id: e.id, name: e.name, host: e.host, format: e.format };
}

// core/snapshot.ts
var MAX_TOP_SAVERS = 5;
var MAX_SNAPSHOT_INCIDENTS = 50;
var MAX_SNAPSHOT_TIMELINE = 30;
var MAX_SNAPSHOT_DELIVERIES = 20;
var MAX_RATIO_POINTS = 288;
var RATIO_BUCKET_MS = 5 * MINUTE_MS;
var SPARKLINE_POINTS = 30;
var COMPACT_FLOWS = 500;
var COMPACT_SPARKLINE_POINTS = 12;
var byT = (a, b) => fromIso(a.t) - fromIso(b.t);
var sum = (xs, f) => xs.reduce((s, x) => s + f(x), 0);
var ATTRIBUTION_RANK = { reconciled: 0, route: 1, "route-only": 2, pipeline: 3, proportional: 4 };
function summarizeAttribution(figures) {
  const live = figures.filter((f) => f.inB > 0 || f.whpPerDayM > 0);
  const pool = live.length > 0 ? live : figures;
  const methods = pool.map((f) => f.attribution);
  const measured = methods.filter((m) => m !== "route-only");
  if (measured.length === 0)
    return methods.length > 0 ? "route-only" : "route";
  return measured.reduce((worst, m) => ATTRIBUTION_RANK[m] > ATTRIBUTION_RANK[worst] ? m : worst, "reconciled");
}
function ratioBuckets(minuteRows, fromMs, untilMs) {
  const buckets = /* @__PURE__ */ new Map();
  for (const rows of Object.values(minuteRows)) {
    for (const r of rows) {
      const t = fromIso(r.t);
      if (!(t >= fromMs && t < untilMs))
        continue;
      const b = Math.floor(t / RATIO_BUCKET_MS) * RATIO_BUCKET_MS;
      const acc = buckets.get(b) ?? { whp: 0, saved: 0 };
      acc.whp += r.whpM;
      acc.saved += r.savedM;
      buckets.set(b, acc);
    }
  }
  return buckets;
}
function routeIdentity(key) {
  const p = parseFlowKey(key);
  return p ? `${p.groupId}|${p.inputId}|${p.routeId}|${p.outputId}` : void 0;
}
function routeHistoryKeys(flows, minuteRows) {
  const current = /* @__PURE__ */ new Set();
  const heir = /* @__PURE__ */ new Map();
  for (const f of flows) {
    current.add(f.key);
    const id = routeIdentity(f.key);
    if (id === void 0)
      continue;
    const prev = heir.get(id);
    if (prev === void 0 || f.key < prev)
      heir.set(id, f.key);
  }
  const out = /* @__PURE__ */ new Map();
  for (const key of Object.keys(minuteRows).sort()) {
    if (current.has(key))
      continue;
    const id = routeIdentity(key);
    const to = id === void 0 ? void 0 : heir.get(id);
    if (to === void 0)
      continue;
    const list = out.get(to);
    if (list)
      list.push(key);
    else
      out.set(to, [key]);
  }
  return out;
}
function outputType(inventory, groupId, outputId) {
  return inventory?.byGroup?.[groupId]?.outputs?.find((o) => o.id === outputId);
}
function routeNamed(inventory, groupId, routeId) {
  const name = inventory?.byGroup?.[groupId]?.routes?.find((r) => r.id === routeId)?.name?.trim();
  return name && name !== routeId ? { routeName: name } : {};
}
function distinctLabels(savers, overrides) {
  const routeOf = (s) => parseObjectKey(s.objectKey)?.id ?? s.objectKey;
  const repeated = (list) => {
    const seen = /* @__PURE__ */ new Set();
    const twice = /* @__PURE__ */ new Set();
    for (const s of list)
      (seen.has(s.label) ? twice : seen).add(s.label);
    return twice;
  };
  let out = savers;
  for (const widen of [(s) => `${humanize(routeOf(s), overrides)} \xB7 ${s.label}`, (s) => `${s.label} \xB7 ${s.groupId}`]) {
    const twice = repeated(out);
    if (twice.size === 0)
      break;
    out = out.map((s) => twice.has(s.label) ? { ...s, label: widen(s) } : s);
  }
  return out;
}
function buildSnapshot(parts) {
  const { settings, sweepAtMs, windowStartMs, windowEndMs } = parts;
  const tz = settings.displayTimezone || "UTC";
  const windowStartIso = toIso(windowStartMs);
  const hourAgo = windowEndMs - 60 * MINUTE_MS;
  const coveredMin = Math.min(60, Math.max(1, Math.round((windowEndMs - Math.max(hourAgo, parts.collectingSinceMs)) / MINUTE_MS)));
  const perDayFactor = 1440 / coveredMin;
  const openIncidents = (parts.incidents ?? []).filter((i) => !i.closedAt);
  const openByKey = /* @__PURE__ */ new Map();
  for (const i of openIncidents)
    openByKey.set(`${i.type}|${i.objectKey}`, i);
  const mutedUntil = (key) => {
    const until = key ? parts.muted?.[key] : void 0;
    return until !== void 0 && fromIso(until) > sweepAtMs ? until : void 0;
  };
  const memberMutedUntil = (key) => {
    const until = key ? settings.mutes?.[key]?.until : void 0;
    return until !== void 0 && fromIso(until) > sweepAtMs ? until : void 0;
  };
  const priceCache = /* @__PURE__ */ new Map();
  const pricesFor = (groupId, outputId) => {
    const k = `${groupId}:${outputId}`;
    let p = priceCache.get(k);
    if (!p) {
      p = effectivePrices(parts.prices, groupId, outputId, sweepAtMs, outputType(parts.inventory, groupId, outputId));
      priceCache.set(k, p);
    }
    return p;
  };
  const history = routeHistoryKeys(parts.flows, parts.minuteRows);
  let lastMinuteSavedM = 0;
  const flows = parts.flows.map((f) => {
    const own = [...parts.minuteRows[f.key] ?? []].sort(byT);
    const earlier = history.get(f.key);
    const rows = earlier ? poolMinuteRows([own, ...earlier.map((k) => parts.minuteRows[k])]) : own;
    const last = own.find((r) => r.t === windowStartIso) ?? { t: windowStartIso, inB: 0, outB: 0, inE: 0, outE: 0, whpM: 0, paidM: 0, savedM: 0 };
    const hour = rows.filter((r) => {
      const t = fromIso(r.t);
      return t >= hourAgo && t < windowEndMs;
    });
    lastMinuteSavedM += last.savedM;
    const keys = flowObjectKeys(f);
    const demoMuted = mutedUntil(keys.route) ?? mutedUntil(keys.pipeline) ?? mutedUntil(keys.input);
    const memberMuted = demoMuted ? void 0 : memberMutedUntil(keys.route) ?? memberMutedUntil(keys.pipeline) ?? memberMutedUntil(keys.input) ?? memberMutedUntil(keys.output);
    const muted = demoMuted ?? memberMuted;
    const price = pricesFor(f.groupId, f.outputId);
    let state = "ok";
    if (!muted) {
      if ([keys.route, keys.pipeline].some((k) => k && openByKey.has(`regression|${k}`)))
        state = "regression";
      else if (keys.input && openByKey.has(`spike|${keys.input}`))
        state = "spike";
      else if (price.unpriced)
        state = "unpriced";
      else if (parts.baselines && keys.route && !isWarm(parts.baselines.byObject[keys.route], settings.thresholds.warmupSamples))
        state = "learning";
    }
    const fig = {
      key: f.key,
      groupId: f.groupId,
      inputId: f.inputId,
      routeId: f.routeId,
      ...routeNamed(parts.inventory, f.groupId, f.routeId),
      pipelineId: f.pipelineId,
      outputId: f.outputId,
      inB: last.inB,
      outB: last.outB,
      whpM: last.whpM,
      paidM: last.paidM,
      savedM: last.savedM,
      ratio: ratio(last.savedM, last.whpM),
      ratePerHourM: last.paidM * 60,
      savedPerDayM: Math.round(sum(hour, (r) => r.savedM) * perDayFactor),
      whpPerDayM: Math.round(sum(hour, (r) => r.whpM) * perDayFactor),
      paidPerDayM: Math.round(sum(hour, (r) => r.paidM) * perDayFactor),
      inBPerDay: Math.round(sum(hour, (r) => r.inB) * perDayFactor),
      outBPerDay: Math.round(sum(hour, (r) => r.outB) * perDayFactor),
      attribution: parts.attribution?.[f.key] ?? f.attribution,
      sparkline: sparkline(rows.slice(-SPARKLINE_POINTS), SPARKLINE_POINTS),
      state
    };
    if (muted) {
      fig.muted = true;
      fig.mutedUntil = muted;
      if (memberMuted)
        fig.mutedByMember = true;
    }
    if (isDiversion(price.counterfactual, f.outputId) && price.counterfactual.kind === "other") {
      fig.diverted = true;
      fig.divertedTo = price.counterfactual.outputId;
    }
    const hourWhp = sum(hour, (r) => r.whpM);
    const added = addedCost({ whpM: hourWhp, paidM: sum(hour, (r) => r.paidM) });
    if (added > INFLATION_NOISE * hourWhp)
      fig.addedPerDayM = Math.round(added * perDayFactor);
    return fig;
  });
  const monthKey = localMonthKey(sweepAtMs, tz);
  const mtdMinutes = meteredMinutesInMonth(parts.totals, monthKey);
  const destKeys = /* @__PURE__ */ new Map();
  for (const f of flows)
    if (f.outputId !== "-")
      destKeys.set(`${f.groupId}:${f.outputId}`, { groupId: f.groupId, outputId: f.outputId });
  for (const [gid, g] of Object.entries(parts.inventory?.byGroup ?? {})) {
    for (const o of g.outputs ?? []) {
      if (o.disabled || o.type === "default" || !settings.includeInternal && isInternalOutput(o))
        continue;
      destKeys.set(`${gid}:${o.id}`, { groupId: gid, outputId: o.id });
    }
  }
  const destinations = [...destKeys.entries()].sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0).map(([key, { groupId, outputId }]) => {
    const mine = flows.filter((f) => f.groupId === groupId && f.outputId === outputId);
    const price = pricesFor(groupId, outputId);
    const mtd = outputMonthTotals(parts.totals, monthKey, key);
    const d = {
      groupId,
      outputId,
      type: outputType(parts.inventory, groupId, outputId)?.type ?? "unknown",
      whpPerDayM: sum(mine, (f) => f.whpPerDayM),
      paidPerDayM: sum(mine, (f) => f.paidPerDayM),
      savedPerDayM: sum(mine, (f) => f.savedPerDayM),
      mtdPaidM: mtd.paidM,
      mtdSavedM: mtd.savedM,
      mtdWhpM: mtd.whpM,
      mtdMinutes,
      milliCentsPerGb: price.paidMcPerGb,
      counterfactual: price.counterfactual,
      unpriced: price.unpriced
    };
    if (price.counterfactualUnpriced)
      d.counterfactualUnpriced = true;
    const budget = settings.budgets?.[outputId];
    if (budget && budget.centsPerMonth > 0) {
      const projectedM = Math.round(
        budgetPace({ paidMtdM: mtd.paidM, nowMs: sweepAtMs, tz, meteredMinutes: mtdMinutes, collectingSinceMs: parts.collectingSinceMs }).projectedM
      );
      d.budget = { centsPerMonth: budget.centsPerMonth, projectedM, pct: projectedM / (budget.centsPerMonth * 1e3) * 100 };
    }
    return d;
  });
  const byRoute = /* @__PURE__ */ new Map();
  for (const f of flows) {
    if (f.routeId === "-")
      continue;
    const k = `${f.groupId}:${f.routeId}`;
    const acc = byRoute.get(k) ?? { groupId: f.groupId, routeId: f.routeId, pipelineId: f.pipelineId, saved: 0, whp: 0, divertedSaved: 0 };
    acc.saved += f.savedPerDayM;
    acc.whp += f.whpPerDayM;
    if (f.diverted)
      acc.divertedSaved += f.savedPerDayM;
    byRoute.set(k, acc);
  }
  const topSavers = distinctLabels(
    [...byRoute.values()].filter((r) => r.saved > 0).map((r) => {
      const saver = {
        objectKey: objectKey("route", r.groupId, r.routeId),
        label: humanize(r.pipelineId !== "-" ? r.pipelineId : r.routeId, settings.humanize),
        savedPerDayM: r.saved,
        ratio: ratio(r.saved, r.whp),
        groupId: r.groupId,
        pipelineId: r.pipelineId
      };
      if (r.divertedSaved >= r.saved)
        saver.diverted = true;
      return saver;
    }).sort((a, b) => b.savedPerDayM - a.savedPerDayM || (a.objectKey < b.objectKey ? -1 : 1)).slice(0, MAX_TOP_SAVERS),
    settings.humanize
  );
  const todayKey = localDayKey(sweepAtMs, tz);
  const sinceKey = localDayKey(Number.isFinite(parts.collectingSinceMs) ? parts.collectingSinceMs : sweepAtMs, tz);
  const trend = [];
  for (let i = 29; i >= 0; i--) {
    const day = addDaysToKey(todayKey, -i);
    if (day < sinceKey)
      continue;
    const d = parts.totals?.byDay?.[day];
    trend.push({ day, savedM: d?.savedM ?? 0, whpM: d?.whpM ?? 0, paidM: d?.paidM ?? 0 });
  }
  let coverageStart = Number.POSITIVE_INFINITY;
  for (const rows of Object.values(parts.minuteRows))
    for (const r of rows)
      coverageStart = Math.min(coverageStart, fromIso(r.t));
  const firstFullBucket = Number.isFinite(coverageStart) ? Math.ceil(coverageStart / RATIO_BUCKET_MS) * RATIO_BUCKET_MS : windowEndMs;
  const dayAgo = sweepAtMs - DAY_MS;
  const series = /* @__PURE__ */ new Map();
  for (const p of parts.previous?.ratioSeries ?? []) {
    const t = fromIso(p.t);
    if (t >= dayAgo && t < firstFullBucket)
      series.set(t, p.ratio);
  }
  for (const [t, b] of ratioBuckets(parts.minuteRows, firstFullBucket, windowEndMs))
    if (b.whp > 0)
      series.set(t, ratio(b.saved, b.whp));
  const ratioSeries = [...series.entries()].filter(([t]) => t >= dayAgo).sort((a, b) => a[0] - b[0]).slice(-MAX_RATIO_POINTS).map(([t, r]) => ({ t: toIso(t), ratio: r }));
  const incidents = (parts.incidents ?? []).filter((i) => !i.closedAt || fromIso(i.closedAt) >= sweepAtMs - DAY_MS).sort((a, b) => fromIso(b.openedAt) - fromIso(a.openedAt) || (a.id < b.id ? -1 : 1)).slice(0, MAX_SNAPSHOT_INCIDENTS);
  const everyCommit = Array.isArray(parts.timeline) ? [...parts.timeline].sort((a, b) => fromIso(b.committedAt) - fromIso(a.committedAt)) : allCommits(parts.timeline);
  const timeline = everyCommit.slice(0, MAX_SNAPSHOT_TIMELINE);
  const timelineTruncated = droppedRecentCommit(everyCommit, MAX_SNAPSHOT_TIMELINE, sweepAtMs);
  const deliveries = [...parts.deliveries ?? []].sort((a, b) => fromIso(b.at) - fromIso(a.at)).slice(0, MAX_SNAPSHOT_DELIVERIES);
  const headline = computeHeadline(parts.totals, sweepAtMs, tz, parts.collectingSinceMs, settings.criblCostCentsPerMonth, parts.windowEndMs);
  Object.assign(headline, savingsSplit(headline.mtdM, destinations, parts.totals, monthKey), costAddedFigures(flows));
  return {
    schemaVersion: 1,
    sweepAt: toIso(sweepAtMs),
    windowStart: windowStartIso,
    windowEnd: toIso(windowEndMs),
    mode: parts.mode,
    headline,
    ratePerSecM: lastMinuteSavedM / 60,
    flows,
    destinations,
    topSavers,
    unpricedOutputIds: [...new Set(destinations.filter((d) => d.unpriced).map((d) => d.outputId))],
    openIncidents: openIncidents.length,
    incidents,
    trend,
    ratioSeries,
    timeline,
    ...timelineTruncated ? { timelineTruncated: true } : {},
    deliveries,
    calls: parts.calls,
    collectingSince: toIso(Number.isFinite(parts.collectingSinceMs) ? parts.collectingSinceMs : sweepAtMs),
    metricsSource: parts.metricsSource,
    attributionSummary: summarizeAttribution(flows),
    flowCounts: flowCounts(flows)
  };
}
function flowCounts(flows) {
  const routes2 = /* @__PURE__ */ new Set();
  const sources = /* @__PURE__ */ new Set();
  let n = 0;
  for (const f of flows) {
    if (f.key === OTHER_FLOW_KEY) {
      n += f.folded ?? 0;
      continue;
    }
    n++;
    if (f.routeId && f.routeId !== "-")
      routes2.add(`${f.groupId}:${f.routeId}`);
    if (f.inputId && f.inputId !== "-")
      sources.add(`${f.groupId}:${f.inputId}`);
  }
  return { flows: n, routes: routes2.size, sources: sources.size };
}
var CHANGES_WINDOW_MS = 7 * DAY_MS;
function droppedRecentCommit(commits, keep, nowMs) {
  const first = commits[keep];
  return first !== void 0 && fromIso(first.committedAt) >= nowMs - CHANGES_WINDOW_MS;
}
function savingsSplit(mtdM, destinations, totals, monthKey) {
  if (Object.keys(totals?.byOutputMonth?.[monthKey] ?? {}).length === 0)
    return {};
  let diverted = 0;
  for (const d of destinations)
    if (isDiversion(d.counterfactual, d.outputId))
      diverted += Math.max(0, d.mtdSavedM);
  const divertedMtdM = Math.min(Math.max(0, mtdM), diverted);
  return { reducedMtdM: mtdM - divertedMtdM, divertedMtdM };
}
function costAddedFigures(flows) {
  const adding = flows.filter((f) => (f.addedPerDayM ?? 0) > 0);
  if (adding.length === 0)
    return {};
  return { addedPerDayM: adding.reduce((s, f) => s + (f.addedPerDayM ?? 0), 0), addedFlows: adding.length };
}
function utf8Length(s) {
  let n = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 128)
      n += 1;
    else if (c < 2048)
      n += 2;
    else if (c >= 55296 && c <= 56319 && i + 1 < s.length) {
      n += 4;
      i++;
    } else
      n += 3;
  }
  return n;
}
function snapshotBytes(s) {
  return utf8Length(JSON.stringify(s));
}
var OTHER_FLOW_KEY = makeFlowKey("-", "other", "-", "-", "-");
function foldFlows(flows, keep) {
  const existingOther = flows.find((f) => f.key === OTHER_FLOW_KEY);
  const ranked = flows.filter((f) => f.key !== OTHER_FLOW_KEY).sort((a, b) => b.whpPerDayM - a.whpPerDayM || (a.key < b.key ? -1 : 1));
  const rest = [...ranked.slice(keep), ...existingOther ? [existingOther] : []];
  if (rest.length === 0)
    return ranked.slice(0, keep);
  const total = (k) => sum(rest, (f) => f[k]);
  const folded = ranked.length - Math.min(keep, ranked.length) + (existingOther?.folded ?? 0);
  const other = {
    key: OTHER_FLOW_KEY,
    groupId: "-",
    inputId: "other",
    routeId: "-",
    pipelineId: "-",
    outputId: "-",
    inB: total("inB"),
    outB: total("outB"),
    whpM: total("whpM"),
    paidM: total("paidM"),
    savedM: total("savedM"),
    ratio: ratio(total("savedM"), total("whpM")),
    ratePerHourM: total("ratePerHourM"),
    savedPerDayM: total("savedPerDayM"),
    whpPerDayM: total("whpPerDayM"),
    paidPerDayM: total("paidPerDayM"),
    inBPerDay: total("inBPerDay"),
    outBPerDay: total("outBPerDay"),
    attribution: "proportional",
    sparkline: [],
    state: "ok",
    folded
  };
  return [...ranked.slice(0, keep), other];
}
function shrinkSparkline(values, points) {
  if (values.length <= points)
    return values;
  const out = [];
  for (let b = 0; b < points; b++) {
    const from = Math.floor(b * values.length / points);
    const to = Math.floor((b + 1) * values.length / points);
    out.push(sum(values.slice(from, to), (v) => v) / Math.max(1, to - from));
  }
  return out;
}
function halveSeries(series) {
  const out = [];
  for (let i = 0; i < series.length; i += 2) {
    const pair = series.slice(i, i + 2);
    out.push({ t: pair[0].t, ratio: sum(pair, (p) => p.ratio) / pair.length });
  }
  return out;
}
function keepCommits(x, keep) {
  const cut = x.timelineTruncated || droppedRecentCommit(x.timeline, keep, fromIso(x.sweepAt));
  return { timeline: x.timeline.slice(0, keep), ...cut ? { timelineTruncated: true } : {} };
}
function compactSnapshot(snapshot, maxJsonBytes) {
  if (snapshotBytes(snapshot) <= maxJsonBytes)
    return snapshot;
  let s = {
    ...snapshot,
    flows: foldFlows(snapshot.flows, COMPACT_FLOWS).map((f) => ({ ...f, sparkline: shrinkSparkline(f.sparkline, COMPACT_SPARKLINE_POINTS) }))
  };
  const steps = [
    (x) => x.ratioSeries.length > 144 ? { ...x, ratioSeries: halveSeries(x.ratioSeries) } : void 0,
    (x) => x.ratioSeries.length > 72 ? { ...x, ratioSeries: halveSeries(x.ratioSeries) } : void 0,
    (x) => x.ratioSeries.length > 36 ? { ...x, ratioSeries: halveSeries(x.ratioSeries) } : void 0,
    (x) => x.flows.length > 251 ? { ...x, flows: foldFlows(x.flows, 250) } : void 0,
    (x) => x.flows.length > 101 ? { ...x, flows: foldFlows(x.flows, 100) } : void 0,
    (x) => x.flows.length > 51 ? { ...x, flows: foldFlows(x.flows, 50) } : void 0,
    (x) => ({ ...x, incidents: x.incidents.slice(0, 20), ...keepCommits(x, 10), deliveries: x.deliveries.slice(0, 10) }),
    (x) => ({ ...x, flows: x.flows.map((f) => ({ ...f, sparkline: [] })) }),
    (x) => ({ ...x, incidents: x.incidents.filter((i) => !i.closedAt).slice(0, 10), ...keepCommits(x, 5), deliveries: [] })
  ];
  for (const step of steps) {
    if (snapshotBytes(s) <= maxJsonBytes)
      break;
    s = step(s) ?? s;
  }
  return s;
}

// core/sweep.ts
var DEFAULT_SWEEP_BUDGET = 35;
var LOCK_TTL_MS = 13e4;
var LOCK_RENEW_BELOW_MS = 45e3;
var LOCK_SKEW_MS = 5e3;
var SWEEP_TIME_BUDGET_MS = 1e5;
var NOTIFY_TIME_BUDGET_MS = 45e3;
var MAX_BACKFILL_MS = 46 * HOUR_MS;
var MAX_SWEEP_SPAN_MS = 24 * HOUR_MS;
var MAX_METERING_GAPS = 20;
var FIRST_RUN_SEED_MS = 60 * MINUTE_MS;
var FIRST_RUN_SEED_MAX_MS = MAX_SWEEP_SPAN_MS;
var FIRST_RUN_FLOW_MINUTES = 12e4;
function firstRunSeedMs(flowCount, maxMs = FIRST_RUN_SEED_MAX_MS) {
  if (!(flowCount > 0))
    return FIRST_RUN_SEED_MS;
  const minutes = Math.floor(FIRST_RUN_FLOW_MINUTES / flowCount);
  return Math.max(FIRST_RUN_SEED_MS, Math.min(maxMs, FIRST_RUN_SEED_MAX_MS, minutes * MINUTE_MS));
}
var SETTLE_MS = 2e4;
var HOLD_EMPTY_MAX_MS = 3 * MINUTE_MS;
var TIMELINE_EVERY_MIN = 5;
var INVENTORY_EVERY_MIN = 10;
var MAX_INVENTORY_EVERY_MIN = 60;
var EXPIRE_EVERY_MS = HOUR_MS;
var EXPIRY_FIRST_RESERVE = 20;
var EXPIRY_MIN_BATCH = 5;
var NOTIFY_LOG_CAP = 200;
var SNAPSHOT_MAX_BYTES = 9e4;
var COMMITS_PER_REFRESH = 50;
var MAX_FILE_LOOKUPS = 5;
var MAX_GROUPS_PER_REFRESH = 3;
var MAX_MISSING_GROUPS_PER_SWEEP = 8;
var GROUP_READ_CALLS = 4;
var FAILED_ATTEMPT_COOLDOWN_MS = 2 * MINUTE_MS;
var DELIVERY_OWNER_FRESH_MS = 9e4;
var UNDELIVERED_CLOSURE_MS = 10 * MINUTE_MS;
var MAX_INCIDENT_DELIVERIES = 20;
var RESERVE_CALLS = 6;
var MAX_OPEN_INCIDENT_DAYS = 5;
var READ_CONCURRENCY = 6;
var RATE_LIMIT_BACKOFF_MIN = [2, 4, 8, 16];
var PASSTHROUGH_PIPELINES = /* @__PURE__ */ new Set(["-", "", "passthrough", "mrd_passthrough"]);
function statusOf(e) {
  const s = e !== null && typeof e === "object" ? e.status : void 0;
  return typeof s === "number" ? s : void 0;
}
function createMeteredTransport(http, kv, opts) {
  const sleep = opts.sleep ?? defaultSleep;
  const delay = opts.retryDelayMs ?? RATE_LIMIT_RETRY_MS;
  let calls = 0;
  let hits = 0;
  let retries = 0;
  const take = (method, path) => {
    if (opts.hardCap !== void 0 && calls + 1 > opts.hardCap)
      throw new BudgetExceeded(opts.hardCap, calls, method, path);
    calls++;
  };
  async function metered(method, path, attempt, limited) {
    for (; ; ) {
      take(method, path);
      let value;
      let answer;
      let was429;
      try {
        value = await attempt();
        was429 = limited(value);
        answer = value;
      } catch (e) {
        if (statusOf(e) !== 429)
          throw e;
        was429 = true;
        answer = e;
      }
      if (!was429)
        return value;
      hits++;
      const after = retryAfterOf(answer, opts.clock.now());
      if (hits > 1)
        throw new RateLimited(method, path, after);
      const wait = retryWaitMs(after, delay);
      if (wait === void 0)
        throw new RateLimited(method, path, after);
      retries++;
      await sleep(wait);
    }
  }
  const never = () => false;
  const kvPath = (key) => `/kvstore/${key}`;
  return {
    http: {
      request: (method, path, body, reqOpts) => metered(
        method,
        path,
        () => http.request(method, path, body, reqOpts),
        (r) => r.status === 429
      )
    },
    kv: {
      get: (key) => metered("GET", kvPath(key), () => kv.get(key), never),
      put: (key, value) => metered("PUT", kvPath(key), () => kv.put(key, value), never),
      del: (key) => metered("DELETE", kvPath(key), () => kv.del(key), never),
      list: (prefix) => metered("POST", "/kvstore/keys", () => kv.list(prefix), never)
    },
    rawKv: {
      get: (key) => (calls++, kv.get(key)),
      put: (key, value) => (calls++, kv.put(key, value)),
      del: (key) => (calls++, kv.del(key)),
      list: (prefix) => (calls++, kv.list(prefix))
    },
    calls: () => calls,
    retries: () => retries,
    limitHits: () => hits
  };
}
var rateMemory = /* @__PURE__ */ new WeakMap();
function rateLimitMemoryFor(kv) {
  let m = rateMemory.get(kv);
  if (!m)
    rateMemory.set(kv, m = { streak: 0 });
  return m;
}
function backoffMinutes(streak) {
  const i = Math.max(1, Math.min(streak, RATE_LIMIT_BACKOFF_MIN.length)) - 1;
  return RATE_LIMIT_BACKOFF_MIN[i];
}
function nextRateLimit(prev, limited, stopped, startedMs) {
  if (!limited)
    return void 0;
  const streak = prev.streak + 1;
  const since = prev.since ?? toIso(startedMs);
  if (!stopped)
    return { since, streak };
  return { since, streak, until: toIso(minuteFloor(startedMs) + (backoffMinutes(streak) + 1) * MINUTE_MS) };
}
function backoffInForce(mem, meta, nowMs) {
  const metaUntil = meta?.rateLimitedUntil ? fromIso(meta.rateLimitedUntil) : Number.NaN;
  const memUntil = mem.until ?? Number.NaN;
  const until = Math.max(Number.isFinite(metaUntil) ? metaUntil : -Infinity, Number.isFinite(memUntil) ? memUntil : -Infinity);
  if (!(nowMs < until))
    return void 0;
  const sinceMs = meta?.rateLimitedSince ? fromIso(meta.rateLimitedSince) : mem.since ?? nowMs;
  return { since: toIso(Number.isFinite(sinceMs) ? sinceMs : nowMs), until: toIso(until), streak: Math.max(mem.streak, meta?.consecutiveRateLimited ?? 0) };
}
function remember(mem, status) {
  if (!status) {
    mem.streak = 0;
    delete mem.since;
    delete mem.until;
    return;
  }
  mem.streak = status.streak;
  mem.since = fromIso(status.since);
  if (status.until)
    mem.until = fromIso(status.until);
  else
    delete mem.until;
}
function recordGap(gaps, fromMs, toMs, nowIso) {
  const from = minuteFloor(fromMs);
  const to = minuteFloor(toMs);
  const list = [...gaps ?? []];
  if (!(to > from))
    return list;
  const last = list.at(-1);
  if (last && fromIso(last.from) <= to && from <= fromIso(last.to)) {
    const f = Math.min(fromIso(last.from), from);
    const t = Math.max(fromIso(last.to), to);
    list[list.length - 1] = { from: toIso(f), to: toIso(t), minutes: Math.round((t - f) / MINUTE_MS), recordedAt: nowIso };
  } else {
    list.push({ from: toIso(from), to: toIso(to), minutes: Math.round((to - from) / MINUTE_MS), recordedAt: nowIso });
  }
  return list.slice(-MAX_METERING_GAPS);
}
function windowWaitMs(retryAfterMs, nowMs) {
  const toNextMinute = minuteFloor(nowMs) + MINUTE_MS - nowMs + 1e3;
  return Math.min(RETRY_AFTER_MAX_MS, Math.max(1e3, retryAfterMs ?? toNextMinute));
}
var NOOP_LOGGER2 = {
  info: () => void 0,
  warn: () => void 0,
  error: () => void 0
};
function resolveDeps(deps) {
  const partial = deps;
  return {
    ...deps,
    logger: partial.logger ?? NOOP_LOGGER2,
    sleep: partial.sleep ?? defaultSleep,
    owner: partial.owner || `sweep:${partial.runtime ?? "ui"}`,
    appVersion: partial.appVersion ?? "0.0.0",
    build: partial.build ?? "release",
    runtime: partial.runtime ?? "ui",
    workspace: partial.workspace ?? "",
    linkBase: partial.linkBase ?? ""
  };
}
function minuteKey(ms) {
  return toIso(minuteFloor(ms)).slice(0, 16);
}
async function mapLimit2(items2, limit, fn) {
  const out = new Array(items2.length);
  let next = 0;
  const workers = Array.from({ length: Math.max(1, Math.min(limit, items2.length)) }, async () => {
    while (next < items2.length) {
      const i = next++;
      out[i] = await fn(items2[i]);
    }
  });
  await Promise.all(workers);
  return out;
}
var zeroMoney = () => ({ whpM: 0, paidM: 0, savedM: 0 });
var addMoney = (acc, r) => {
  acc.whpM += r.whpM;
  acc.paidM += r.paidM;
  acc.savedM += r.savedM;
};
function moneyAt(doc, t) {
  const total = zeroMoney();
  const byOutput = /* @__PURE__ */ new Map();
  let any = false;
  for (const [key, rows] of Object.entries(doc?.flows ?? {})) {
    const row = rows.find((r) => r.t === t);
    if (!row)
      continue;
    any = true;
    addMoney(total, row);
    const parts = key.split("|");
    const outKey = `${parts[0]}:${parts[4]}`;
    const acc = byOutput.get(outKey) ?? zeroMoney();
    addMoney(acc, row);
    byOutput.set(outKey, acc);
  }
  return { any, total, byOutput };
}
function replaceMinute(doc, hourIso, t, rows) {
  const flows = {};
  for (const [key, list] of Object.entries(doc?.flows ?? {})) {
    const kept = rows[key] ? list : list.filter((r) => r.t !== t);
    if (kept.length > 0)
      flows[key] = kept;
  }
  return upsertMinuteRows({ schemaVersion: 1, bucketStart: doc?.bucketStart ?? hourIso, flows }, hourIso, rows);
}
function routeLabel(flow, inventory, labels) {
  if (!PASSTHROUGH_PIPELINES.has(flow.pipelineId))
    return humanize(flow.pipelineId, labels);
  const route = inventory?.byGroup?.[flow.groupId]?.routes?.find((r) => r.id === flow.routeId);
  return humanize(route?.name && !labels[flow.routeId] ? route.name : flow.routeId, labels);
}
function describeError(e) {
  return e instanceof Error ? e.message : String(e);
}
function windowHasTraffic(w) {
  const any = (m) => Object.values(m ?? {}).some((v) => v.bytes > 0 || v.events > 0);
  return any(w.inputs) || any(w.outputs);
}
function holdBackEnd(windows, hadTraffic, newStart, windowEnd) {
  let last = -1;
  for (let i = windows.length - 1; i >= 0; i--) {
    if (hadTraffic(i)) {
      last = i;
      break;
    }
  }
  if (last < 0 || last === windows.length - 1)
    return windowEnd;
  const heldStart = Math.max(fromIso(windows[last + 1].windowStart), newStart);
  if (!(heldStart < windowEnd))
    return windowEnd;
  return windowEnd - (heldStart + MINUTE_MS) < HOLD_EMPTY_MAX_MS ? heldStart : windowEnd;
}
function isScheduledOwner(o) {
  return !!o && (o.startsWith("runner:") || o.startsWith("backend:") || o === "sweep:backend");
}
function deliveryOwnedElsewhere(meta, owner, nowMs) {
  const fresh = (o, atIso) => {
    if (!o || o === owner || !isScheduledOwner(o))
      return false;
    const at = atIso ? fromIso(atIso) : Number.NaN;
    return nowMs - at < DELIVERY_OWNER_FRESH_MS;
  };
  return fresh(meta?.lastSweepOwner, meta?.lastSweepAt) || fresh(meta?.deliveryOwner, meta?.deliveryOwnerAt);
}
function inFailedAttemptCooldown(i, nowMs) {
  const at = i.lastAttemptAt ? fromIso(i.lastAttemptAt) : Number.NaN;
  if (!Number.isFinite(at))
    return false;
  const ok = i.lastNotifiedAt ? fromIso(i.lastNotifiedAt) : Number.NaN;
  return !(ok >= at) && nowMs - at < FAILED_ATTEMPT_COOLDOWN_MS;
}
function undeliveredClosure(i, nowMs) {
  const closed = i.closedAt ? fromIso(i.closedAt) : Number.NaN;
  if (!Number.isFinite(closed) || !(nowMs - closed < UNDELIVERED_CLOSURE_MS))
    return false;
  const told = i.lastNotifiedAt ? fromIso(i.lastNotifiedAt) : Number.NaN;
  if (told >= closed)
    return false;
  return Number.isFinite(told) || i.type === "goodnews";
}
function roomFor(t, limit, cost, stillNeeded) {
  return limit - t.calls() - cost - stillNeeded;
}
async function runSweep(deps, opts) {
  const d = resolveDeps(deps);
  const startedAt = d.clock.now();
  const nowMs = opts.nowMs ?? startedAt;
  const t = createMeteredTransport(d.http, d.kv, {
    clock: d.clock,
    sleep: d.sleep,
    hardCap: deps.budget
  });
  const docs = createKvDocs({
    kv: t.kv,
    codec: d.codec,
    clock: d.clock,
    logger: d.logger
  });
  const rawDocs = createKvDocs({
    kv: t.rawKv,
    codec: d.codec,
    clock: d.clock,
    logger: d.logger
  });
  const base = {
    calls: 0,
    ms: 0,
    minutesProcessed: 0,
    backfilledMinutes: 0,
    opened: 0,
    closed: 0,
    notified: 0,
    snapshotBytes: 0
  };
  const done = (r) => ({
    ...base,
    ...r,
    calls: t.calls(),
    ms: d.clock.now() - startedAt
  });
  const windowEnd = minuteFloor(nowMs - SETTLE_MS);
  let meta = null;
  let metaRead = false;
  let locked = false;
  const lock = { at: startedAt };
  const progress = {};
  const mem = rateLimitMemoryFor(d.kv);
  const prevRate = () => {
    const since = meta?.rateLimitedSince ?? (mem.since !== void 0 ? toIso(mem.since) : void 0);
    return { streak: Math.max(mem.streak, meta?.consecutiveRateLimited ?? 0), ...since ? { since } : {} };
  };
  const backingOff = (status, withMeta) => {
    d.logger.info(`sweep: rate limited by the Leader since ${status.since}; backing off until ${status.until}`);
    return done({ skipped: "backoff", error: "rate_limited", rateLimit: status, ...withMeta ? { meta: withMeta } : {} });
  };
  try {
    if (opts.mode !== "manual") {
      const remembered = backoffInForce(mem, null, nowMs);
      if (remembered)
        return backingOff(remembered, null);
      meta = await docs.getMeta();
      metaRead = true;
      if (meta && !(meta.consecutiveRateLimited > 0) && !meta.rateLimitedUntil)
        remember(mem, void 0);
      const recorded = backoffInForce(mem, meta, nowMs);
      if (recorded)
        return backingOff(recorded, meta);
      const through = meta?.meteredThrough ? fromIso(meta.meteredThrough) : Number.NaN;
      if (through >= windowEnd) {
        if (d.runtime === "ui")
          return done({ skipped: "current" });
        const current = await scheduledCheckIn(d, docs, meta, nowMs);
        if (current)
          return done(current);
      }
    }
    lock.at = d.clock.now();
    locked = await docs.acquireLock(d.owner, LOCK_TTL_MS);
    if (!locked)
      return done({ skipped: "locked" });
  } catch (e) {
    if (e instanceof RateLimited) {
      const rate = nextRateLimit(prevRate(), true, true, nowMs);
      remember(mem, rate);
      return done({ skipped: "rate_limited", error: "rate_limited", ...rate ? { rateLimit: rate } : {} });
    }
    if (e instanceof BudgetExceeded)
      return done({ skipped: "budget", error: "budget" });
    d.logger.error("sweep: could not start", e);
    return done({ error: describeError(e) });
  }
  let outcome;
  try {
    if (!metaRead) {
      meta = await docs.getMeta();
      metaRead = true;
    }
    outcome = await sweepLocked({
      d,
      mode: opts.mode,
      nowMs,
      windowEnd,
      startedAt,
      t,
      docs,
      meta,
      lock,
      progress,
      prevRate: prevRate()
    });
    remember(mem, progress.rate ?? void 0);
    if (progress.rate)
      outcome = { ...outcome, rateLimit: progress.rate };
  } catch (e) {
    if (e instanceof LockLost) {
      d.logger.warn(`sweep stopped: ${e.message}`);
      return done({ skipped: "locked", error: "lock_lost" });
    }
    const stopped = e instanceof RateLimited || e instanceof BudgetExceeded || e instanceof TimeBudgetExceeded;
    const code = e instanceof RateLimited ? "rate_limited" : e instanceof BudgetExceeded ? "budget" : e instanceof TimeBudgetExceeded ? "time_budget" : describeError(e);
    if (stopped)
      d.logger.warn(`sweep stopped: ${code}`);
    else
      d.logger.error("sweep failed", e);
    const rateLimited = e instanceof RateLimited;
    if (rateLimited) {
      const wait = windowWaitMs(e.retryAfterMs, d.clock.now());
      d.logger.warn(`sweep: waiting ${Math.round(wait / 1e3)} s for the Leader's rate-limit window before recording the failure`);
      await d.sleep(wait);
    }
    const limited = rateLimited || t.limitHits() > 0;
    const rate = limited ? nextRateLimit(prevRate(), true, rateLimited, nowMs) : void 0;
    if (limited)
      remember(mem, rate);
    const timelineAt = await writeFetchedTimeline(rawDocs, progress, toIso(nowMs), d.logger);
    const metaAfter = await recordFailure(rawDocs, meta, metaRead, code, rateLimited, d.logger, {
      kvRefused: isKvWriteRefusal(e),
      progress,
      nowIso: toIso(nowMs),
      ...rate ? { rate } : {},
      ...timelineAt ? { timelineRefreshedAt: timelineAt } : {}
    });
    const skipped = rateLimited ? "rate_limited" : e instanceof BudgetExceeded ? "budget" : void 0;
    outcome = {
      ...skipped ? { skipped } : {},
      error: code,
      ...metaAfter ? { meta: metaAfter } : {},
      ...rate ? { rateLimit: rate } : {}
    };
  }
  await releaseLock(rawDocs, d, lock.at);
  return done(outcome);
}
async function scheduledCheckIn(d, docs, meta, nowMs) {
  if (meta.deliveryDeferredAt) {
    d.logger.info("sweep: this minute is metered, but the tab that metered it left alerts to deliver; sweeping in full");
    return null;
  }
  if (isScheduledOwner(meta.lastSweepOwner))
    return { skipped: "current", meta };
  const stamped = { ...meta, deliveryOwner: d.owner, deliveryOwnerAt: toIso(nowMs) };
  try {
    await docs.putMeta(stamped);
    return { skipped: "current", meta: stamped };
  } catch (e) {
    if (e instanceof RateLimited)
      return { skipped: "rate_limited", error: "rate_limited" };
    if (e instanceof BudgetExceeded)
      return { skipped: "budget", error: "budget" };
    d.logger.warn("sweep: could not check in (the next sweep tries again)", describeError(e));
    return { skipped: "current", meta };
  }
}
var TimeBudgetExceeded = class extends Error {
  constructor(ms) {
    super(`sweep exceeded its ${SWEEP_TIME_BUDGET_MS / 1e3} s time budget (${Math.round(ms / 1e3)} s); writes abandoned`);
    this.name = "TimeBudgetExceeded";
  }
};
var LockLost = class extends Error {
  constructor(ms, holder) {
    super(`lock/meter was taken${holder ? ` by ${holder}` : ""} ${Math.round(ms / 1e3)} s into the sweep; writes abandoned`);
    this.name = "LockLost";
  }
};
function isKvWriteRefusal(e) {
  return e instanceof KvHttpError && e.op === "PUT" && e.status >= 400 && e.status !== 429;
}
async function expireKeys(docs, nowMs, room, progress) {
  progress.expiryRan = true;
  const [roll, incidents] = [await docs.listKeysWithChunks("roll/"), await docs.listKeysWithChunks("incidents/")];
  const keys = [...roll.keys, ...incidents.keys];
  const chunks = { ...roll.chunks, ...incidents.chunks };
  const expired = expiredKeys(keys, nowMs);
  let deleted = 0;
  for (const k of expired) {
    const listed = chunks[k] ?? [];
    if (room() < 1 + listed.length)
      break;
    await docs.del(k, { listed });
    deleted++;
  }
  progress.kvDatedKeys = keys.length - deleted;
  progress.lastExpiredAt = toIso(nowMs);
  progress.expiryBacklog = expired.length - deleted;
  return { listed: keys.length, expired: expired.length, deleted };
}
async function expireKeysSafely(docs, nowMs, room, progress, logger) {
  try {
    return await expireKeys(docs, nowMs, room, progress);
  } catch (e) {
    if (e instanceof RateLimited || e instanceof BudgetExceeded)
      throw e;
    logger.warn("sweep: the key expiry pass failed; the next pass tries again", describeError(e));
    return void 0;
  }
}
async function keepLock(a, stage) {
  const before = a.d.clock.now();
  if (a.lock.at + LOCK_TTL_MS - before >= LOCK_RENEW_BELOW_MS)
    return;
  if (!await a.docs.renewLock(a.d.owner, LOCK_TTL_MS)) {
    const holder = await a.docs.getLock().catch(() => null);
    throw new LockLost(before - a.startedAt, holder?.owner);
  }
  a.lock.at = before;
  a.d.logger.info(`sweep: renewed lock/meter before ${stage} (${Math.round((before - a.startedAt) / 1e3)} s into the sweep)`);
}
async function releaseLock(rawDocs, d, lockedAt) {
  try {
    const now = d.clock.now();
    if (now - lockedAt < LOCK_TTL_MS - LOCK_SKEW_MS)
      await rawDocs.putDoc(KEYS.lock, {
        owner: d.owner,
        expiresAt: toIso(now)
      });
    else
      await rawDocs.releaseLock(d.owner);
  } catch (e) {
    d.logger.warn("sweep: lock release failed (it expires on its own)", e);
  }
}
async function writeFetchedTimeline(rawDocs, progress, nowIso, logger) {
  const pending = progress.timeline;
  if (!pending || pending.written || pending.groups.size === 0)
    return void 0;
  try {
    let fresh = await rawDocs.getTimeline() ?? { schemaVersion: 1, updatedAt: nowIso, byGroup: {} };
    for (const [gid, list] of pending.groups)
      fresh = mergeCommits(fresh, gid, list, nowIso);
    await rawDocs.putTimeline(fresh);
    pending.written = true;
    return nowIso;
  } catch (e) {
    logger.warn("sweep: could not keep the fetched timeline after the stop (the next sweep fetches it again)", e);
    return void 0;
  }
}
async function recordFailure(rawDocs, meta, metaRead, code, rateLimited, logger, more) {
  try {
    const current = metaRead ? meta : await rawDocs.getMeta();
    if (!current)
      return null;
    const next = {
      ...current,
      sweepErrors: (current.sweepErrors ?? 0) + 1,
      lastError: code
    };
    if (more.kvRefused)
      next.kvWriteFailingSince = current.kvWriteFailingSince ?? more.nowIso;
    if (more.progress.lastExpiredAt)
      next.lastExpiredAt = more.progress.lastExpiredAt;
    if (more.timelineRefreshedAt)
      next.timelineRefreshedAt = more.timelineRefreshedAt;
    if (more.progress.kvDatedKeys !== void 0)
      next.kvDatedKeys = more.progress.kvDatedKeys;
    if (more.progress.expiryBacklog !== void 0) {
      if (more.progress.expiryBacklog > 0)
        next.expiryBacklog = more.progress.expiryBacklog;
      else
        delete next.expiryBacklog;
    }
    if (more.rate) {
      next.consecutiveRateLimited = more.rate.streak;
      next.rateLimitedSince = more.rate.since;
      if (more.rate.until)
        next.rateLimitedUntil = more.rate.until;
      else
        delete next.rateLimitedUntil;
    }
    if (rateLimited) {
      next.consecutiveRateLimited = Math.max(next.consecutiveRateLimited ?? 0, (current.consecutiveRateLimited ?? 0) + 1);
      if (next.consecutiveRateLimited % 3 === 0) {
        next.inventoryRefreshEveryMin = Math.min(MAX_INVENTORY_EVERY_MIN, (current.inventoryRefreshEveryMin ?? INVENTORY_EVERY_MIN) * 2);
      }
    }
    await rawDocs.putMeta(next);
    return next;
  } catch (e) {
    logger.warn("sweep: could not record the failure in meta", e);
    return null;
  }
}
async function sweepLocked(a) {
  const { d, mode, nowMs, windowEnd, t, docs, meta } = a;
  const nowIso = toIso(nowMs);
  const target = d.budget ?? DEFAULT_SWEEP_BUDGET;
  const limitFor = (force) => force ? d.budget ?? Number.POSITIVE_INFINITY : target;
  const demoBuild = d.build === "demo";
  const { progress } = a;
  const failingSince = meta?.kvWriteFailingSince ? fromIso(meta.kvWriteFailingSince) : Number.NaN;
  const expiredBefore = meta?.lastExpiredAt ? fromIso(meta.lastExpiredAt) : Number.NaN;
  const backlogBefore = meta?.expiryBacklog ?? 0;
  if (Number.isFinite(failingSince) && (!(expiredBefore >= failingSince) || !(nowMs - expiredBefore < EXPIRE_EVERY_MS) || backlogBefore > 0)) {
    const pass = await expireKeysSafely(docs, nowMs, () => target - t.calls() - EXPIRY_FIRST_RESERVE, progress, d.logger);
    if (pass)
      d.logger.warn(
        `sweep: the KV store has refused writes since ${meta?.kvWriteFailingSince}; expiry pass first: ${pass.deleted} of ${pass.expired} expired key(s) deleted, ${pass.listed - pass.deleted} dated key(s) left`
      );
  }
  const [storedSettings, storedPrices, storedInventory, storedBaselines, storedTimeline, demoState, storedTotals, prevSnapshot] = await Promise.all([
    docs.getSettings(),
    docs.getPrices(),
    docs.getInventory(),
    docs.getBaselines(),
    docs.getTimeline(),
    demoBuild ? docs.getDemoState() : Promise.resolve(null),
    docs.getTotals(),
    docs.getSnapshot()
  ]);
  const settings = mergeSettings(storedSettings ?? {}, defaultSettings(nowIso, "UTC"));
  const tz = settings.displayTimezone || "UTC";
  const labels = settings.humanize ?? {};
  const prices = storedPrices ?? emptyPrices(nowIso);
  let inventory = storedInventory;
  let baselines = storedBaselines ?? emptyBaselines(nowIso);
  let timeline = storedTimeline ?? {
    schemaVersion: 1,
    updatedAt: nowIso,
    byGroup: {}
  };
  let totals = storedTotals ?? emptyTotals(nowIso);
  const totalsThrough = storedTotals?.meteredThrough !== void 0 && storedTotals.meteredAt === storedTotals.updatedAt ? fromIso(storedTotals.meteredThrough) : Number.NaN;
  const priced = (storedPrices?.versions ?? []).length > 0;
  const th = effectiveThresholds(settings);
  const muted = demoState?.muted ?? {};
  let groupFields = {
    ...meta?.groupsKnown ? { groupsKnown: meta.groupsKnown } : {},
    ...meta?.groupsListedAt ? { groupsListedAt: meta.groupsListedAt } : {},
    ...meta?.groupsMetered ? { groupsMetered: meta.groupsMetered } : {},
    ...meta?.inventorySkippedAt ? { inventorySkippedAt: meta.inventorySkippedAt } : {}
  };
  const sweptMeta = (m) => {
    const minute = minuteKey(nowMs);
    const callsNow = t.calls() + 2;
    const next = {
      schemaVersion: 1,
      installedAt: meta?.installedAt ?? nowIso,
      collectingSince: m.collectingSince,
      appVersion: d.appVersion,
      build: d.build,
      metricsSource: "metrics-query",
      lastSweepAt: nowIso,
      lastSweepMs: d.clock.now() - a.startedAt,
      lastSweepCalls: callsNow,
      lastSweepMode: mode,
      lastSweepOwner: d.owner,
      sweepErrors: meta?.sweepErrors ?? 0,
      consecutiveRateLimited: 0,
      sweepCount: (meta?.sweepCount ?? 0) + 1,
      callsThisMinute: {
        minute,
        calls: (meta?.callsThisMinute?.minute === minute ? meta.callsThisMinute.calls : 0) + callsNow
      }
    };
    if (m.meteredThrough)
      next.meteredThrough = m.meteredThrough;
    if (meta?.lastWeeklySentAt)
      next.lastWeeklySentAt = meta.lastWeeklySentAt;
    if (m.lastExpiredAt)
      next.lastExpiredAt = m.lastExpiredAt;
    const datedKeys = progress.kvDatedKeys ?? meta?.kvDatedKeys;
    if (datedKeys !== void 0)
      next.kvDatedKeys = datedKeys;
    const backlogAfter = progress.expiryBacklog ?? meta?.expiryBacklog ?? 0;
    if (backlogAfter > 0)
      next.expiryBacklog = backlogAfter;
    if (m.timelineRefreshedAt)
      next.timelineRefreshedAt = m.timelineRefreshedAt;
    if (meta?.inventoryRefreshEveryMin !== void 0)
      next.inventoryRefreshEveryMin = meta.inventoryRefreshEveryMin;
    Object.assign(next, groupFields);
    if (d.runtime !== "ui" && isScheduledOwner(d.owner)) {
      next.deliveryOwner = d.owner;
      next.deliveryOwnerAt = nowIso;
    } else if (meta?.deliveryOwner && meta.deliveryOwnerAt) {
      next.deliveryOwner = meta.deliveryOwner;
      next.deliveryOwnerAt = meta.deliveryOwnerAt;
    }
    if (m.deliveryDeferredAt)
      next.deliveryDeferredAt = m.deliveryDeferredAt;
    const webhooks = d.envWebhooks !== void 0 ? d.envWebhooks.map(webhookDescriptor) : meta?.deliveryWebhooks;
    if (webhooks && webhooks.length > 0)
      next.deliveryWebhooks = webhooks;
    const gaps = m.gap ? recordGap(meta?.gaps, m.gap.from, m.gap.to, nowIso) : meta?.gaps;
    if (gaps && gaps.length > 0)
      next.gaps = gaps;
    const rate = nextRateLimit(a.prevRate, t.limitHits() > 0, false, nowMs);
    progress.rate = rate ?? null;
    if (rate) {
      next.consecutiveRateLimited = rate.streak;
      next.rateLimitedSince = rate.since;
      if (rate.until)
        next.rateLimitedUntil = rate.until;
    }
    return next;
  };
  const incidentDocs = /* @__PURE__ */ new Map();
  const prevOpen = (prevSnapshot?.incidents ?? []).filter((i) => !i.closedAt);
  const dayKeys = new Set(prevOpen.map((i) => incidentsDocKey(fromIso(i.openedAt))));
  if (!prevSnapshot || (prevSnapshot.openIncidents ?? 0) > prevOpen.length) {
    dayKeys.add(incidentsDocKey(nowMs));
    dayKeys.add(incidentsDocKey(nowMs - DAY_MS));
  }
  const oldestDay = incidentsDocKey(nowMs - MAX_OPEN_INCIDENT_DAYS * DAY_MS);
  const toRead = [...dayKeys].filter((k) => k >= oldestDay).sort();
  const incidentReads = await mapLimit2(toRead, READ_CONCURRENCY, (k) => docs.getIncidents(k));
  toRead.forEach((k, i) => incidentDocs.set(k, incidentReads[i]?.items ?? []));
  const openById = /* @__PURE__ */ new Map();
  for (const i of prevOpen)
    if (!incidentDocs.has(incidentsDocKey(fromIso(i.openedAt))))
      openById.set(i.id, i);
  for (const items2 of incidentDocs.values())
    for (const i of items2)
      if (!i.closedAt)
        openById.set(i.id, i);
  const floorLimit = windowEnd - MAX_BACKFILL_MS;
  const oldThrough = meta?.meteredThrough ? fromIso(meta.meteredThrough) : Number.NaN;
  const firstRun = !Number.isFinite(oldThrough);
  const storedSince = meta?.collectingSince ? fromIso(meta.collectingSince) : Number.NaN;
  const lastFailedOnLimits = a.prevRate.streak > 0 || meta?.lastError === "rate_limited" || meta?.lastError === "budget" || meta?.lastError === "time_budget";
  const reachMax = firstRun && lastFailedOnLimits ? FIRST_RUN_SEED_MS : d.firstRunReachMs ?? FIRST_RUN_SEED_MAX_MS;
  const planRange = (seedFlows) => {
    let newStart2;
    if (firstRun) {
      const bySize = windowEnd - firstRunSeedMs(seedFlows, reachMax);
      const seed = Number.isFinite(storedSince) && storedSince < windowEnd ? Math.min(minuteFloor(storedSince), bySize) : bySize;
      newStart2 = Math.max(seed, floorLimit);
    } else {
      newStart2 = Math.max(Math.min(oldThrough, windowEnd), floorLimit);
    }
    let queryStart2 = newStart2;
    if (!firstRun) {
      const rewrite = Math.min(newStart2, windowEnd) - MINUTE_MS;
      if (rewrite < oldThrough && rewrite >= floorLimit - MINUTE_MS)
        queryStart2 = rewrite;
    }
    const collectingSinceMs2 = firstRun ? newStart2 : Number.isFinite(storedSince) ? Math.min(storedSince, newStart2) : newStart2;
    const rangeEnd2 = Math.min(windowEnd, newStart2 + MAX_SWEEP_SPAN_MS);
    const touchedHours2 = [];
    for (let h = hourFloor(queryStart2); h < rangeEnd2; h += HOUR_MS)
      touchedHours2.push(h);
    return { newStart: newStart2, queryStart: queryStart2, collectingSinceMs: collectingSinceMs2, rangeEnd: rangeEnd2, sliced: rangeEnd2 < windowEnd, touchedHours: touchedHours2 };
  };
  let { newStart, queryStart, collectingSinceMs, rangeEnd, sliced, touchedHours } = planRange(
    storedInventory ? buildFlows(storedInventory, settings).length : 0
  );
  const gapFrom = firstRun ? Number.NaN : oldThrough;
  const gap = gapFrom < floorLimit ? { from: gapFrom, to: floorLimit } : void 0;
  if (gap)
    d.logger.warn(
      `sweep: ${Math.round((gap.to - gap.from) / MINUTE_MS)} minute(s) from ${toIso(gap.from)} are older than the Leader keeps metrics and were never metered; recorded in meta.gaps`
    );
  const snapshotHoursFor = (end) => [.../* @__PURE__ */ new Set([hourFloor(end - HOUR_MS), hourFloor(end - MINUTE_MS)])];
  const foldsFor = (end) => {
    const hours = touchedHours.filter((h) => h + HOUR_MS <= end);
    return {
      hours,
      days: [...new Set(hours.map((h) => utcDayKey(h)))],
      dayFolds: [...new Set(hours.filter((h) => (h + HOUR_MS) % DAY_MS === 0).map((h) => utcDayKey(h)))]
    };
  };
  let readHours = [];
  let foldDays = [];
  let dayFolds = [];
  const planReads = () => {
    readHours = [.../* @__PURE__ */ new Set([...touchedHours, ...snapshotHoursFor(rangeEnd)])].sort((x, y) => x - y);
    ({ days: foldDays, dayFolds } = foldsFor(rangeEnd));
  };
  planReads();
  const mandatoryAfterRefresh = () => 3 + readHours.length + touchedHours.length + foldDays.length * 2 + dayFolds.length * 2 + 5 + RESERVE_CALLS;
  let knownGroups = Object.keys(inventory?.byGroup ?? {});
  const refreshed = /* @__PURE__ */ new Map();
  progress.timeline = { groups: refreshed, written: false };
  const refreshTimeline = async (groups, stillNeeded, force) => {
    if (groups.length === 0)
      return false;
    const room = roomFor(t, limitFor(force), groups.length + 2, stillNeeded);
    if (room < 0)
      return false;
    const perGroupShow = Math.max(0, Math.min(MAX_FILE_LOOKUPS, Math.floor(room / groups.length)));
    let any = false;
    for (const gid of groups) {
      try {
        const commits2 = await fetchCommits(t.http, gid, COMMITS_PER_REFRESH, {
          withFiles: perGroupShow > 0,
          maxShow: perGroupShow,
          cached: timeline.byGroup[gid] ?? []
        });
        refreshed.set(gid, commits2);
        timeline = mergeCommits(timeline, gid, commits2, nowIso);
        any = true;
      } catch (e) {
        if (e instanceof RateLimited || e instanceof BudgetExceeded)
          throw e;
        d.logger.warn(`sweep: timeline refresh for ${gid} failed; keeping the stored timeline`, describeError(e));
      }
    }
    return any;
  };
  const timelineEvery = d.timelineEveryMin ?? TIMELINE_EVERY_MIN;
  const lastTimelineRefresh = meta?.timelineRefreshedAt ? fromIso(meta.timelineRefreshedAt) : Number.NaN;
  const timelineDue = mode === "manual" || !storedTimeline || timelineEvery > 0 && !(nowMs - lastTimelineRefresh < timelineEvery * MINUTE_MS);
  let timelineRefreshed = false;
  if (priced && timelineDue && knownGroups.length > 0)
    timelineRefreshed = await refreshTimeline(knownGroups, mandatoryAfterRefresh(), mode === "manual");
  const inventoryEvery = d.inventoryEveryMin ?? meta?.inventoryRefreshEveryMin ?? INVENTORY_EVERY_MIN;
  const invAt = inventory ? fromIso(inventory.updatedAt) : Number.NaN;
  const fetchedAt = (gid) => {
    const at = inventory?.groupsFetchedAt?.[gid];
    return at ? fromIso(at) : invAt;
  };
  let listing = Array.isArray(meta?.groupsKnown) ? [...meta.groupsKnown] : void 0;
  let listedAt = meta?.groupsListedAt;
  let listedNow = false;
  const listedAtMs = listedAt ? fromIso(listedAt) : Number.NaN;
  if (!inventory || mode === "manual" || !listing || !Number.isFinite(listedAtMs) || utcHourKey(listedAtMs) !== utcHourKey(nowMs)) {
    const res = await t.http.request("GET", streamGroups());
    if (res.ok) {
      listing = workerGroupIds(res.json);
      listedAt = nowIso;
      listedNow = true;
    } else
      d.logger.warn(`sweep: listing worker groups failed (HTTP ${res.status}); keeping the known groups`);
  }
  const listed = listing && listing.length > 0 ? listing : knownGroups.length > 0 ? knownGroups : ["default"];
  const committedSince = (gid) => {
    const since = fetchedAt(gid);
    return Number.isFinite(since) && (timeline.byGroup[gid] ?? []).some((c) => {
      const at = commitTimeMs(c);
      return at >= since && at < rangeEnd;
    });
  };
  const inInventory = (gid) => !!inventory?.byGroup?.[gid];
  const byAge = (a2, b) => (fetchedAt(a2) || 0) - (fetchedAt(b) || 0) || listed.indexOf(a2) - listed.indexOf(b);
  const missing = listed.filter((g) => !inInventory(g)).sort((a2, b) => Number(b === "default") - Number(a2 === "default"));
  const forced = [.../* @__PURE__ */ new Set([...missing.slice(0, MAX_MISSING_GROUPS_PER_SWEEP), ...knownGroups.filter((g) => listed.includes(g) && committedSince(g))])];
  if (mode === "manual") {
    for (const g of knownGroups.filter((x) => listed.includes(x)).sort(byAge).slice(0, MAX_GROUPS_PER_REFRESH))
      if (!forced.includes(g))
        forced.push(g);
  }
  const forcedFit = Math.floor(roomFor(t, limitFor(true), 1, mandatoryAfterRefresh()) / GROUP_READ_CALLS);
  const groupReads = forced.slice(0, Math.max(inventory ? 0 : 1, Math.min(forced.length, forcedFit)));
  const waiting = missing.length - groupReads.filter((g) => !inInventory(g)).length;
  if (waiting > 0)
    d.logger.info(`sweep: ${waiting} listed worker group(s) not read yet; the next sweep reads them`);
  let inventorySkippedAt = meta?.inventorySkippedAt;
  const periodicDue = !!inventory && mode !== "manual" && !(nowMs - invAt < inventoryEvery * MINUTE_MS);
  if (periodicDue) {
    const stale = !(nowMs - invAt < MAX_INVENTORY_EVERY_MIN * MINUTE_MS);
    const candidates = knownGroups.filter((g) => listed.includes(g) && !groupReads.includes(g)).sort(byAge);
    const fit = Math.floor(roomFor(t, limitFor(stale), groupReads.length * GROUP_READ_CALLS, mandatoryAfterRefresh()) / GROUP_READ_CALLS);
    const take = Math.min(candidates.length, MAX_GROUPS_PER_REFRESH, Math.max(0, fit));
    groupReads.push(...candidates.slice(0, take));
    if (take === 0 && candidates.length > 0 && groupReads.length === 0) {
      inventorySkippedAt = nowIso;
      d.logger.info(
        `sweep: inventory refresh due (${Math.round((nowMs - invAt) / MINUTE_MS)} min old) does not fit the ${target}-call plan; keeping the stored inventory (forced at ${MAX_INVENTORY_EVERY_MIN} min)`
      );
    }
  }
  let inventoryRefreshed = false;
  const byGroup = { ...inventory?.byGroup ?? {} };
  const readAt = { ...inventory?.groupsFetchedAt ?? {} };
  let dropped = 0;
  if (listedNow && listing && listing.length > 0) {
    for (const gid of Object.keys(byGroup)) {
      if (listing.includes(gid))
        continue;
      delete byGroup[gid];
      delete readAt[gid];
      dropped++;
      d.logger.info(`sweep: worker group ${gid} is no longer listed by the Leader; dropped from the inventory`);
    }
  }
  let fetched = 0;
  for (const gid of groupReads) {
    try {
      byGroup[gid] = await fetchGroupInventory(t.http, gid);
      readAt[gid] = nowIso;
      fetched++;
    } catch (e) {
      if (e instanceof RateLimited || e instanceof BudgetExceeded)
        throw e;
      d.logger.warn(`sweep: inventory for ${gid} failed; keeping the stored copy`, describeError(e));
    }
  }
  if (fetched > 0 || dropped > 0) {
    for (const gid of Object.keys(readAt))
      if (!byGroup[gid])
        delete readAt[gid];
    inventory = {
      schemaVersion: 1,
      updatedAt: fetched > 0 ? nowIso : inventory?.updatedAt ?? nowIso,
      hash: inventoryHash(byGroup),
      byGroup,
      groupsFetchedAt: readAt
    };
    inventoryRefreshed = true;
  } else if (!inventory) {
    throw new Error("no inventory: every config read failed and none is stored");
  }
  if (!inventory)
    throw new Error("no inventory");
  knownGroups = Object.keys(inventory.byGroup);
  if (firstRun && !storedInventory) {
    const hourPlan = { newStart, queryStart, collectingSinceMs, rangeEnd, sliced, touchedHours };
    ({ newStart, queryStart, collectingSinceMs, rangeEnd, sliced, touchedHours } = planRange(buildFlows(inventory, settings).length));
    planReads();
    if (d.budget !== void 0 && roomFor(t, d.budget, 0, mandatoryAfterRefresh()) < 0) {
      ({ newStart, queryStart, collectingSinceMs, rangeEnd, sliced, touchedHours } = hourPlan);
      planReads();
      d.logger.info(`sweep: the first run keeps its hour of history; the ${d.budget}-call budget does not fit a longer reach`);
    }
  }
  groupFields = {
    ...listing ? { groupsKnown: listing } : {},
    ...listedAt ? { groupsListedAt: listedAt } : {},
    groupsMetered: knownGroups,
    ...inventorySkippedAt ? { inventorySkippedAt } : {}
  };
  if (!priced) {
    assertTime(a);
    await keepLock(a, "the inventory and meta writes");
    if (inventoryRefreshed)
      await docs.putInventory(inventory);
    const unpricedMeta = sweptMeta({
      collectingSince: meta?.collectingSince ?? toIso(windowEnd - FIRST_RUN_SEED_MS),
      ...meta?.meteredThrough ? { meteredThrough: meta.meteredThrough } : {},
      timelineRefreshedAt: meta?.timelineRefreshedAt,
      lastExpiredAt: progress.lastExpiredAt ?? meta?.lastExpiredAt
    });
    await docs.putMeta(unpricedMeta);
    d.logger.info("sweep: no prices yet; nothing metered (the inventory is fresh for the Prices screen)");
    return { skipped: "no_prices", meta: unpricedMeta };
  }
  const flows = buildFlows(inventory, settings);
  if (!timelineRefreshed && !storedTimeline && knownGroups.length > 0)
    timelineRefreshed = await refreshTimeline(knownGroups, mandatoryAfterRefresh(), false);
  const metrics = await fetchMetrics(t.http, knownGroups, queryStart, rangeEnd, { inventory });
  for (const err of metrics.errors)
    d.logger.warn(`sweep: metrics ${err.query} query failed (HTTP ${err.status}); attribution falls back`, err.message);
  const windows = [...metrics.windows].sort((x, y) => fromIso(x.windowStart) - fromIso(y.windowStart));
  const hourKeys = readHours.map((h) => minuteDocKey(h));
  const hourDocs = await mapLimit2(hourKeys, READ_CONCURRENCY, (k) => docs.getRollMinute(k));
  const minuteDocs = /* @__PURE__ */ new Map();
  readHours.forEach((h, i) => minuteDocs.set(h, hourDocs[i] ?? void 0));
  const dirtyHours = /* @__PURE__ */ new Set();
  const meterEnd = sliced ? rangeEnd : holdBackEnd(
    windows,
    (i) => windowHasTraffic(windows[i]) || fromIso(windows[i].windowStart) < newStart && moneyAt(minuteDocs.get(hourFloor(fromIso(windows[i].windowStart))), windows[i].windowStart).any,
    newStart,
    windowEnd
  );
  const heldMinutes = Math.round((rangeEnd - meterEnd) / MINUTE_MS);
  if (heldMinutes > 0)
    d.logger.info(`sweep: holding ${heldMinutes} empty minute(s) after traffic; the Leader may not have them yet`);
  const priceTimes = (prices.versions ?? []).map((v) => fromIso(v.effectiveFrom)).filter((x) => !Number.isNaN(x)).sort((x, y) => x - y);
  const epochOf = (ms) => {
    let lo = 0;
    let hi = priceTimes.length;
    while (lo < hi) {
      const mid = lo + hi >> 1;
      if (priceTimes[mid] <= ms)
        lo = mid + 1;
      else
        hi = mid;
    }
    return lo;
  };
  const firstPricedMs = priceTimes.length > 0 ? priceTimes[0] : Number.NaN;
  const priceCache = /* @__PURE__ */ new Map();
  const outputTypes = /* @__PURE__ */ new Map();
  for (const [gid, g] of Object.entries(inventory.byGroup))
    for (const o of g.outputs ?? [])
      outputTypes.set(`${gid}:${o.id}`, o.type);
  const pricesAt = (groupId, outputId, ms) => {
    const key = `${groupId}:${outputId}#${epochOf(ms)}`;
    let p = priceCache.get(key);
    if (!p) {
      p = effectivePrices(prices, groupId, outputId, ms, outputTypes.get(`${groupId}:${outputId}`));
      priceCache.set(key, p);
    }
    return p;
  };
  const flowsByRoute = /* @__PURE__ */ new Map();
  const flowsByInput = /* @__PURE__ */ new Map();
  for (const f of flows) {
    if (f.routeId !== "-") {
      const k = objectKey("route", f.groupId, f.routeId);
      (flowsByRoute.get(k) ?? flowsByRoute.set(k, []).get(k)).push(f);
    }
    if (f.inputId !== "-") {
      const k = objectKey("in", f.groupId, f.inputId);
      (flowsByInput.get(k) ?? flowsByInput.set(k, []).get(k)).push(f);
    }
  }
  const routeOfFlow = /* @__PURE__ */ new Map();
  for (const [k, fs] of flowsByRoute)
    for (const f of fs)
      routeOfFlow.set(f.key, k);
  const whpHistory = /* @__PURE__ */ new Map();
  const noteWhp = (route, minute, whp) => {
    let m = whpHistory.get(route);
    if (!m)
      whpHistory.set(route, m = /* @__PURE__ */ new Map());
    m.set(minute, whp);
    for (const at of m.keys()) {
      if (at > minute - HOUR_MS)
        break;
      m.delete(at);
    }
  };
  for (const doc of minuteDocs.values()) {
    for (const [key, rows] of Object.entries(doc?.flows ?? {})) {
      const route = routeOfFlow.get(key);
      if (!route)
        continue;
      for (const r of rows) {
        const m = fromIso(r.t);
        if (m >= newStart - HOUR_MS && m < newStart)
          noteWhp(route, m, (whpHistory.get(route)?.get(m) ?? 0) + r.whpM);
      }
    }
  }
  const whpPerDay = (route, minute) => {
    const m = whpHistory.get(route);
    if (!m)
      return 0;
    let sum2 = 0;
    let n = 0;
    for (const [at, v] of m) {
      if (at > minute - HOUR_MS && at <= minute) {
        sum2 += v;
        n++;
      }
    }
    return n > 0 ? Math.round(sum2 * 1440 / n) : 0;
  };
  const detectCursor = storedBaselines?.updatedAt ? fromIso(storedBaselines.updatedAt) : Number.NaN;
  const commits = () => allCommits(timeline);
  const changes = /* @__PURE__ */ new Map();
  const unmatched = /* @__PURE__ */ new Set();
  let lastAttribution;
  let minutesProcessed = 0;
  let backfilledMinutes = 0;
  let detected = false;
  const passthrough = passthroughPipelines(inventory);
  for (const w of windows) {
    const m = fromIso(w.windowStart);
    if (m >= meterEnd)
      break;
    const tIso = w.windowStart;
    const hour = hourFloor(m);
    const doc = minuteDocs.get(hour);
    const isNew = m >= newStart;
    const attrib = attributeWindow(flows, w, { passthroughPipelines: passthrough });
    const rows = {};
    for (const f of flows) {
      const a2 = attrib[f.key];
      if (!a2)
        continue;
      if (!(a2.inB > 0 || a2.outB > 0 || a2.inE > 0 || a2.outE > 0))
        continue;
      const p = pricesAt(f.groupId, f.outputId, m);
      const money = priceMinute({ inB: a2.inB, outB: a2.outB }, p.paidMcPerGb, p.whpMcPerGb, p.counterfactual);
      rows[f.key] = {
        t: tIso,
        inB: a2.inB,
        outB: a2.outB,
        inE: a2.inE,
        outE: a2.outE,
        ...money
      };
    }
    const before = moneyAt(doc, tIso);
    if (!isNew && before.any && Object.keys(rows).length === 0)
      continue;
    const nextDoc = replaceMinute(doc, toIso(hour), tIso, rows);
    minuteDocs.set(hour, nextDoc);
    dirtyHours.add(hour);
    const after = moneyAt(nextDoc, tIso);
    const replaced = Number.isFinite(totalsThrough) ? m < totalsThrough : !isNew || before.any;
    totals = addMinuteToTotals(totals, localDayKey(m, tz), after.total, replaced ? before.total : void 0, nowIso);
    const month = localMonthKey(m, tz);
    for (const outKey of /* @__PURE__ */ new Set([...before.byOutput.keys(), ...after.byOutput.keys()])) {
      totals = addOutputMinuteToTotals(
        totals,
        month,
        outKey,
        after.byOutput.get(outKey) ?? zeroMoney(),
        replaced ? before.byOutput.get(outKey) ?? zeroMoney() : void 0
      );
    }
    if (m + MINUTE_MS === meterEnd)
      lastAttribution = Object.fromEntries(Object.entries(attrib).map(([k, v]) => [k, v.attribution]));
    if (!isNew)
      continue;
    minutesProcessed++;
    const catchUp = m + MINUTE_MS < (sliced ? windowEnd : meterEnd);
    if (catchUp)
      backfilledMinutes++;
    for (const [route, fs] of flowsByRoute) {
      let whp = 0;
      for (const f of fs)
        whp += rows[f.key]?.whpM ?? 0;
      noteWhp(route, m, whp);
    }
    const minuteEnd = m + MINUTE_MS;
    if (w.coarse || !(minuteEnd > detectCursor || Number.isNaN(detectCursor)))
      continue;
    const evalNow = minuteEnd === meterEnd ? Math.min(Math.max(nowMs, minuteEnd), minuteEnd + MINUTE_MS - 1e3) : minuteEnd;
    const ratioSeries = {};
    for (const [route, fs] of flowsByRoute) {
      let saved = 0;
      let whp = 0;
      for (const f of fs) {
        saved += rows[f.key]?.savedM ?? 0;
        whp += rows[f.key]?.whpM ?? 0;
      }
      ratioSeries[route] = {
        x: whp > 0 ? saved / whp : null,
        whpPerDayM: whpPerDay(route, m),
        label: routeLabel(fs[0], inventory, labels),
        outputId: fs[0].outputId
      };
    }
    const costSeries = {};
    for (const [input, fs] of flowsByInput) {
      let paid = 0;
      for (const f of fs)
        paid += rows[f.key]?.paidM ?? 0;
      costSeries[input] = {
        x: paid * 60,
        label: humanize(fs[0].inputId, labels),
        outputId: fs[0].outputId
      };
    }
    const budgetSeries = {};
    for (const [outputId, b] of Object.entries(settings.budgets ?? {})) {
      if (!(b?.centsPerMonth > 0))
        continue;
      for (const gid of knownGroups) {
        if (!flows.some((f) => f.groupId === gid && f.outputId === outputId))
          continue;
        budgetSeries[objectKey("out", gid, outputId)] = {
          paidMtdM: outputMonthTotals(totals, month, `${gid}:${outputId}`).paidM,
          budgetCentsPerMonth: b.centsPerMonth,
          label: humanize(outputId, labels)
        };
      }
    }
    const res = detect({
      nowMs: evalNow,
      minuteStartMs: m,
      settings,
      baselines,
      openIncidents: [...openById.values()],
      ratioSeries,
      costSeries,
      budgetSeries,
      muted,
      commits: commits(),
      inventory,
      evaluateBudget: shouldEvaluateBudget(baselines, evalNow, settings),
      // P0-17 (loaned from WP-F): budget pace projects over the minutes metered this month, not since the 1st.
      budgetMinutesMtd: meteredMinutesInMonth(totals, month),
      collectingSinceMs,
      ...minuteEnd <= firstPricedMs ? { learnOnly: true } : {}
    });
    baselines = res.baselines;
    detected = true;
    for (const inc of res.opened) {
      const late = catchUp ? { ...inc, notes: [...inc.notes, CATCH_UP_NOTE] } : inc;
      const opened2 = evalNow < nowMs ? { ...late, detectedAt: nowIso } : late;
      if (!opened2.closedAt)
        openById.set(opened2.id, opened2);
      changes.set(opened2.id, { incident: opened2, event: "incident.opened" });
      if (res.unmatchedRegressions.includes(inc.id))
        unmatched.add(inc.id);
    }
    for (const inc of res.updated) {
      const prev = changes.get(inc.id);
      const was = openById.get(inc.id);
      openById.set(inc.id, inc);
      changes.set(inc.id, {
        incident: inc,
        event: prev?.event === "incident.opened" ? "incident.opened" : "incident.updated",
        prevSeverity: prev?.prevSeverity ?? was?.severity
      });
    }
    for (const inc of res.closed) {
      const prev = changes.get(inc.id);
      openById.delete(inc.id);
      changes.set(inc.id, {
        incident: inc,
        event: prev?.event === "incident.opened" ? "incident.opened" : "incident.closed"
      });
    }
  }
  const pendingUnmatched = [...unmatched].filter((id) => changes.get(id)?.incident.cause === "unknown");
  if (pendingUnmatched.length > 0 && !timelineRefreshed) {
    const groups = [...new Set(pendingUnmatched.map((id) => parseObjectKey(changes.get(id).incident.objectKey)?.groupId))].filter(
      (g) => !!g
    );
    const stillNeeded = touchedHours.length + foldDays.length * 2 + dayFolds.length * 2 + 5 + RESERVE_CALLS;
    timelineRefreshed = await refreshTimeline(groups, stillNeeded, true);
  }
  if (timelineRefreshed) {
    const candidates = [...new Map([...openById.values(), ...[...changes.values()].map((c) => c.incident)].map((i) => [i.id, i])).values()];
    const { incidents: rematched, upgraded } = rematchIncidents(candidates, commits(), inventory, th.regressionCommitWindowMin);
    for (const inc of rematched) {
      if (!upgraded.includes(inc.id))
        continue;
      const prev = changes.get(inc.id);
      const was = prev?.incident ?? openById.get(inc.id);
      if (!inc.closedAt)
        openById.set(inc.id, inc);
      changes.set(inc.id, {
        incident: inc,
        event: prev?.event ?? "incident.updated",
        prevSeverity: prev?.prevSeverity ?? was?.severity
      });
    }
  }
  assertTime(a);
  await keepLock(a, "the durable writes");
  const writes = [];
  const hourDocWrites = [...dirtyHours].sort((x, y) => x - y);
  await mapLimit2(hourDocWrites, READ_CONCURRENCY, (h) => docs.putRollMinute(minuteDocKey(h), minuteDocs.get(h)));
  const folds = foldsFor(meterEnd);
  const hourDocsByDay = /* @__PURE__ */ new Map();
  for (const day of folds.days) {
    const key = hourDocKey(fromIso(`${day}T00:00:00.000Z`));
    let hd = await docs.getRollHour(key);
    for (const h of folds.hours.filter((x) => utcDayKey(x) === day)) {
      const md = minuteDocs.get(h);
      if (md)
        hd = upsertHourRows(hd, day, foldHourRows(md));
    }
    hourDocsByDay.set(day, hd);
    if (hd)
      await docs.putRollHour(key, hd);
  }
  for (const day of folds.dayFolds) {
    const hd = hourDocsByDay.get(day);
    if (!hd)
      continue;
    const dayMs = fromIso(`${day}T00:00:00.000Z`);
    const key = dayDocKey(dayMs);
    const dd = await docs.getRollDay(key);
    await docs.putRollDay(key, upsertDayRows(dd, day.slice(0, 7), foldDayRows(hd)));
  }
  totals = { ...pruneTotals(totals), updatedAt: nowIso, meteredThrough: toIso(meterEnd), meteredAt: nowIso };
  writes.push(docs.putTotals(totals));
  if (detected || !storedBaselines)
    writes.push(docs.putBaselines(baselines));
  if (inventoryRefreshed)
    writes.push(docs.putInventory(inventory));
  await Promise.all(writes);
  if (refreshed.size > 0) {
    let fresh = await docs.getTimeline() ?? {
      schemaVersion: 1,
      updatedAt: nowIso,
      byGroup: {}
    };
    for (const [gid, list] of refreshed)
      fresh = mergeCommits(fresh, gid, list, nowIso);
    timeline = fresh;
    await docs.putTimeline(fresh);
    progress.timeline.written = true;
  }
  const writeIncidents = async (list) => {
    const byDoc = /* @__PURE__ */ new Map();
    for (const inc of list) {
      const k = incidentsDocKey(fromIso(inc.openedAt));
      (byDoc.get(k) ?? byDoc.set(k, []).get(k)).push(inc);
    }
    for (const [k, items2] of byDoc) {
      const baseItems = incidentDocs.has(k) ? incidentDocs.get(k) : (await docs.getIncidents(k))?.items ?? [];
      const merged = mergeIncidentUpdates(baseItems, [], items2, []);
      incidentDocs.set(k, merged);
      await docs.putIncidents(k, { schemaVersion: 1, items: merged });
    }
  };
  await writeIncidents([...changes.values()].map((c) => c.incident));
  const logs = [];
  let notified = 0;
  const pickedUp = /* @__PURE__ */ new Set();
  const deferred = d.runtime === "ui" && deliveryOwnedElsewhere(meta, d.owner, nowMs);
  if (deferred)
    d.logger.info("sweep: a runner or backend swept in the last 90 s; it delivers the alerts");
  const leftToDeliver = deferred && (changes.size > 0 || openById.size > 0 || (prevSnapshot?.incidents ?? []).some((i) => !openById.has(i.id) && undeliveredClosure(i, nowMs)));
  const endpoints = deferred ? [] : deliveryOrder(resolveEndpoints([...settings.notifications, ...d.envWebhooks ?? []]).filter((e) => e.enabled));
  if (endpoints.length > 0) {
    const router = createDeliveryRouter({ http: t.http, webhook: d.webhook, clock: d.clock, sleep: d.sleep, logger: d.logger });
    const candidates = [...changes.values()];
    for (const inc of openById.values()) {
      if (changes.has(inc.id))
        continue;
      pickedUp.add(inc.id);
      candidates.push({ incident: inc, event: inc.lastNotifiedAt ? "incident.updated" : "incident.opened" });
    }
    for (const inc of prevSnapshot?.incidents ?? []) {
      if (changes.has(inc.id) || openById.has(inc.id) || !undeliveredClosure(inc, nowMs))
        continue;
      pickedUp.add(inc.id);
      candidates.push({ incident: inc, event: inc.type === "goodnews" ? "incident.opened" : "incident.closed" });
    }
    let outOfTime = false;
    const down = /* @__PURE__ */ new Set();
    for (const c of candidates) {
      let incident = c.incident;
      if (inFailedAttemptCooldown(incident, nowMs))
        continue;
      let attempted = false;
      let delivered = false;
      for (const ep of endpoints) {
        if (down.has(ep.id))
          continue;
        if (!shouldNotify(incident, ep, nowMs, th.cooldownMinutes, c.prevSeverity))
          continue;
        if (d.clock.now() - a.startedAt > NOTIFY_TIME_BUDGET_MS) {
          if (!outOfTime)
            d.logger.warn("sweep: notification time budget spent; remaining notifications wait for the next sweep");
          outOfTime = true;
          break;
        }
        const canonical = canonicalPayload(c.event, {
          incident,
          workspace: d.workspace,
          linkBase: d.linkBase,
          labels,
          sentAt: nowIso
        });
        const webhook = channelOf(ep) === "webhook";
        const sentAt = d.clock.now();
        const attempts = await router.deliver({ endpoint: ep, event: c.event, canonical, incidentId: incident.id, tz, labels, ...webhook ? { backoffMs: [] } : {} });
        logs.push(...attempts);
        const failedSlow = attempts.length > 0 && attempts.every((x) => x.status === 0) && d.clock.now() - sentAt >= WEBHOOK_TIMEOUT_MS;
        if (attempts.some(isTimeoutAttempt) || failedSlow) {
          down.add(ep.id);
          d.logger.warn(`sweep: ${ep.name || ep.id} did not answer within ${WEBHOOK_TIMEOUT_MS / 1e3} s; skipped for the rest of this sweep, retried next sweep`);
        }
        const last = lastAttempt(attempts);
        if (!last)
          continue;
        attempted = true;
        if (last.status >= 200 && last.status < 300) {
          notified++;
          delivered = true;
        }
        const ref = {
          endpointId: ep.id,
          status: last.status,
          at: last.at,
          ...last.error ? { error: last.error } : {}
        };
        incident = {
          ...incident,
          deliveries: [...incident.deliveries ?? [], ref].slice(-MAX_INCIDENT_DELIVERIES)
        };
      }
      if (!attempted)
        continue;
      incident = { ...incident, lastAttemptAt: nowIso, ...delivered ? { lastNotifiedAt: nowIso } : {} };
      changes.set(incident.id, { ...c, incident });
      if (!incident.closedAt)
        openById.set(incident.id, incident);
    }
  }
  assertTime(a);
  await keepLock(a, "the snapshot and meta writes");
  const attemptedNow = [...changes.values()].filter((c) => c.incident.lastAttemptAt === nowIso).map((c) => c.incident);
  if (attemptedNow.length > 0)
    await writeIncidents(attemptedNow);
  let deliveries = prevSnapshot?.deliveries ?? [];
  if (logs.length > 0) {
    const log = await docs.getNotifyLog() ?? {
      schemaVersion: 1,
      items: []
    };
    const items2 = [...log.items, ...logs].slice(-NOTIFY_LOG_CAP);
    await docs.putNotifyLog({ schemaVersion: 1, items: items2 });
    deliveries = items2;
  }
  const lastExpiry = meta?.lastExpiredAt ? fromIso(meta.lastExpiredAt) : Number.NaN;
  const hourly = !(nowMs - lastExpiry < EXPIRE_EVERY_MS) && roomFor(t, target, 2, 3) >= 0;
  const backlog = (meta?.expiryBacklog ?? 0) > 0 && roomFor(t, target, 2 + EXPIRY_MIN_BATCH, 3) >= 0;
  if (!progress.expiryRan && (hourly || backlog))
    await expireKeysSafely(docs, nowMs, () => target - t.calls() - 3, progress, d.logger);
  const lastExpiredAt = progress.lastExpiredAt ?? meta?.lastExpiredAt;
  const snapshotHours = snapshotHoursFor(meterEnd);
  for (const h of snapshotHours)
    if (!minuteDocs.has(h))
      minuteDocs.set(h, await docs.getRollMinute(minuteDocKey(h)) ?? void 0);
  const snapshotRows = mergeRowsByFlow(snapshotHours.map((h) => minuteDocs.get(h)));
  const snapshotIncidents = /* @__PURE__ */ new Map();
  for (const i of prevSnapshot?.incidents ?? [])
    snapshotIncidents.set(i.id, i);
  for (const items2 of incidentDocs.values())
    for (const i of items2)
      snapshotIncidents.set(i.id, i);
  for (const i of openById.values())
    snapshotIncidents.set(i.id, i);
  for (const c of changes.values())
    snapshotIncidents.set(c.incident.id, c.incident);
  const plannedFinal = t.calls() + 3;
  const snapshot = compactSnapshot(
    buildSnapshot({
      sweepAtMs: nowMs,
      windowStartMs: meterEnd - MINUTE_MS,
      windowEndMs: meterEnd,
      mode,
      settings,
      prices,
      inventory,
      flows,
      minuteRows: snapshotRows,
      ...lastAttribution ? { attribution: lastAttribution } : {},
      totals,
      collectingSinceMs,
      incidents: [...snapshotIncidents.values()],
      timeline,
      deliveries,
      muted,
      baselines,
      calls: plannedFinal,
      metricsSource: "metrics-query",
      previous: prevSnapshot
    }),
    SNAPSHOT_MAX_BYTES
  );
  const bytes = snapshotBytes(snapshot);
  await docs.putSnapshot(snapshot);
  const nextMeta = sweptMeta({
    collectingSince: toIso(collectingSinceMs),
    meteredThrough: toIso(meterEnd),
    timelineRefreshedAt: refreshed.size > 0 ? nowIso : meta?.timelineRefreshedAt,
    lastExpiredAt,
    ...leftToDeliver ? { deliveryDeferredAt: nowIso } : {},
    ...gap ? { gap } : {}
  });
  await docs.putMeta(nextMeta);
  let opened = 0;
  let closed = 0;
  for (const c of changes.values()) {
    if (pickedUp.has(c.incident.id))
      continue;
    if (c.event === "incident.opened")
      opened++;
    if (c.incident.closedAt)
      closed++;
  }
  return {
    minutesProcessed,
    backfilledMinutes,
    ...heldMinutes > 0 ? { heldMinutes } : {},
    ...gap ? { unmeteredMinutes: Math.round((gap.to - gap.from) / MINUTE_MS) } : {},
    ...sliced ? { catchUpRemainingMinutes: Math.round((windowEnd - meterEnd) / MINUTE_MS) } : {},
    opened,
    closed,
    notified,
    snapshotBytes: bytes,
    snapshot,
    meta: nextMeta
  };
}
function assertTime(a) {
  const elapsed = a.d.clock.now() - a.startedAt;
  if (elapsed > SWEEP_TIME_BUDGET_MS)
    throw new TimeBudgetExceeded(elapsed);
}

// core/runtime.ts
var APP_ID = "meter-reader";
var BACKEND_API_BASE = "/api/v1";
function createConsoleLogger(prefix = "[meter-reader]") {
  const c = globalThis.console;
  const emit = (level) => (msg, data) => {
    if (!c)
      return;
    if (data === void 0)
      c[level](`${prefix} ${msg}`);
    else
      c[level](`${prefix} ${msg}`, data);
  };
  return { info: emit("info"), warn: emit("warn"), error: emit("error") };
}
function createOwnerId(prefix, env = globalThis) {
  const uuid = env.crypto?.randomUUID?.();
  return `${prefix}:${uuid ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`}`;
}
function originOf(url) {
  const m = /^(https?):\/\/([^/?#]+)/i.exec((url ?? "").trim());
  if (!m)
    return void 0;
  const host = m[2].replace(/^[^@]*@/, "").replace(/:\d+$/, "").toLowerCase();
  return {
    origin: `${m[1].toLowerCase()}://${m[2].replace(/^[^@]*@/, "")}`,
    host
  };
}
function workspaceFromUrl(url) {
  const o = originOf(url);
  if (!o)
    return "";
  const cloud = /^([^.]+)\.cribl(?:-staging)?\.cloud$/.exec(o.host);
  return cloud ? cloud[1] : o.host;
}
function linkBaseFrom(apiUrl, basePath) {
  const o = originOf(apiUrl);
  if (!o)
    return (basePath ?? "").replace(/\/+$/, "");
  const path = (basePath && basePath.trim() !== "" ? basePath : `/app-ui/${APP_ID}`).replace(/\/+$/, "");
  return `${o.origin}${path.startsWith("/") ? path : `/${path}`}`;
}
function globalFetch() {
  const f = globalThis.fetch;
  return typeof f === "function" ? f : void 0;
}
function createBackendDeps(opts = {}) {
  const fetchFn = opts.fetch ?? globalFetch();
  if (!fetchFn)
    throw new Error("fetch is not available in this environment");
  const deps = {
    http: createFetchHttp({ fetch: fetchFn, baseUrl: BACKEND_API_BASE }),
    kv: createFetchKvStore({ fetch: fetchFn, baseUrl: BACKEND_API_BASE }),
    webhook: createFetchWebhookSender(fetchFn),
    clock: { now: () => Date.now() },
    codec: detectCodec(),
    logger: opts.logger ?? createConsoleLogger(),
    owner: opts.owner ?? createOwnerId("backend"),
    appVersion: opts.appVersion ?? "0.0.0",
    build: opts.build ?? "release",
    runtime: "backend",
    workspace: opts.workspace ?? workspaceFromUrl(opts.requestUrl),
    linkBase: opts.linkBase ?? linkBaseFrom(opts.requestUrl, void 0)
  };
  if (opts.budget !== void 0)
    deps.budget = opts.budget;
  return deps;
}

// package.json
var version = "1.1.0";

// backend/lib/build-info.ts
var APP_VERSION = typeof version === "string" ? version : "0.0.0";
var BUILD = "release";

// backend/lib/http.ts
async function readJsonBody(request) {
  let text;
  try {
    text = await request.text();
  } catch {
    return {};
  }
  if (text.trim() === "")
    return {};
  try {
    const value = JSON.parse(text);
    return value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
  } catch {
    return {};
  }
}
function json(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" }
  });
}
function stringField(body, name) {
  const v = body[name];
  return typeof v === "string" && v.trim() !== "" ? v : void 0;
}

// backend/lib/deps.ts
function depsFor(request, context, body) {
  const workspace = stringField(body, "workspace");
  const linkBase = stringField(body, "linkBase");
  return createBackendDeps({
    appVersion: APP_VERSION,
    build: BUILD,
    owner: context?.invocationId ? `backend:${context.invocationId}` : createOwnerId("backend"),
    requestUrl: request.url,
    ...workspace ? { workspace } : {},
    ...linkBase ? { linkBase } : {}
  });
}

// backend/meter.ts
async function onRequest(request, context) {
  const body = await readJsonBody(request);
  const mode = body.mode === "manual" ? "manual" : "scheduled";
  const result = await runSweep(depsFor(request, context, body), { mode });
  const { snapshot, ...summary } = result;
  const payload = {
    ok: result.error === void 0 || result.skipped !== void 0,
    ...summary,
    ...mode === "manual" && snapshot ? { snapshot } : {}
  };
  return json(result.error !== void 0 && result.skipped === void 0 ? 422 : 200, payload);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  onRequest
});
//# sourceMappingURL=meter.js.map
