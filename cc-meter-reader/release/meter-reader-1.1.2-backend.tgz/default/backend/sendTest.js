var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// backend/sendTest.ts
var sendTest_exports = {};
__export(sendTest_exports, {
  onRequest: () => onRequest
});
module.exports = __toCommonJS(sendTest_exports);

// core/http.ts
var BudgetExceeded = class extends Error {
  constructor(budget, calls, method, path) {
    super(`Leader API budget of ${budget} calls exhausted (${calls} used); refused ${method} ${path}`);
    this.name = "BudgetExceeded";
    this.budget = budget;
    this.calls = calls;
    this.method = method;
    this.path = path;
  }
};
var RateLimited = class extends Error {
  constructor(method, path, retryAfterMs) {
    super(`Rate limited by the Leader (second 429 this sweep) on ${method} ${path}`);
    this.name = "RateLimited";
    this.method = method;
    this.path = path;
    this.retryAfterMs = retryAfterMs;
  }
};
var RETRY_AFTER_MAX_MS = 6e4;
function parseRetryAfter(value, nowMs) {
  if (value === void 0 || value === null)
    return void 0;
  const v = value.trim();
  if (v === "")
    return void 0;
  if (/^\d+(\.\d+)?$/.test(v))
    return Math.round(Number(v) * 1e3);
  const at = Date.parse(v);
  return Number.isFinite(at) ? Math.max(0, at - nowMs) : void 0;
}
function retryAfterOf(source, nowMs) {
  if (source === null || typeof source !== "object")
    return void 0;
  const s = source;
  if (typeof s.retryAfterMs === "number" && Number.isFinite(s.retryAfterMs))
    return Math.max(0, s.retryAfterMs);
  const h = s.headers;
  if (!h)
    return void 0;
  return parseRetryAfter(h["retry-after"] ?? h["Retry-After"], nowMs);
}
function retryWaitMs(retryAfterMs, fallbackMs) {
  if (retryAfterMs === void 0)
    return fallbackMs;
  if (retryAfterMs > RETRY_AFTER_MAX_MS)
    return void 0;
  return Math.max(1e3, retryAfterMs);
}
var RATE_LIMIT_RETRY_MS = 5e3;
function defaultSleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
var DEFAULT_TIMEOUT_MS = 25e3;
var TIMEOUT_PREFIX = "timeout:";
var NETWORK_ERROR_PREFIX = "network_error:";
function callFetch(fetchFn, url, init) {
  return Reflect.apply(fetchFn, globalThis, [url, init]);
}
function joinUrl(baseUrl, path) {
  const base = baseUrl.replace(/\/+$/, "");
  return path.startsWith("/") ? base + path : `${base}/${path}`;
}
function collectHeaders(res) {
  if (!res.headers || typeof res.headers.forEach !== "function")
    return void 0;
  const out = {};
  res.headers.forEach((value, key) => {
    out[key.toLowerCase()] = value;
  });
  return out;
}
function createFetchHttp(options) {
  const defaultTimeout = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  return {
    async request(method, path, body, opts) {
      const timeoutMs = opts?.timeoutMs ?? defaultTimeout;
      const raw = opts?.raw === true;
      const init = { method, headers: {} };
      if (body !== void 0) {
        if (raw && typeof body === "string") {
          init.headers = { "content-type": "text/plain" };
          init.body = body;
        } else {
          init.headers = { "content-type": "application/json" };
          init.body = JSON.stringify(body);
        }
      }
      const controller = typeof AbortController === "function" ? new AbortController() : void 0;
      if (controller)
        init.signal = controller.signal;
      let timer;
      const timedOut = new Promise((resolve) => {
        timer = setTimeout(() => resolve("timeout"), timeoutMs);
      });
      try {
        const exchange = (async () => {
          const res2 = await callFetch(options.fetch, joinUrl(options.baseUrl, path), init);
          const text2 = await res2.text();
          return { res: res2, text: text2 };
        })();
        exchange.catch(() => void 0);
        const outcome = await Promise.race([exchange, timedOut]);
        if (outcome === "timeout") {
          controller?.abort();
          return { status: 0, ok: false, text: `${TIMEOUT_PREFIX} no response from ${method} ${path} within ${timeoutMs} ms` };
        }
        const { res, text } = outcome;
        const headers = collectHeaders(res);
        const result = { status: res.status, ok: res.ok };
        if (headers)
          result.headers = headers;
        if (raw || text.length === 0) {
          result.text = text;
          return result;
        }
        try {
          result.json = JSON.parse(text);
        } catch {
          result.text = text;
        }
        return result;
      } catch (e) {
        return { status: 0, ok: false, text: `${NETWORK_ERROR_PREFIX} ${e instanceof Error ? e.message : String(e)}` };
      } finally {
        if (timer !== void 0)
          clearTimeout(timer);
      }
    }
  };
}

// core/codec.ts
var utf8Encoder = new TextEncoder();
function utf8Decode(bytes) {
  return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
}
function utf8ByteLength(s) {
  let bytes = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 128)
      bytes += 1;
    else if (c < 2048)
      bytes += 2;
    else if (c >= 55296 && c <= 56319 && i + 1 < s.length) {
      const next = s.charCodeAt(i + 1);
      if (next >= 56320 && next <= 57343) {
        bytes += 4;
        i++;
      } else
        bytes += 3;
    } else
      bytes += 3;
  }
  return bytes;
}
function fnv1a(s) {
  const bytes = utf8Encoder.encode(s);
  let h = 2166136261;
  for (let i = 0; i < bytes.length; i++) {
    h ^= bytes[i];
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}
var B64_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var B64_LOOKUP = (() => {
  const t = new Int16Array(128).fill(-1);
  for (let i = 0; i < B64_ALPHABET.length; i++)
    t[B64_ALPHABET.charCodeAt(i)] = i;
  return t;
})();
var ENCODE_CHUNK = 3 * 8192;
var DECODE_CHUNK = 4 * 8192;
function globalFn(name) {
  const fn = globalThis[name];
  return typeof fn === "function" ? fn : void 0;
}
function binaryString(bytes) {
  return String.fromCharCode.apply(null, bytes);
}
function toBase64(bytes) {
  const btoaFn = globalFn("btoa");
  if (btoaFn) {
    const pieces = [];
    for (let i = 0; i < bytes.length; i += ENCODE_CHUNK)
      pieces.push(btoaFn(binaryString(bytes.subarray(i, i + ENCODE_CHUNK))));
    return pieces.join("");
  }
  return toBase64Pure(bytes);
}
function toBase64Pure(bytes) {
  const out = [];
  let i = 0;
  for (; i + 2 < bytes.length; i += 3) {
    const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
    out.push(B64_ALPHABET[n >> 18 & 63], B64_ALPHABET[n >> 12 & 63], B64_ALPHABET[n >> 6 & 63], B64_ALPHABET[n & 63]);
  }
  const rest = bytes.length - i;
  if (rest === 1) {
    const n = bytes[i] << 16;
    out.push(B64_ALPHABET[n >> 18 & 63], B64_ALPHABET[n >> 12 & 63], "==");
  } else if (rest === 2) {
    const n = bytes[i] << 16 | bytes[i + 1] << 8;
    out.push(B64_ALPHABET[n >> 18 & 63], B64_ALPHABET[n >> 12 & 63], B64_ALPHABET[n >> 6 & 63], "=");
  }
  return out.join("");
}
function fromBase64(input) {
  const s = input.replace(/[\t\n\f\r ]+/g, "");
  if (s.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(s))
    throw new Error("invalid base64 input");
  const padding = s.endsWith("==") ? 2 : s.endsWith("=") ? 1 : 0;
  const out = new Uint8Array(s.length / 4 * 3 - padding);
  const atobFn = globalFn("atob");
  if (!atobFn)
    return fromBase64Pure(s, out);
  let o = 0;
  for (let i = 0; i < s.length; i += DECODE_CHUNK) {
    const bin = atobFn(s.slice(i, i + DECODE_CHUNK));
    for (let j = 0; j < bin.length; j++)
      out[o++] = bin.charCodeAt(j);
  }
  return out;
}
function fromBase64Pure(s, out) {
  let o = 0;
  for (let i = 0; i < s.length; i += 4) {
    const a = B64_LOOKUP[s.charCodeAt(i)];
    const b = B64_LOOKUP[s.charCodeAt(i + 1)];
    const c = s[i + 2] === "=" ? 0 : B64_LOOKUP[s.charCodeAt(i + 2)];
    const d = s[i + 3] === "=" ? 0 : B64_LOOKUP[s.charCodeAt(i + 3)];
    const n = a << 18 | b << 12 | c << 6 | d;
    if (o < out.length)
      out[o++] = n >> 16 & 255;
    if (o < out.length)
      out[o++] = n >> 8 & 255;
    if (o < out.length)
      out[o++] = n & 255;
  }
  return out;
}
function streamCtor(name) {
  const ctor = globalThis[name];
  return typeof ctor === "function" ? ctor : void 0;
}
function hasCompressionStreams() {
  return streamCtor("CompressionStream") !== void 0 && streamCtor("DecompressionStream") !== void 0;
}
async function pump(stream, input) {
  const writer = stream.writable.getWriter();
  const reader = stream.readable.getReader();
  const writing = (async () => {
    await writer.write(input);
    await writer.close();
  })();
  writing.catch(() => void 0);
  const parts = [];
  let total = 0;
  for (; ; ) {
    const { done, value } = await reader.read();
    if (done)
      break;
    if (value) {
      parts.push(value);
      total += value.byteLength;
    }
  }
  await writing;
  const out = new Uint8Array(total);
  let offset = 0;
  for (const p of parts) {
    out.set(p, offset);
    offset += p.byteLength;
  }
  return out;
}
var webCodec = {
  encoding: "gzip",
  async gzip(s) {
    const Ctor = streamCtor("CompressionStream");
    if (!Ctor)
      throw new Error("CompressionStream is not available in this runtime");
    return pump(new Ctor("gzip"), utf8Encoder.encode(s));
  },
  async gunzip(b) {
    const Ctor = streamCtor("DecompressionStream");
    if (!Ctor)
      throw new Error("DecompressionStream is not available in this runtime");
    return utf8Decode(await pump(new Ctor("gzip"), b));
  }
};
var identityCodec = {
  encoding: "identity",
  async gzip(s) {
    return utf8Encoder.encode(s);
  },
  async gunzip(b) {
    return utf8Decode(b);
  }
};
function detectCodec() {
  return hasCompressionStreams() ? webCodec : identityCodec;
}

// core/adapters/cribl-urls.ts
var seg = encodeURIComponent;
var kvKey = (key) => `/kvstore/${key.split("/").map(seg).join("/")}`;
var kvKeys = () => "/kvstore/keys";

// core/time.ts
var MINUTE_MS = 6e4;
var HOUR_MS = 36e5;
var DAY_MS = 864e5;
function toIso(ms) {
  return new Date(ms).toISOString();
}
function fromIso(iso) {
  if (typeof iso !== "string" || iso.length === 0)
    return Number.NaN;
  return Date.parse(iso);
}
var displayFormatters = /* @__PURE__ */ new Map();
function displayFormatter(tz, kind) {
  const cacheKey = `${kind}|${tz}`;
  let f = displayFormatters.get(cacheKey);
  if (!f) {
    const base = { timeZone: tz };
    const opts = kind === "time" ? { ...base, hour: "numeric", minute: "2-digit", hour12: true } : kind === "datetime" ? { ...base, month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", hour12: true } : kind === "monthday" ? { ...base, month: "short", day: "numeric" } : { ...base, month: "short", day: "numeric", year: "numeric" };
    f = new Intl.DateTimeFormat("en-US", opts);
    displayFormatters.set(cacheKey, f);
  }
  return f;
}
function normalizeSpaces(s) {
  return s.replace(/[   ]/g, " ");
}
function formatLocalTime(ms, tz) {
  return normalizeSpaces(displayFormatter(tz, "time").format(new Date(ms)));
}
var LEGACY_ZONES = {
  "Asia/Calcutta": "Asia/Kolkata",
  "Asia/Saigon": "Asia/Ho_Chi_Minh",
  "Asia/Katmandu": "Asia/Kathmandu",
  "Asia/Rangoon": "Asia/Yangon",
  "Europe/Kiev": "Europe/Kyiv",
  "Atlantic/Faeroe": "Atlantic/Faroe",
  "America/Buenos_Aires": "America/Argentina/Buenos_Aires",
  "America/Godthab": "America/Nuuk",
  "Pacific/Truk": "Pacific/Chuuk",
  "Pacific/Ponape": "Pacific/Pohnpei"
};
function canonicalZoneName(tz) {
  return LEGACY_ZONES[tz] ?? tz;
}
function isValidTimeZone(tz) {
  if (typeof tz !== "string" || tz.length === 0)
    return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

// core/settings.ts
var SETTINGS_SCHEMA_VERSION = 1;
var DEFAULT_QR_URL = "https://github.com/Cribl-Community/cc-meter-reader";
var DEFAULT_THRESHOLDS = {
  regressionPoints: 15,
  regressionMinutes: 3,
  regressionCommitWindowMin: 30,
  spikeSigma: 3,
  spikeMinutes: 2,
  spikeMinCentsPerHour: 500,
  budgetWarnPct: 90,
  budgetAlertPct: 100,
  goodNewsPoints: 15,
  cooldownMinutes: 60,
  ewmaAlpha: 14e-4,
  warmupSamples: 10,
  recoveryMinutes: 5,
  regressionMinCentsPerDay: 500
};
function defaultSettings(nowIso, tz, runtime = "ui") {
  return {
    schemaVersion: SETTINGS_SCHEMA_VERSION,
    updatedAt: nowIso,
    displayTimezone: isValidTimeZone(tz) ? tz : "UTC",
    headlinePeriodDefault: "annualized",
    presenter: { headlinePeriod: "annualized", qrUrl: DEFAULT_QR_URL },
    live: { pollSeconds: 10, presenterPollSeconds: 5 },
    budgets: {},
    thresholds: { ...DEFAULT_THRESHOLDS },
    goodNewsEnabled: false,
    excludedObjectKeys: [],
    includeInternal: false,
    notifications: [],
    humanize: {},
    demo: { enabled: false, replayMode: false, profile: true },
    runtime: runtime === "backend" ? "backend" : "ui"
  };
}
var isNum = (v) => typeof v === "number" && Number.isFinite(v);
var isObj = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
var CRIBL_ID_PATTERN = /^[A-Za-z0-9_-]{1,512}$/;
var SECRET_TOKEN = /\bxox[abposr]-|\bxapp-|\bghp_|\bgho_|\bghs_|\bgithub_pat_|\bAKIA[0-9A-Z]{16}\b|-{5}BEGIN [A-Z ]*KEY|\bBearer\s+\S/;
var HOST_WITH_PATH = /(?:^|[^A-Za-z0-9.@-])(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}(?::\d+)?\/\S/;
var BARE_USERINFO = /(?:^|\s)[^\s:@/]+:[^\s@/]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}/;
var RANDOM_TOKEN = /^(?=[A-Za-z0-9]*[a-z])(?=[A-Za-z0-9]*[A-Z])(?=[A-Za-z0-9]*\d)[A-Za-z0-9]{20,}$/;
var UUID_TOKEN = /(?:^|[^0-9A-Za-z])[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?:$|[^0-9A-Za-z])/i;
var HEX_RUN = /(?:^|[^0-9A-Za-z])[0-9a-f]{24,}(?:$|[^0-9A-Za-z])/i;
var LOWER_ALNUM_RUN = /(?:^|[^0-9A-Za-z])(?=[a-z0-9]*\d)(?=[a-z0-9]*[a-z])[a-z0-9]{24,}(?:$|[^0-9A-Za-z])/;
var JWT_TOKEN = /(?:^|[^\w-])eyJ[\w-]+\.[\w-]+\./;
var KEY_PREFIX = /(?:^|[^\w.])SG\.[\w-]{6,}|(?:^|[^A-Za-z0-9])[sr]k_(?:live|test)_\w+|(?:^|[^A-Za-z0-9])[sr]k_[A-Za-z0-9]{16,}|(?:^|[^A-Za-z0-9])sk-[\w-]{16,}/;
var PASSWORD_WORD = /^(?=\S*[a-z])(?=\S*[A-Z])(?=\S*\d)(?=\S*[^\sA-Za-z0-9._-])\S{8,64}$/;
function looksLikeSecretToken(value) {
  if (typeof value !== "string")
    return false;
  const v = value.trim();
  if (v === "")
    return false;
  return UUID_TOKEN.test(v) || HEX_RUN.test(v) || LOWER_ALNUM_RUN.test(v) || JWT_TOKEN.test(v) || KEY_PREFIX.test(v) || PASSWORD_WORD.test(v);
}
function unstorableText(value) {
  return looksLikeCredentialText(value) || looksLikeSecretToken(value);
}
function looksLikeCredentialText(value) {
  if (typeof value !== "string")
    return false;
  const v = value.trim();
  if (v === "")
    return false;
  return v.includes("://") || urlHasCredentials(v) || HOST_WITH_PATH.test(v) || BARE_USERINFO.test(v) || SECRET_TOKEN.test(v) || RANDOM_TOKEN.test(v);
}
function isStorableTargetId(value) {
  return typeof value === "string" && CRIBL_ID_PATTERN.test(value) && !unstorableText(value);
}
var WEBHOOK_URL = [
  /^https?:\/\/hooks\.slack\.com\//i,
  /^https?:\/\/[^/?#]*\.webhook\.office\.com\//i,
  /^https?:\/\/outlook\.office(?:365)?\.com\/webhook/i,
  /^https?:\/\/(?:[^/?#]*\.)?discord(?:app)?\.com\/api\/webhooks\//i,
  /^https?:\/\/hooks\.zapier\.com\//i,
  /^https?:\/\/events\.pagerduty\.com\//i,
  /^https?:\/\/(?:[^/?#]*\.)?webhook\.site\//i,
  /^https?:\/\/maker\.ifttt\.com\/trigger\//i,
  /^https?:\/\/api\.telegram\.org\/bot/i
];
function isWebhookUrl(url) {
  if (typeof url !== "string")
    return false;
  const u = url.trim();
  return urlHasCredentials(u) || WEBHOOK_URL.some((re) => re.test(u));
}
function isStorableEndpoint(e) {
  return e?.channel === "cribl-bell" || e?.channel === "cribl-target";
}
function storableEndpoint(e) {
  if (!isObj(e) || typeof e.id !== "string" || e.id === "" || looksLikeCredentialText(e.id))
    return void 0;
  const ep = e;
  if (!isStorableEndpoint(ep))
    return void 0;
  if (ep.channel === "cribl-target" && !isStorableTargetId(ep.criblTargetId))
    return void 0;
  const out = normalizeEndpoint({ ...ep, url: "", host: "" });
  if (out.channel === "cribl-bell")
    delete out.criblTargetId;
  if (unstorableText(out.name))
    out.name = out.channel === "cribl-target" ? out.criblTargetId ?? "" : "";
  return out;
}
function storableLabels(map) {
  const out = {};
  if (!isObj(map))
    return out;
  for (const [k, v] of Object.entries(map))
    if (typeof v === "string" && !unstorableText(v) && !unstorableText(k))
      out[k] = v;
  return out;
}
function storableSettings(s) {
  if (!Array.isArray(s.notifications))
    return s;
  const notifications = s.notifications.map(storableEndpoint).filter((e) => e !== void 0);
  const out = { ...s, notifications };
  if (s.humanize !== void 0)
    out.humanize = storableLabels(s.humanize);
  if (s.presenter && isWebhookUrl(s.presenter.qrUrl))
    out.presenter = { ...s.presenter, qrUrl: DEFAULT_QR_URL };
  return out;
}
function urlHasCredentials(url) {
  return /^[a-z][a-z0-9+.-]*:\/\/[^/?#]*@/i.test((url ?? "").trim());
}
function hostFromUrl(url) {
  if (urlHasCredentials(url))
    return void 0;
  const m = /^https:\/\/(\[[^\]]+\]|[^/?#:]+)(?::\d+)?(?:[/?#]|$)/i.exec((url ?? "").trim());
  return m ? m[1].toLowerCase() : void 0;
}
var SEVERITIES = ["info", "medium", "high"];
var FORMATS = ["generic", "slack", "servicenow"];
var PERIODS = ["mtd", "today", "30d", "annualized"];
function pick(stored, fallback) {
  if (stored === void 0 || stored === null)
    return fallback;
  if (typeof fallback === "number")
    return isNum(stored) ? stored : fallback;
  return typeof stored === typeof fallback ? stored : fallback;
}
function pickPeriod(stored, fallback) {
  return PERIODS.includes(stored) ? stored : fallback;
}
function mergeSettings(stored, defaults) {
  const s = isObj(stored) ? stored : {};
  const presenter = isObj(s.presenter) ? s.presenter : {};
  const live = isObj(s.live) ? s.live : {};
  const thresholds = isObj(s.thresholds) ? s.thresholds : {};
  const demo = isObj(s.demo) ? s.demo : {};
  const mergedThresholds = { ...defaults.thresholds };
  for (const k of Object.keys(defaults.thresholds)) {
    mergedThresholds[k] = pick(thresholds[k], defaults.thresholds[k]);
  }
  const budgets = {};
  if (isObj(s.budgets)) {
    for (const [k, v] of Object.entries(s.budgets)) {
      if (isObj(v) && isNum(v.centsPerMonth))
        budgets[k] = { centsPerMonth: v.centsPerMonth };
    }
  }
  const humanizeMap = storableLabels(s.humanize);
  const storedQr = typeof presenter.qrUrl === "string" ? presenter.qrUrl : defaults.presenter.qrUrl;
  const qrUrl = isWebhookUrl(storedQr) ? DEFAULT_QR_URL : storedQr;
  const out = {
    schemaVersion: SETTINGS_SCHEMA_VERSION,
    updatedAt: pick(s.updatedAt, defaults.updatedAt),
    displayTimezone: typeof s.displayTimezone === "string" && isValidTimeZone(s.displayTimezone) ? s.displayTimezone : defaults.displayTimezone,
    headlinePeriodDefault: pickPeriod(s.headlinePeriodDefault, defaults.headlinePeriodDefault),
    presenter: { headlinePeriod: pickPeriod(presenter.headlinePeriod, defaults.presenter.headlinePeriod), ...qrUrl !== void 0 ? { qrUrl } : {} },
    live: {
      pollSeconds: pick(live.pollSeconds, defaults.live.pollSeconds),
      presenterPollSeconds: pick(live.presenterPollSeconds, defaults.live.presenterPollSeconds)
    },
    budgets: isObj(s.budgets) ? budgets : { ...defaults.budgets },
    thresholds: mergedThresholds,
    goodNewsEnabled: pick(s.goodNewsEnabled, defaults.goodNewsEnabled),
    excludedObjectKeys: Array.isArray(s.excludedObjectKeys) ? s.excludedObjectKeys.filter((k) => typeof k === "string") : [...defaults.excludedObjectKeys],
    includeInternal: pick(s.includeInternal, defaults.includeInternal),
    // D57: a stored direct webhook (written by a build before 1.0.14 / 1.1.0) is dropped on read, URL and all, as is
    // a target whose id is not shaped like a Cribl id (a URL typed as the target id before the rule 4.5 fix); the Cribl channels
    // keep no URL and no name is a URL: nothing a sweep or a tab reads can carry a webhook URL out of KV.
    notifications: (Array.isArray(s.notifications) ? s.notifications : defaults.notifications).map(storableEndpoint).filter((e) => e !== void 0),
    humanize: isObj(s.humanize) ? humanizeMap : { ...defaults.humanize },
    demo: {
      enabled: pick(demo.enabled, defaults.demo.enabled),
      replayMode: pick(demo.replayMode, defaults.demo.replayMode),
      profile: pick(demo.profile, defaults.demo.profile),
      // Row 9: only a stored boolean is kept (absent = on, demoSettleOn), so a document written before it reads the same.
      ...typeof demo.settle === "boolean" ? { settle: demo.settle } : typeof defaults.demo.settle === "boolean" ? { settle: defaults.demo.settle } : {}
    },
    runtime: s.runtime === "backend" || s.runtime === "ui" ? s.runtime : defaults.runtime
  };
  const cost = isNum(s.criblCostCentsPerMonth) ? s.criblCostCentsPerMonth : defaults.criblCostCentsPerMonth;
  if (cost !== void 0)
    out.criblCostCentsPerMonth = cost;
  if (cost !== void 0 && cost > 0 && s.criblCostEstimate === true)
    out.criblCostEstimate = true;
  if (isObj(s.mutes)) {
    const mutes = {};
    for (const [k, v] of Object.entries(s.mutes)) {
      if (isObj(v) && typeof v.until === "string")
        mutes[k] = typeof v.by === "string" ? { until: v.until, by: v.by } : { until: v.until };
    }
    if (Object.keys(mutes).length > 0)
      out.mutes = mutes;
  }
  const keyboard = isObj(s.keyboard) ? s.keyboard : {};
  if (typeof keyboard.singleKeyShortcuts === "boolean")
    out.keyboard = { singleKeyShortcuts: keyboard.singleKeyShortcuts };
  else if (defaults.keyboard)
    out.keyboard = { ...defaults.keyboard };
  if (isNum(s.savingsGoalCentsPerMonth) && s.savingsGoalCentsPerMonth > 0)
    out.savingsGoalCentsPerMonth = s.savingsGoalCentsPerMonth;
  return out;
}
function normalizeEndpoint(e) {
  const out = {
    id: e.id,
    name: typeof e.name === "string" ? e.name : "",
    url: e.url,
    host: hostFromUrl(e.url) ?? (typeof e.host === "string" ? e.host : ""),
    format: FORMATS.includes(e.format) ? e.format : "generic",
    minSeverity: SEVERITIES.includes(e.minSeverity) ? e.minSeverity : "medium",
    weeklyReceipt: typeof e.weeklyReceipt === "boolean" ? e.weeklyReceipt : true,
    enabled: typeof e.enabled === "boolean" ? e.enabled : true
  };
  const lt = e.lastTest;
  if (isObj(lt) && typeof lt.at === "string" && isNum(lt.status))
    out.lastTest = { at: lt.at, status: lt.status, hostAuthorized: lt.hostAuthorized === true };
  if (e.channel === "webhook" || e.channel === "cribl-bell" || e.channel === "cribl-target")
    out.channel = e.channel;
  if (typeof e.criblTargetId === "string" && e.criblTargetId !== "")
    out.criblTargetId = e.criblTargetId;
  if (out.criblTargetId !== void 0 && typeof e.confirmedAt === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/.test(e.confirmedAt) && Number.isFinite(Date.parse(e.confirmedAt)) && e.confirmedTargetId === out.criblTargetId) {
    out.confirmedAt = e.confirmedAt;
    out.confirmedTargetId = e.confirmedTargetId;
  }
  return out;
}

// core/kv.ts
var KEYS = {
  settings: "settings",
  prices: "prices",
  snapshot: "snapshot",
  inventory: "inventory",
  baselines: "baselines",
  timeline: "timeline",
  notifyLog: "notify/log",
  lock: "lock/meter",
  demoState: "demo/state",
  tour: "tour/active",
  meta: "meta",
  totals: "totals"
};
var PREFIXES = {
  rollMin: "roll/min/",
  rollHour: "roll/hour/",
  rollDay: "roll/day/",
  incidents: "incidents/"
};
var CHUNK_THRESHOLD_BYTES = 9e4;
var CHUNK_CHARS = 9e4;
var MAX_CHUNKS = 256;
var KEY_RE = /^[A-Za-z0-9_.-]+(?:\/[A-Za-z0-9_.-]+)*$/;
var PREFIX_RE = /^(?:[A-Za-z0-9_.-]+\/?)*$/;
var CHUNK_KEY_RE = /\/c\/\d+$/;
function assertValidKey(key) {
  if (!KEY_RE.test(key))
    throw new Error(`invalid KV key "${key}": use '/'-separated segments of [A-Za-z0-9_.-]`);
}
function assertValidPrefix(prefix) {
  if (!PREFIX_RE.test(prefix))
    throw new Error(`invalid KV prefix "${prefix}"`);
}
function chunkKey(key, index) {
  return `${key}/c/${index}`;
}
function isChunkKey(key) {
  return CHUNK_KEY_RE.test(key);
}
var KvHttpError = class extends Error {
  constructor(op, key, status, detail, retryAfterMs) {
    super(`KV ${op} ${key} failed: HTTP ${status}${detail ? ` ${detail.slice(0, 200)}` : ""}`);
    this.name = "KvHttpError";
    this.op = op;
    this.key = key;
    this.status = status;
    this.retryAfterMs = retryAfterMs;
  }
};
function kvError(op, key, res) {
  return new KvHttpError(op, key, res.status, res.text, res.status === 429 ? retryAfterOf(res, Date.now()) : void 0);
}
var KvDocTooLarge = class extends Error {
  constructor(key, bytes, chunks, maxChunks) {
    super(`KV document ${key} is ${bytes} bytes \u2192 ${chunks} chunks (max ${maxChunks}); compact it before writing`);
    this.name = "KvDocTooLarge";
    this.key = key;
    this.bytes = bytes;
    this.chunks = chunks;
  }
};
function unwrapKvText(text) {
  const t = text.trim();
  if (!t.startsWith('"'))
    return text;
  try {
    const inner = JSON.parse(t);
    if (typeof inner === "string") {
      const s = inner.trim();
      if (s.startsWith("{") || s.startsWith("[") || s.startsWith('"'))
        return inner;
    }
  } catch {
  }
  return text;
}
function normalizeKeyList(body, prefix) {
  const obj = body !== null && typeof body === "object" ? body : void 0;
  const list = Array.isArray(body) ? body : obj?.items ?? obj?.keys ?? obj?.data;
  if (!Array.isArray(list))
    return [];
  const out = /* @__PURE__ */ new Set();
  for (const entry of list) {
    let name = entry;
    if (entry !== null && typeof entry === "object") {
      const e = entry;
      name = e.key ?? e.name ?? e.id;
    }
    if (typeof name !== "string")
      continue;
    const clean = name.replace(/^\/+/, "");
    if (clean.length > 0 && clean.startsWith(prefix))
      out.add(clean);
  }
  return [...out].sort();
}
function isProxyMissingKey(res) {
  return res.status === 0 && /ReadableStreamDefaultController/.test(res.text ?? "") && /not valid JSON/.test(res.text ?? "");
}
function createHttpKvStore(http) {
  return {
    async get(key) {
      const res = await http.request("GET", kvKey(key), void 0, { raw: true });
      if (res.status === 404 || isProxyMissingKey(res))
        return null;
      if (!res.ok)
        throw kvError("GET", key, res);
      return unwrapKvText(res.text ?? (res.json === void 0 ? "" : JSON.stringify(res.json)));
    },
    async put(key, value) {
      const res = await http.request("PUT", kvKey(key), value, { raw: true });
      if (!res.ok)
        throw kvError("PUT", key, res);
    },
    async del(key) {
      const res = await http.request("DELETE", kvKey(key), void 0, { raw: true });
      if (res.status === 404)
        return;
      if (!res.ok)
        throw kvError("DELETE", key, res);
    },
    async list(prefix) {
      const res = await http.request("POST", kvKeys(), { prefix });
      if (!res.ok)
        throw kvError("LIST", prefix, res);
      let body = res.json;
      if (body === void 0 && res.text) {
        try {
          body = JSON.parse(res.text);
        } catch {
          body = void 0;
        }
      }
      return normalizeKeyList(body, prefix);
    }
  };
}
function createFetchKvStore(options) {
  return createHttpKvStore(createFetchHttp(options));
}
function isChunkManifest(v) {
  if (!isObj2(v) || v.chunked !== true)
    return false;
  return (v.encoding === "gzip-base64" || v.encoding === "identity-base64") && Number.isInteger(v.chunks) && v.chunks >= 1 && typeof v.sha === "string" && typeof v.bytes === "number";
}
function isObj2(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
var isStr = (v) => typeof v === "string";
var isNum2 = (v) => typeof v === "number" && Number.isFinite(v);
var isArr = Array.isArray;
function allValues(v, pred) {
  return isObj2(v) && Object.values(v).every(pred);
}
var V1_MIGRATIONS = { 0: (doc) => ({ ...doc, schemaVersion: 1 }) };
function dropBadItems(list, ok, where, warn) {
  const kept = list.filter(ok);
  if (kept.length !== list.length)
    warn(`dropped ${list.length - kept.length} malformed entries from ${where}`);
  return kept;
}
var flowsOk = (v) => allValues(v, isArr);
var SPECS = {
  settings: {
    name: "settings",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.displayTimezone) && isObj2(d.thresholds) && isObj2(d.budgets) && isArr(d.notifications) && isArr(d.excludedObjectKeys) && isObj2(d.humanize) && isObj2(d.demo) && isObj2(d.live) && isObj2(d.presenter) && (d.runtime === void 0 || d.runtime === "backend" || d.runtime === "ui")
  },
  prices: {
    name: "prices",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isArr(d.versions) && d.versions.every((v) => isObj2(v) && isStr(v.effectiveFrom) && isObj2(v.byOutputId))
  },
  snapshot: {
    name: "snapshot",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.sweepAt) && isObj2(d.headline) && isArr(d.flows) && isArr(d.destinations)
  },
  inventory: {
    name: "inventory",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.hash) && allValues(d.byGroup, (g) => isObj2(g) && isArr(g.inputs) && isArr(g.outputs) && isArr(g.pipelines) && isArr(g.routes))
  },
  baselines: {
    name: "baselines",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isObj2(d.byObject) && isObj2(d.rules)
  },
  timeline: {
    name: "timeline",
    latest: 1,
    migrations: V1_MIGRATIONS,
    repair(d, warn) {
      if (!isObj2(d.byGroup))
        return;
      for (const [gid, list] of Object.entries(d.byGroup)) {
        if (isArr(list))
          d.byGroup[gid] = dropBadItems(list, (c) => isObj2(c) && isStr(c.hash), `timeline.byGroup.${gid}`, warn);
      }
    },
    guard: (d) => allValues(d.byGroup, isArr)
  },
  notifyLog: {
    name: "notify/log",
    latest: 1,
    migrations: V1_MIGRATIONS,
    repair(d, warn) {
      if (isArr(d.items))
        d.items = dropBadItems(d.items, (x) => isObj2(x) && isStr(x.endpointId), "notify/log.items", warn);
    },
    guard: (d) => isArr(d.items)
  },
  demoState: {
    name: "demo/state",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isObj2(d.routes) && isObj2(d.trim) && isObj2(d.rates) && isObj2(d.muted) && isNum2(d.measuredLagSec)
  },
  meta: {
    name: "meta",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.installedAt) && isStr(d.collectingSince) && isNum2(d.sweepErrors) && isNum2(d.sweepCount)
  },
  totals: {
    name: "totals",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isObj2(d.byDay)
  },
  rollMinute: {
    name: "roll/min",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.bucketStart) && flowsOk(d.flows)
  },
  rollHour: {
    name: "roll/hour",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.day) && flowsOk(d.flows)
  },
  rollDay: {
    name: "roll/day",
    latest: 1,
    migrations: V1_MIGRATIONS,
    guard: (d) => isStr(d.month) && flowsOk(d.flows)
  },
  incidents: {
    name: "incidents",
    latest: 1,
    migrations: V1_MIGRATIONS,
    repair(d, warn) {
      if (isArr(d.items))
        d.items = dropBadItems(d.items, (x) => isObj2(x) && isStr(x.id), "incidents.items", warn);
    },
    guard: (d) => isArr(d.items)
  }
};
function upgradeDoc(spec, value, key, warn) {
  if (!isObj2(value)) {
    warn(`KV ${key}: ${spec.name} is not a JSON object; treating as missing`);
    return null;
  }
  let doc = value;
  let version2 = doc.schemaVersion === void 0 ? 0 : doc.schemaVersion;
  if (!Number.isInteger(version2) || version2 < 0) {
    warn(`KV ${key}: ${spec.name} has an invalid schemaVersion; treating as missing`, { schemaVersion: doc.schemaVersion });
    return null;
  }
  if (version2 > spec.latest) {
    warn(`KV ${key}: ${spec.name} schemaVersion ${String(version2)} is newer than this build (${spec.latest}); treating as missing`);
    return null;
  }
  while (version2 < spec.latest) {
    const step = spec.migrations?.[version2];
    if (!step) {
      warn(`KV ${key}: no migration for ${spec.name} from schemaVersion ${String(version2)}; treating as missing`);
      return null;
    }
    doc = step(doc);
    version2 = version2 + 1;
  }
  spec.repair?.(doc, (msg, data) => warn(`KV ${key}: ${msg}`, data));
  if (!spec.guard(doc)) {
    warn(`KV ${key}: ${spec.name} failed shape validation; treating as missing`);
    return null;
  }
  return doc;
}
var MAX_LOCK_HOLD_MS = 10 * 6e4;
function lockBinds(lock, now) {
  const expires = Date.parse(lock.expiresAt);
  return expires > now && expires - now <= MAX_LOCK_HOLD_MS;
}
var NOOP_LOGGER = { info: () => void 0, warn: () => void 0, error: () => void 0 };
var CORRUPT = Symbol("corrupt");
async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
    while (next < items.length) {
      const i = next++;
      out[i] = await fn(items[i], i);
    }
  });
  await Promise.all(workers);
  return out;
}
function parseStored(raw) {
  if (raw.trim() === "[object Object]")
    return CORRUPT;
  let v;
  try {
    v = JSON.parse(raw);
  } catch {
    return CORRUPT;
  }
  if (typeof v === "string") {
    const inner = v.trim();
    if (inner.startsWith("{") || inner.startsWith("[")) {
      try {
        return JSON.parse(inner);
      } catch {
      }
    }
  }
  return v;
}
function chunkText(raw) {
  const t = raw.trim();
  if (t.startsWith('"')) {
    const v = JSON.parse(t);
    if (typeof v !== "string")
      throw new Error("chunk is not a string");
    return v;
  }
  return t;
}
function splitEvery(s, size) {
  const parts = [];
  for (let i = 0; i < s.length; i += size)
    parts.push(s.slice(i, i + size));
  return parts.length > 0 ? parts : [""];
}
function createKvDocs(deps) {
  const logger = deps.logger ?? NOOP_LOGGER;
  const threshold = deps.chunkThresholdBytes ?? CHUNK_THRESHOLD_BYTES;
  const chunkChars = deps.chunkChars ?? CHUNK_CHARS;
  const maxChunks = deps.maxChunks ?? MAX_CHUNKS;
  const concurrency = deps.concurrency ?? 4;
  const warn = (msg, data) => logger.warn(msg, data);
  let calls = 0;
  const store = {
    get(k) {
      calls++;
      return deps.kv.get(k);
    },
    put(k, v) {
      calls++;
      return deps.kv.put(k, v);
    },
    del(k) {
      calls++;
      return deps.kv.del(k);
    },
    list(p) {
      calls++;
      return deps.kv.list(p);
    }
  };
  const knownChunks = /* @__PURE__ */ new Map();
  function codecFor(encoding) {
    if (encoding === "identity-base64")
      return identityCodec;
    return deps.codec.encoding === "identity" ? null : deps.codec;
  }
  async function assemble(key, m) {
    const raws = await mapLimit(
      Array.from({ length: m.chunks }, (_, i) => i),
      concurrency,
      (i) => store.get(chunkKey(key, i))
    );
    const missing = raws.findIndex((r) => r === null);
    if (missing >= 0)
      return { reason: `chunk ${missing} of ${m.chunks} is missing` };
    const codec = codecFor(m.encoding);
    if (!codec)
      return { reason: `cannot decode ${m.encoding} with an identity codec` };
    let text;
    try {
      const b64 = raws.map(chunkText).join("");
      text = await codec.gunzip(fromBase64(b64));
    } catch (e) {
      return { reason: `chunks do not decode: ${e instanceof Error ? e.message : String(e)}` };
    }
    if (fnv1a(text) !== m.sha)
      return { reason: "hash mismatch" };
    return { text };
  }
  async function readChunked(key, m, allowRetry) {
    if (!isChunkManifest(m) || m.chunks > maxChunks) {
      warn(`KV ${key}: malformed chunk manifest; treating as missing`, m);
      return CORRUPT;
    }
    knownChunks.set(key, m.chunks);
    const got = await assemble(key, m);
    if ("text" in got) {
      const parsed = parseStored(got.text);
      if (parsed === CORRUPT)
        warn(`KV ${key}: reassembled document is not valid JSON; treating as missing`);
      return parsed;
    }
    if (allowRetry) {
      const again = await store.get(key);
      if (again === null)
        return null;
      const next = parseStored(again);
      if (isObj2(next) && next.chunked === true) {
        if (isChunkManifest(next) && next.sha !== m.sha)
          return readChunked(key, next, false);
      } else if (next !== CORRUPT) {
        knownChunks.set(key, 0);
        return next;
      }
    }
    warn(`KV ${key}: chunked document failed verification (${got.reason}); treating as missing`);
    return CORRUPT;
  }
  async function load(key) {
    const raw = await store.get(key);
    if (raw === null)
      return null;
    const parsed = parseStored(raw);
    if (parsed === CORRUPT) {
      warn(`KV ${key}: stored value is not valid JSON; treating as missing`);
      return CORRUPT;
    }
    if (isObj2(parsed) && parsed.chunked === true)
      return readChunked(key, parsed, true);
    knownChunks.set(key, 0);
    return parsed;
  }
  async function deleteChunkIndexes(key, indexes) {
    if (indexes.length === 0)
      return;
    try {
      await mapLimit(indexes, concurrency, (i) => store.del(chunkKey(key, i)));
    } catch (e) {
      warn(`KV ${key}: could not delete stale chunks (${indexes.join(",")}); they are unreferenced`, e);
    }
  }
  function range(from, to) {
    return Array.from({ length: Math.max(0, to - from) }, (_, i) => from + i);
  }
  async function save(key, doc) {
    const json2 = JSON.stringify(doc);
    if (json2 === void 0)
      throw new TypeError(`KV ${key}: refusing to write a non-JSON value`);
    const bytes = utf8ByteLength(json2);
    if (bytes <= threshold) {
      await store.put(key, json2);
      knownChunks.set(key, 0);
      return;
    }
    const encoding = deps.codec.encoding === "identity" ? "identity-base64" : "gzip-base64";
    const parts = splitEvery(toBase64(await deps.codec.gzip(json2)), chunkChars);
    if (parts.length > maxChunks)
      throw new KvDocTooLarge(key, bytes, parts.length, maxChunks);
    await mapLimit(parts, concurrency, (p, i) => store.put(chunkKey(key, i), JSON.stringify(p)));
    const manifest = {
      schemaVersion: 1,
      chunked: true,
      encoding,
      chunks: parts.length,
      bytes,
      sha: fnv1a(json2),
      updatedAt: new Date(deps.clock.now()).toISOString()
    };
    await store.put(key, JSON.stringify(manifest));
    knownChunks.set(key, parts.length);
  }
  async function getTyped(key, spec) {
    assertValidKey(key);
    const loaded = await load(key);
    if (loaded === null || loaded === CORRUPT)
      return null;
    return upgradeDoc(spec, loaded, key, warn);
  }
  async function putTyped(key, spec, doc) {
    assertValidKey(key);
    if (!isObj2(doc) || doc.schemaVersion !== spec.latest || !spec.guard(doc)) {
      throw new TypeError(`KV ${key}: refusing to write an invalid ${spec.name} document`);
    }
    await save(key, doc);
  }
  function familyKey(prefix, key) {
    return key.startsWith(prefix) ? key : prefix + key.replace(/^\/+/, "");
  }
  function parseLock(v) {
    if (v === null || v === CORRUPT)
      return null;
    if (isObj2(v) && isStr(v.owner) && isStr(v.expiresAt) && Number.isFinite(Date.parse(v.expiresAt))) {
      return { owner: v.owner, expiresAt: v.expiresAt };
    }
    warn(`KV ${KEYS.lock}: malformed lock; treating as free`, v);
    return null;
  }
  const readLock = async () => parseLock(await load(KEYS.lock));
  const writeLock = (lock) => save(KEYS.lock, lock);
  return {
    getSettings: () => getTyped(KEYS.settings, SPECS.settings),
    // D57: whatever the caller built, the stored document holds no webhook URL (rule 4.5; core/settings.ts).
    putSettings: (doc) => putTyped(KEYS.settings, SPECS.settings, storableSettings(doc)),
    getPrices: () => getTyped(KEYS.prices, SPECS.prices),
    putPrices: (doc) => putTyped(KEYS.prices, SPECS.prices, doc),
    getSnapshot: () => getTyped(KEYS.snapshot, SPECS.snapshot),
    putSnapshot: (doc) => putTyped(KEYS.snapshot, SPECS.snapshot, doc),
    getInventory: () => getTyped(KEYS.inventory, SPECS.inventory),
    putInventory: (doc) => putTyped(KEYS.inventory, SPECS.inventory, doc),
    getBaselines: () => getTyped(KEYS.baselines, SPECS.baselines),
    putBaselines: (doc) => putTyped(KEYS.baselines, SPECS.baselines, doc),
    getTimeline: () => getTyped(KEYS.timeline, SPECS.timeline),
    putTimeline: (doc) => putTyped(KEYS.timeline, SPECS.timeline, doc),
    getNotifyLog: () => getTyped(KEYS.notifyLog, SPECS.notifyLog),
    putNotifyLog: (doc) => putTyped(KEYS.notifyLog, SPECS.notifyLog, doc),
    getDemoState: () => getTyped(KEYS.demoState, SPECS.demoState),
    putDemoState: (doc) => putTyped(KEYS.demoState, SPECS.demoState, doc),
    getMeta: () => getTyped(KEYS.meta, SPECS.meta),
    putMeta: (doc) => putTyped(KEYS.meta, SPECS.meta, doc),
    getTotals: () => getTyped(KEYS.totals, SPECS.totals),
    putTotals: (doc) => putTyped(KEYS.totals, SPECS.totals, doc),
    getRollMinute: (key) => getTyped(familyKey(PREFIXES.rollMin, key), SPECS.rollMinute),
    putRollMinute: (key, doc) => putTyped(familyKey(PREFIXES.rollMin, key), SPECS.rollMinute, doc),
    getRollHour: (key) => getTyped(familyKey(PREFIXES.rollHour, key), SPECS.rollHour),
    putRollHour: (key, doc) => putTyped(familyKey(PREFIXES.rollHour, key), SPECS.rollHour, doc),
    getRollDay: (key) => getTyped(familyKey(PREFIXES.rollDay, key), SPECS.rollDay),
    putRollDay: (key, doc) => putTyped(familyKey(PREFIXES.rollDay, key), SPECS.rollDay, doc),
    getIncidents: (key) => getTyped(familyKey(PREFIXES.incidents, key), SPECS.incidents),
    putIncidents: (key, doc) => putTyped(familyKey(PREFIXES.incidents, key), SPECS.incidents, doc),
    async listKeys(prefix) {
      assertValidPrefix(prefix);
      const names = await store.list(prefix);
      return [...new Set(names.map((k) => k.replace(/^\/+/, "")))].filter((k) => k.startsWith(prefix) && !isChunkKey(k)).sort();
    },
    async listKeysWithChunks(prefix) {
      assertValidPrefix(prefix);
      const names = [...new Set((await store.list(prefix)).map((k) => k.replace(/^\/+/, "")))].filter((k) => k.startsWith(prefix));
      const chunks = {};
      const keys = [];
      for (const k of names) {
        if (!isChunkKey(k)) {
          keys.push(k);
          continue;
        }
        const at = k.lastIndexOf("/c/");
        const index = Number(k.slice(at + 3));
        if (Number.isInteger(index) && index >= 0)
          (chunks[k.slice(0, at)] ??= []).push(index);
      }
      for (const list of Object.values(chunks))
        list.sort((a, b) => a - b);
      return { keys: keys.sort(), chunks };
    },
    async del(key, opts) {
      assertValidKey(key);
      if (opts?.listed) {
        await store.del(key);
        await deleteChunkIndexes(key, [...opts.listed]);
        knownChunks.delete(key);
        return;
      }
      let chunks = knownChunks.get(key) ?? 0;
      const raw = await store.get(key);
      if (raw !== null) {
        const parsed = parseStored(raw);
        if (isChunkManifest(parsed))
          chunks = Math.max(chunks, Math.min(parsed.chunks, maxChunks));
        await store.del(key);
      }
      await deleteChunkIndexes(key, range(0, chunks));
      knownChunks.delete(key);
    },
    async acquireLock(owner, ttlMs, opts = {}) {
      if (!owner)
        throw new Error("acquireLock needs a non-empty owner");
      const now = deps.clock.now();
      const current = await readLock();
      if (current && current.owner !== owner && lockBinds(current, now))
        return false;
      await writeLock({ owner, expiresAt: new Date(now + Math.max(0, ttlMs)).toISOString() });
      if (opts.verify === false)
        return true;
      const back = await readLock();
      return back !== null && back.owner === owner;
    },
    async releaseLock(owner) {
      const current = await readLock();
      if (!current || current.owner !== owner)
        return false;
      await writeLock({ owner, expiresAt: new Date(deps.clock.now()).toISOString() });
      return true;
    },
    async renewLock(owner, ttlMs) {
      if (!owner)
        throw new Error("renewLock needs a non-empty owner");
      const now = deps.clock.now();
      const current = await readLock();
      if (!current || current.owner !== owner)
        return false;
      await writeLock({ owner, expiresAt: new Date(now + Math.max(0, ttlMs)).toISOString() });
      if (Date.parse(current.expiresAt) > now)
        return true;
      const back = await readLock();
      return back !== null && back.owner === owner;
    },
    getLock: readLock,
    async getDoc(key, guard) {
      assertValidKey(key);
      const loaded = await load(key);
      if (loaded === null || loaded === CORRUPT)
        return null;
      if (!guard(loaded)) {
        warn(`KV ${key}: document failed its guard; treating as missing`);
        return null;
      }
      return loaded;
    },
    async putDoc(key, doc) {
      assertValidKey(key);
      await save(key, doc);
    },
    calls: () => calls,
    resetCalls() {
      calls = 0;
    }
  };
}

// core/format.ts
var MC_PER_CENT = 1e3;
var MC_PER_DOLLAR = 1e5;
var MINUS = "\u2212";
function groupThousands(n) {
  const s = String(Math.trunc(Math.abs(n)));
  let out = "";
  for (let i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 === 0)
      out += ",";
    out += s[i];
  }
  return out;
}
function roundHalfUp(x) {
  return Math.floor(x + 0.5);
}
var UNDER_ONE_DOLLAR = "< $1";
function fmtDollars(mc) {
  if (!Number.isFinite(mc))
    return "$0";
  const dollars = roundHalfUp(Math.abs(mc) / MC_PER_DOLLAR);
  if (dollars === 0 && mc !== 0)
    return mc < 0 ? `${MINUS}${UNDER_ONE_DOLLAR}` : UNDER_ONE_DOLLAR;
  const body = `$${groupThousands(dollars)}`;
  return mc < 0 && dollars > 0 ? `${MINUS}${body}` : body;
}
function fmtDollarsCents(mc) {
  if (!Number.isFinite(mc))
    return "$0.00";
  const cents = roundHalfUp(Math.abs(mc) / MC_PER_CENT);
  const body = `$${groupThousands(Math.floor(cents / 100))}.${String(cents % 100).padStart(2, "0")}`;
  return mc < 0 && cents > 0 ? `${MINUS}${body}` : body;
}
function fmtPct(ratio2) {
  if (!Number.isFinite(ratio2))
    return "0%";
  const pct = roundHalfUp(Math.abs(ratio2) * 100);
  const text = pct >= 1e3 ? pct.toLocaleString("en-US") : String(pct);
  return ratio2 < 0 && pct > 0 ? `${MINUS}${text}%` : `${text}%`;
}
function fmtDuration(sec) {
  const total = Number.isFinite(sec) && sec > 0 ? Math.round(sec) : 0;
  const h = Math.floor(total / 3600);
  const m = Math.floor(total % 3600 / 60);
  const s = total % 60;
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${ss}` : `${m}:${ss}`;
}
var NBSP = "\xA0";
function fmtDurationShort(sec) {
  const total = Number.isFinite(sec) && sec > 0 ? Math.round(sec) : 0;
  const u = (n, unit) => `${n}${NBSP}${unit}`;
  if (total < 60)
    return u(total, "s");
  const d = Math.floor(total / 86400);
  const h = Math.floor(total % 86400 / 3600);
  const m = Math.floor(total % 3600 / 60);
  const s = total % 60;
  if (d > 0)
    return h > 0 ? `${u(d, "d")} ${u(h, "h")}` : u(d, "d");
  if (h > 0)
    return m > 0 ? `${u(h, "h")} ${u(m, "min")}` : u(h, "h");
  return s > 0 ? `${u(m, "min")} ${u(s, "s")}` : u(m, "min");
}
function perYear(mcPerDay) {
  return mcPerDay * 365;
}
function mcToDollarInput(mc) {
  const v = Math.max(0, Math.round(mc));
  const whole = Math.floor(v / MC_PER_DOLLAR);
  const rest = v % MC_PER_DOLLAR;
  let frac = String(rest).padStart(5, "0").replace(/0+$/, "");
  if (frac.length < 2)
    frac = frac.padEnd(2, "0");
  return `${whole}.${frac}`;
}
function roundToDollarsM(mc) {
  if (!Number.isFinite(mc))
    return 0;
  const dollars = roundHalfUp(Math.abs(mc) / MC_PER_DOLLAR);
  return (mc < 0 ? -dollars : dollars) * MC_PER_DOLLAR || 0;
}
function roundToCentsM(mc) {
  if (!Number.isFinite(mc))
    return 0;
  const cents = roundHalfUp(Math.abs(mc) / MC_PER_CENT);
  return (mc < 0 ? -cents : cents) * MC_PER_CENT || 0;
}
function keepUnderOneDollar(mc, rounded) {
  return rounded === 0 && Number.isFinite(mc) && mc !== 0 ? mc : rounded;
}
function footMoney(m, unit = "dollars") {
  const round = unit === "cents" ? roundToCentsM : (mc) => keepUnderOneDollar(mc, roundToDollarsM(mc));
  const whpM = round(m.whpM);
  const savedM = round(m.savedM);
  const paidM = round(m.paidM);
  const foots = Math.abs(m.whpM - m.paidM - m.savedM) < (unit === "cents" ? MC_PER_CENT : MC_PER_DOLLAR) / 2;
  return { whpM, paidM: foots ? Math.max(0, whpM - savedM) : paidM, savedM };
}
function footColumn(valuesM, totalM) {
  const rounded = valuesM.map((v) => roundToDollarsM(v));
  const n = rounded.length;
  if (n === 0)
    return rounded;
  let deficit = Math.round((roundToDollarsM(totalM) - rounded.reduce((a, b) => a + b, 0)) / MC_PER_DOLLAR);
  if (deficit === 0 || Math.abs(deficit) > n)
    return rounded;
  const slack = valuesM.map((v, i) => ({ i, d: (Number.isFinite(v) ? v - rounded[i] : 0) / MC_PER_DOLLAR }));
  if (deficit > 0) {
    slack.sort((a, b) => b.d - a.d || a.i - b.i);
    for (let k = 0; deficit > 0; k = (k + 1) % n, deficit--)
      rounded[slack[k].i] += MC_PER_DOLLAR;
  } else {
    slack.sort((a, b) => a.d - b.d || b.i - a.i);
    for (let k = 0, guard = 0; deficit < 0 && guard < 2 * n; k = (k + 1) % n, guard++) {
      if (rounded[slack[k].i] < MC_PER_DOLLAR)
        continue;
      rounded[slack[k].i] -= MC_PER_DOLLAR;
      deficit++;
    }
  }
  return rounded;
}

// core/strings.ts
function fill(template, values = {}) {
  return template.replace(/\{(\w+)\}/g, (m, k) => k in values ? String(values[k]) : m);
}
function plural(n, forms) {
  return n === 1 ? forms.one : forms.other;
}
var RECEIPT_STRINGS = {
  weeklyTitle: "Meter Reader \u2014 weekly receipt",
  periodTitle: "Meter Reader \u2014 receipt",
  savedLastWeek: "Saved by Cribl, last week",
  savedFor: "Saved by Cribl, {period}",
  saved: "Saved by Cribl",
  wouldHavePaid: "Would have paid {amount}",
  paid: "Paid {amount}",
  savedPct: "{pct} saved",
  vs: "vs. {what}: {sign}{pct}%",
  priorWeek: "prior week",
  openAlertsNone: "Open alerts: none",
  openAlertsList: "Open alerts: {n} ({titles})",
  openAlertsCount: "Open alerts: {n}",
  openThisWeek: "Open this week on the Receipt:",
  /** WeeklyReceipt.sentLate: nothing was metering at Monday 12:00 UTC, so the week's first sweep sent it. */
  sentLate: "Sent late: nothing was metering at Monday 12:00 UTC, so it went out with the first metering since.",
  /** a flow with no pipeline and no route */
  otherLine: "Other",
  topSaversRates: "Top savers, per day at current rates",
  perDaySuffix: "/day",
  netAfterCribl: "Net after Cribl {amount}",
  netAfterCriblYear: "Net after Cribl {amount} a year",
  paidForItself: "Paid for itself {multiple}",
  annualizedFrom: "annualized from {basis}",
  lastDays: { one: "the last {n} day", other: "the last {n} days" },
  todaySoFar: "today so far",
  asOf: "as of {date}",
  rangeRate: "\u2248 {amount} a day at this rate",
  periods: {
    mtd: "month to date",
    today: "today",
    "30d": "last 30 days",
    annualized: "annualized run rate"
  },
  // P1-F02: measured (bytes dropped) vs assumed (credited at another destination's price).
  divertedTag: " (diverted)",
  byReduction: "Saved by reduction {amount}",
  byDiversion: "by diversion {amount}",
  // P0-23: the Basis block.
  basis: "Basis",
  basisPrice: "{label}: {price}",
  typicalList: "typical list",
  presetTypicalList: "{preset} typical list",
  customPrice: "custom price",
  creditedUnpriced: "credited $0 until {label} has a price",
  creditedAt: "credited at {label}'s {price}",
  neverSavings: "never counted as savings",
  morePriced: { one: "and {n} more priced destination", other: "and {n} more priced destinations" },
  noMoney: "No destination carried money",
  unpricedExcluded: { one: "{n} destination unpriced, excluded", other: "{n} destinations unpriced, excluded" },
  metered: "Metered {metered} of {expected} {unit} ({pct})",
  meteredUnder1: "under 1%",
  units: { minute: "minute", minutes: "minutes", day: "day", days: "days" },
  // P2-W13: Copy receipt for a comparison (receiptTextForComparison).
  comparisonTitle: "Meter Reader \u2014 receipt comparison",
  thisRange: "This range",
  comparedPerDay: "Compared per day, at each window's own rate:",
  comparedPerDayWhy: "they were metered for different lengths.",
  aDaySuffix: " a day",
  nothingToCompare: "Nothing was metered to compare with.",
  // A comparison window with nothing metered: its money is unknown, never $0 (review W2, P0-18's class).
  notMetered: "not metered",
  change: "Change",
  windowWouldHavePaid: "{name}: would have paid {amount}",
  windowPaid: "  paid {amount} \xB7 {pct} saved"
};
var PAYLOAD_STRINGS = {
  testTitle: "Meter Reader test notification",
  eventTitle: "Meter Reader {event}",
  testPrefix: "Test: ",
  recoveredPrefix: "Recovered: ",
  newNormalPrefix: "New normal: ",
  closedPrefix: "Closed: ",
  // P1-F07: what a member did with it.
  memberClosed: {
    accepted: "Accepted as the new normal: ",
    muted: "Muted: ",
    excluded: "Alerts stopped: "
  },
  closedBy: " by {by}",
  closedAsNewNormal: "Closed as the new normal",
  recovered: "Recovered",
  /** Core-10 (M9): the plain text's close word for a below-floor close. */
  closed: "Closed",
  weeklyFallback: "{glyph} Meter Reader weekly receipt \xB7 {label} \xB7 Saved by Cribl {amount}",
  weeklyHeader: "{glyph} Weekly receipt \xB7 {label}",
  openReceipt: "Open the Receipt",
  openLedger: "Open in Ledger",
  openLedgerAt: "Open in Ledger: {link}",
  incidentFallback: "{glyph} {title} \xB7 {money}",
  // The money line of every alert channel (the bell, a notification target, Slack, ServiceNow), worded by the rule the
  // incident card follows (src/copy/en.ts incidents.impact, D62; rules round 2 carried it to the channels): only an
  // open regression is projected to a year, as what it costs if left; a spike is a day while it lasts; a recovered
  // incident is a day while it lasted, for how long and what it came to; good news keeps its year; budget pace, none.
  impact: {
    open: "{perDay} a day \xB7 {perYear} a year if left",
    spike: "{perDay} a day above normal while it lasts",
    closed: "{perDay} a day above normal while it lasted \xB7 {duration} \xB7 \u2248 {realized} in all",
    closedNoDuration: "{perDay} a day above normal while it lasted",
    perDayPerYear: "{perDay} a day \xB7 {perYear} a year",
    overBudget: "{perDay} a day over budget",
    // Founder-build r1 core-10 (M9, D26/D47): closed by the dollar floor, not recovered — the ratio is still down.
    belowFloor: "fell under the {floor}/day floor; savings still at {after}"
  },
  demoProfile: " \xB7 1-minute confirmation (demo profile). Default is 3.",
  noChange: "No configuration change found nearby",
  nearby: " (nearby change; it may not be the cause)",
  perHour: "{amount}/hour",
  pctOfBudget: "{pct}% of budget",
  caughtIn: "caught in {duration}",
  caughtOnCatchUp: "caught on catch-up",
  caughtOnCatchUpAfter: "caught on catch-up, {duration} after the change",
  // The Slack field grid.
  fields: {
    commit: "Commit",
    by: "By",
    openFor: "Open for",
    extraPerDay: "Extra per day",
    wasCostingExtra: "Was costing extra per day",
    perYear: "Per year",
    perYearIfLeft: "Per year if left",
    lostWhileOpen: "Lost while open",
    costWhileOpen: "Extra cost while open",
    baseline: "Baseline",
    peak: "Peak",
    now: "Now",
    overBudgetPerDay: "Over budget per day",
    peakProjection: "Peak projection",
    projected: "Projected",
    threshold: "Threshold",
    savingPerDay: "Saving per day",
    before: "Before",
    after: "After",
    lostPerDay: "Lost per day",
    wasLosingPerDay: "Was losing per day",
    recoveredTo: "Recovered to"
  },
  // The plain-text alert (ServiceNow's description, logs).
  plain: {
    ratio: "Savings ratio {drop}{back} \xB7 {money}",
    cost: "Cost {rise}{back} \xB7 {money}",
    budget: "{pace}{back} \xB7 {perDay} a day over",
    before: "{value} before",
    recoveredTo: " \xB7 recovered to {value}",
    projected: "Projected {value}",
    threshold: "Threshold {pct}%",
    commit: 'Commit {hash} "{message}" by {author}',
    opened: "Opened {at}",
    closed: " \xB7 {closed} {at}"
  },
  servicenowWeekly: "Meter Reader weekly receipt {label}",
  // "Send a test alert": the SPEC 12.1 example incident every test payload carries. Founder-build r1 core-11 (m8,
  // #14): neutral names — a release's test alert quotes no demo-rig object (no "mrd_", no "demo:").
  testSample: {
    label: "Example pipeline",
    commitMessage: "Example: a pipeline change",
    objectId: "example_pipeline",
    outputId: "example_destination"
  }
};
var AUTHOR_STRINGS = {
  /** An API credential's commit, unnamed: the client id's last four characters, never the id. */
  apiClient: "API client \xB7\xB7{tail}",
  unknownAuthor: "unknown author"
};
var CREDIT_STRINGS = {
  builder: "Steve Koelpin",
  /** The sign-off on a receipt and on an alert message. */
  signature: "Meter Reader by Steve Koelpin"
};

// core/humanize.ts
var DEMO_LABELS = {
  mrd_pay_sample: "Payments API sampling",
  mrd_win_xml_pack: "Windows XML pack",
  mrd_win_docs_reduce: "Windows XML reduction (aggressive)",
  mrd_k8s_noise: "Kubernetes noise filter",
  mrd_passthrough: "Passthrough (no reduction)",
  mrd_pan_pack: "Palo Alto pack",
  mrd_vpc_pack: "VPC Flow aggregation",
  // the rig's destinations, as demo/rig/destinations.json labels them (P1-I04: never slugs beside prose sources)
  mrd_siem_prod: "SIEM (prod)",
  mrd_siem_apps: "SIEM (apps)",
  mrd_analytics: "Analytics",
  mrd_archive_s3: "Archive (S3)",
  mrd_windows_dc: "Windows DC security events",
  mrd_windows_workstations: "Windows workstation events",
  mrd_pan_firewall: "Palo Alto firewall",
  mrd_vpc_flow: "AWS VPC Flow Logs",
  mrd_payments_api: "Payments API",
  mrd_k8s_prod: "Kubernetes prod"
};
var HUMANIZE_DICTIONARY = {
  win: "Windows",
  fw: "firewall",
  k8s: "Kubernetes",
  agg: "aggregation",
  dedupe: "duplicate suppression",
  trim: "trimming",
  sample: "sampling",
  pay: "Payments",
  api: "API",
  dc: "DC",
  pan: "Palo Alto",
  vpc: "VPC",
  siem: "SIEM",
  s3: "S3",
  devnull: "DevNull",
  // Cribl's built-in destination, spelled as the Ledger and Cribl's own UI spell it
  xml: "XML",
  json: "JSON",
  ocsf: "OCSF",
  to: "to",
  for: "for",
  cdn: "CDN",
  docs: "docs",
  reduce: "reduction",
  noise: "noise filter",
  prod: "prod"
};
var BUILTIN_ID_TOKENS = {
  cribl: "Cribl",
  http: "HTTP",
  tcp: "TCP",
  udp: "UDP",
  tls: "(TLS)",
  json: "JSON",
  hec: "HEC",
  splunk: "Splunk",
  elastic: "Elasticsearch API",
  syslog: "Syslog",
  otel: "OpenTelemetry",
  kafka: "Kafka",
  datadog: "Datadog",
  datagen: "Datagen",
  agent: "Agent",
  s3: "S3"
};
function builtinIdLabel(id) {
  const m = /^(?:in|out)_([a-z0-9_]+)$/.exec(id);
  if (!m)
    return void 0;
  const words = m[1].split("_").filter((t) => t.length > 0).map((t) => BUILTIN_ID_TOKENS[t] ?? (/^\d+$/.test(t) ? t : void 0));
  return words.length > 0 && words.every((w) => w !== void 0) ? words.join(" ") : void 0;
}
function stripPrefix(id) {
  return id.replace(/^mrd?_/i, "");
}
function packLabel(packId) {
  const words = packId.replace(/^(?:cribl|cc)[-_]/i, "").split(/[_\-\s]+/).filter((t) => t.length > 0).map((t) => HUMANIZE_DICTIONARY[t.toLowerCase()] ?? t[0].toUpperCase() + t.slice(1));
  return words.length > 0 ? `${words.join(" ")} pack` : packId;
}
function capitalizeFirst(s) {
  return s.length === 0 ? s : s[0].toUpperCase() + s.slice(1);
}
function humanize(id, overrides) {
  if (typeof id !== "string" || id.length === 0)
    return "";
  const stripped = stripPrefix(id);
  const override = overrides?.[id] ?? overrides?.[stripped];
  if (override !== void 0 && override.trim() !== "")
    return override;
  const demo = DEMO_LABELS[id];
  if (demo !== void 0)
    return demo;
  const pack = /^pack:(.+)$/i.exec(id);
  if (pack)
    return packLabel(pack[1]);
  const builtin = builtinIdLabel(id);
  if (builtin)
    return builtin;
  const tokens = (stripped || id).split(/[_\-\s]+/).filter((t) => t.length > 0).map((t) => HUMANIZE_DICTIONARY[t.toLowerCase()] ?? t);
  if (tokens.length === 0)
    return id;
  return capitalizeFirst(tokens.join(" "));
}
var API_CLIENT = /^([^@\s]+)@clients$/i;
var API_CLIENT_LABEL_PREFIX = "client:";
function apiClientKey(author) {
  const m = typeof author === "string" ? API_CLIENT.exec(author.trim()) : null;
  return m ? `${API_CLIENT_LABEL_PREFIX}${m[1].slice(-4)}` : void 0;
}
function apiClientFallback(key) {
  return fill(AUTHOR_STRINGS.apiClient, { tail: key.slice(API_CLIENT_LABEL_PREFIX.length) });
}
function displayAuthor(author, labels) {
  const a = typeof author === "string" ? author.trim() : "";
  if (a === "")
    return AUTHOR_STRINGS.unknownAuthor;
  const key = apiClientKey(a);
  if (!key)
    return a;
  const named = labels?.[key]?.trim();
  return named ? named : apiClientFallback(key);
}

// core/adapters/webhook.ts
var WEBHOOK_TIMEOUT_MS = 1e4;
var WEBHOOK_BACKOFF_MS = [2e3, 8e3];
function ipv4(host) {
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(host))
    return void 0;
  const o = host.split(".").map(Number);
  return o.every((n) => n <= 255) ? o : void 0;
}
function publicIpv4(o) {
  const [a, b] = o;
  if (a === 0 || a === 10 || a === 127 || a >= 224)
    return false;
  if (a === 100 && b >= 64 && b <= 127)
    return false;
  if (a === 169 && b === 254)
    return false;
  if (a === 172 && b >= 16 && b <= 31)
    return false;
  if (a === 192 && (b === 168 || b === 0 && o[2] === 0))
    return false;
  if (a === 198 && (b === 18 || b === 19))
    return false;
  return true;
}
function isPublicWebhookHost(hostname) {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  if (host === "")
    return false;
  if (host.startsWith("[")) {
    const v6 = host.slice(1, -1);
    if (v6 === "::" || v6 === "::1")
      return false;
    if (/^f[cd][0-9a-f]{0,2}:/.test(v6) || /^fe[89ab][0-9a-f]?:/.test(v6))
      return false;
    const mapped = /^::ffff:(?:([0-9a-f]{1,4}):([0-9a-f]{1,4})|(\d{1,3}(?:\.\d{1,3}){3}))$/.exec(v6);
    if (mapped) {
      const o2 = mapped[3] ? ipv4(mapped[3]) : [parseInt(mapped[1], 16) >> 8, parseInt(mapped[1], 16) & 255, parseInt(mapped[2], 16) >> 8, parseInt(mapped[2], 16) & 255];
      return o2 !== void 0 && publicIpv4(o2);
    }
    return true;
  }
  const o = ipv4(host);
  if (o)
    return publicIpv4(o);
  if (!host.includes("."))
    return false;
  return !/(^|\.)(localhost|local|internal|home\.arpa|lan)$/.test(host);
}
function hostnameOf(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return void 0;
  }
}
function classifyStatus(status) {
  if (status >= 200 && status < 300)
    return { ok: true, retry: false };
  if (status === 0)
    return { ok: false, retry: true, error: "network_error" };
  if (status === 403)
    return { ok: false, retry: false, error: "host_not_authorized" };
  if (status >= 500)
    return { ok: false, retry: true, error: `http_${status}` };
  return { ok: false, retry: false, error: `http_${status}` };
}
function redactUrls(text) {
  return text.replace(/https?:\/\/[^\s'"<>)]+/gi, (u) => hostnameOf(u) ?? "a URL");
}
async function deliver(p) {
  const sleep = p.sleep ?? defaultSleep;
  const backoff = p.backoffMs ?? WEBHOOK_BACKOFF_MS;
  const timeoutMs = p.timeoutMs ?? WEBHOOK_TIMEOUT_MS;
  const body = typeof p.body === "string" ? p.body : JSON.stringify(p.body);
  const logs = [];
  const log = (attempt, at, status, error, detail) => {
    const entry = { endpointId: p.endpointId, event: p.event, status, attempt, at: new Date(at).toISOString(), kind: p.kind ?? "notify" };
    if (p.incidentId !== void 0)
      entry.incidentId = p.incidentId;
    if (error !== void 0)
      entry.error = error;
    if (detail !== void 0)
      entry.detail = redactUrls(detail);
    logs.push(entry);
  };
  if (!/^https:\/\/[^\s/]+/i.test(p.url)) {
    log(1, p.clock.now(), 0, "invalid_url", "webhook URLs must be https://");
    return logs;
  }
  if (urlHasCredentials(p.url)) {
    log(1, p.clock.now(), 0, "invalid_url", "webhook URLs must not carry credentials");
    return logs;
  }
  const hostname = hostnameOf(p.url);
  if (hostname === void 0 || !isPublicWebhookHost(hostname)) {
    log(1, p.clock.now(), 0, "host_not_authorized", "webhook URLs must name a public host");
    return logs;
  }
  if (p.sender.allows && !p.sender.allows(p.url)) {
    log(1, p.clock.now(), 0, "host_not_authorized", "the host is not on this runtime's webhook host list");
    return logs;
  }
  for (let attempt = 1; attempt <= backoff.length + 1; attempt++) {
    const at = p.clock.now();
    let status = 0;
    let transportError;
    try {
      const res = await p.sender.post(p.url, body, timeoutMs);
      status = res.status;
      transportError = res.error;
    } catch (e) {
      transportError = e instanceof Error ? e.message : String(e);
    }
    const verdict = classifyStatus(status);
    log(attempt, at, status, verdict.error, status === 0 ? transportError : void 0);
    if (verdict.ok || !verdict.retry || attempt > backoff.length)
      break;
    await sleep(backoff[attempt - 1]);
  }
  return logs;
}
function lastAttempt(logs) {
  return logs[logs.length - 1];
}
function createFetchWebhookSender(fetchFn, opts = {}) {
  const allowHosts = opts.allowHosts?.map((h) => h.trim().toLowerCase()).filter(Boolean);
  return {
    ...allowHosts && allowHosts.length > 0 ? { allows: (url) => allowHosts.includes((hostnameOf(url) ?? "").toLowerCase()) } : {},
    async post(url, body, timeoutMs) {
      const controller = typeof AbortController === "function" ? new AbortController() : void 0;
      const init = { method: "POST", headers: { "content-type": "application/json" }, body, redirect: "error" };
      if (controller)
        init.signal = controller.signal;
      let timer;
      const timedOut = new Promise((resolve) => {
        timer = setTimeout(() => resolve("timeout"), timeoutMs);
      });
      try {
        const exchange = (async () => {
          const res = await Reflect.apply(fetchFn, globalThis, [url, init]);
          await res.text().catch(() => "");
          return res.status;
        })();
        exchange.catch(() => void 0);
        const outcome = await Promise.race([exchange, timedOut]);
        if (outcome === "timeout") {
          controller?.abort();
          return { status: 0, error: `timeout after ${timeoutMs} ms` };
        }
        return { status: outcome };
      } catch (e) {
        return { status: 0, error: e instanceof Error ? e.message : String(e) };
      } finally {
        if (timer !== void 0)
          clearTimeout(timer);
      }
    }
  };
}

// core/flows.ts
var seg2 = (s) => s === void 0 || s === null || s === "" ? "-" : s;
function makeFlowKey(groupId, inputId, routeId, pipelineId, outputId) {
  return [seg2(groupId), seg2(inputId), seg2(routeId), seg2(pipelineId), seg2(outputId)].join("|");
}
var KINDS = ["in", "route", "pipe", "out"];
function parseObjectKey(key) {
  const m = typeof key === "string" ? /^([a-z]+):([^:]*):(.+)$/.exec(key) : null;
  if (!m || !KINDS.includes(m[1]))
    return null;
  return { kind: m[1], groupId: m[2], id: m[3] };
}
var Q = `(['"\`])((?:(?!\\1)[^\\\\]|\\\\.)*)\\1`;
var RE_EQ = new RegExp(`__inputId\\s*===?\\s*${Q}`, "g");
var RE_EQ_REV = new RegExp(`${Q}\\s*===?\\s*__inputId\\b`, "g");
var RE_STARTS = new RegExp(`__inputId\\s*\\.\\s*startsWith\\(\\s*${Q}\\s*\\)`, "g");
var RE_LIST_ITEM = new RegExp(Q, "g");

// core/incidents.ts
var RECOVERY_POINTS = 5;
function titleFor(incident) {
  switch (incident.type) {
    case "regression":
      return `Savings dropped: ${incident.label}`;
    case "spike":
      return `Cost spike: ${incident.label}`;
    case "budget":
      return `Over budget pace: ${incident.label}`;
    case "goodnews":
      return `Savings improved: ${incident.label}`;
    default:
      return incident.label;
  }
}
function incidentReadings(inc) {
  const { before, after } = inc;
  if (!inc.closedAt || inc.type === "goodnews")
    return { before, after, legacy: false };
  if (inc.recoveredTo !== void 0)
    return { before, after, recoveredTo: inc.recoveredTo, legacy: false };
  const recoveredSide = inc.type === "regression" ? (before - after) * 100 <= RECOVERY_POINTS : after < before;
  if (!recoveredSide)
    return { before, after, legacy: false };
  return { before, recoveredTo: after, legacy: true };
}
var ENDPOINT_FAILED_RETRY_MS = 2 * 6e4;
var MEMBER_MUTE_MS = 24 * 60 * 6e4;

// core/presets.ts
var PRESETS = [
  { id: "splunk_cloud", label: "Splunk Cloud", matchTypes: ["splunk_hec"], milliCentsPerGb: 225e3, billing: "entitlement", monogram: "SC" },
  { id: "splunk_enterprise", label: "Splunk Enterprise", matchTypes: ["splunk", "splunk_lb"], milliCentsPerGb: 2e5, billing: "entitlement", monogram: "SE" },
  { id: "sentinel", label: "Microsoft Sentinel", matchTypes: ["sentinel", "azure_logs"], milliCentsPerGb: 25e4, billing: "entitlement", monogram: "MS" },
  {
    id: "crowdstrike_ngsiem",
    label: "CrowdStrike Falcon Next-Gen SIEM / LogScale",
    matchTypes: ["humio", "humio_hec", "crowdstrike_ngsiem", "crowdstrike_next_gen_siem"],
    milliCentsPerGb: 2e5,
    billing: "entitlement",
    monogram: "CS"
  },
  { id: "datadog", label: "Datadog Logs", matchTypes: ["datadog"], milliCentsPerGb: 18e4, billing: "metered", monogram: "DD" },
  { id: "elastic", label: "Elastic Cloud", matchTypes: ["elastic", "elastic_cloud"], milliCentsPerGb: 35e3, billing: "metered", monogram: "EC" },
  { id: "google_secops", label: "Google SecOps", matchTypes: ["google_chronicle", "chronicle"], milliCentsPerGb: 15e4, billing: "entitlement", monogram: "GS" },
  { id: "sumo", label: "Sumo Logic", matchTypes: ["sumo_logic"], milliCentsPerGb: 25e4, billing: "entitlement", monogram: "SL" },
  { id: "newrelic", label: "New Relic", matchTypes: ["newrelic", "newrelic_events"], milliCentsPerGb: 4e4, billing: "metered", monogram: "NR" },
  { id: "s3", label: "Amazon S3", matchTypes: ["s3"], milliCentsPerGb: 2300, billing: "storage", monogram: "S3" },
  { id: "azure_blob", label: "Azure Blob", matchTypes: ["azure_blob"], milliCentsPerGb: 1800, billing: "storage", monogram: "AB" },
  { id: "cribl_lake", label: "Cribl Lake", matchTypes: ["cribl_lake"], milliCentsPerGb: 5e3, billing: "storage", monogram: "CL" },
  { id: "databricks", label: "Databricks", matchTypes: ["databricks", "databricks_zerobus"], milliCentsPerGb: 5e3, billing: "metered", monogram: "DB" },
  { id: "snowflake", label: "Snowflake", matchTypes: ["snowflake", "snowflake_streaming"], milliCentsPerGb: 3400, billing: "metered", monogram: "SF" },
  { id: "internal", label: "Internal / free", matchTypes: ["devnull", "cribl_tcp", "cribl_http", "router"], milliCentsPerGb: 0, billing: "metered", monogram: "IF" }
];
var byId = new Map(PRESETS.map((p) => [p.id, p]));
var DAYS_PER_MONTH = 365 / 12;

// core/pricing.ts
var BUDGET_EARLY_MIN = 3 * 1440;

// core/rollups.ts
var MINUTE_RETENTION_MS = 25 * HOUR_MS;

// core/range.ts
var RELATIVE_PRESETS = [
  { key: "1h", hours: 1 },
  { key: "6h", hours: 6 },
  { key: "24h", hours: 24 },
  { key: "7d", hours: 7 * 24 },
  { key: "30d", hours: 30 * 24 }
];
var MINUTE_REACH_MS = 24 * HOUR_MS;
var HOUR_REACH_MS = 31 * DAY_MS;
var DOC_CAPS = { minute: 26, hour: 33, day: 14 };
var WEEK_MS = 7 * DAY_MS;
var COMMIT_COMPARE_MS = 24 * HOUR_MS;
var COMPARE_DOC_CAP = Math.max(...Object.values(DOC_CAPS));

// core/receipt.ts
var RECEIPT_WIDTH = 48;
var RECEIPT_MAX_LINES = 5;
var RECEIPT_MAX_BASIS_PRICES = 8;
var MIN_LEADER_DOTS = 4;
var perGb = (mc) => `$${mcToDollarInput(mc)}/GB`;
var int = (n) => Math.round(n).toLocaleString("en-US");
function wrapWords(text, width = RECEIPT_WIDTH, indent = "  ") {
  const out = [];
  let line = "";
  for (const word of text.split(" ").filter(Boolean)) {
    const lead = out.length === 0 ? "" : indent;
    if (line === "")
      line = `${lead}${word}`;
    else if (line.length + 1 + word.length <= width)
      line += ` ${word}`;
    else {
      out.push(line);
      line = `${indent}${word}`;
    }
  }
  if (line !== "")
    out.push(line);
  return out.map((l) => truncate(l, width));
}
function namesPreset(label, presetLabel) {
  const a = label.trim().toLowerCase();
  const b = presetLabel.trim().toLowerCase();
  return a.length > 0 && (a === b || b.startsWith(`${a} `) || a.startsWith(`${b} `));
}
function basisPriceText(p) {
  const preset = p.source === "preset" && p.presetLabel ? namesPreset(p.label, p.presetLabel) ? RECEIPT_STRINGS.typicalList : fill(RECEIPT_STRINGS.presetTypicalList, { preset: p.presetLabel }) : void 0;
  const source = preset ? `, ${preset}` : p.source === "custom" ? `, ${RECEIPT_STRINGS.customPrice}` : "";
  let text = `${fill(RECEIPT_STRINGS.basisPrice, { label: p.label, price: perGb(p.milliCentsPerGb) })}${source}`;
  if (p.creditedAt) {
    const c = p.creditedAt;
    const amount = c.whpM !== void 0 ? `: ${fmtDollars(c.whpM)}` : "";
    text += c.unpriced ? `; ${fill(RECEIPT_STRINGS.creditedUnpriced, { label: c.label })}` : `; ${fill(RECEIPT_STRINGS.creditedAt, { label: c.label, price: perGb(c.milliCentsPerGb) })}${amount}`;
  } else if (p.noSavings)
    text += `; ${RECEIPT_STRINGS.neverSavings}`;
  return text;
}
function coverageLine(c) {
  const metered = Math.min(Math.max(0, c.metered), c.expected);
  const floorPct = Math.floor(metered / c.expected * 100);
  const pct = metered >= c.expected ? fmtPct(1) : metered > 0 && floorPct === 0 ? RECEIPT_STRINGS.meteredUnder1 : fmtPct(floorPct / 100);
  const unit = c.unit === "days" ? plural(c.expected, { one: RECEIPT_STRINGS.units.day, other: RECEIPT_STRINGS.units.days }) : plural(c.expected, { one: RECEIPT_STRINGS.units.minute, other: RECEIPT_STRINGS.units.minutes });
  return fill(RECEIPT_STRINGS.metered, { metered: int(metered), expected: int(c.expected), unit, pct });
}
function basisBlock(b) {
  const out = ["", RECEIPT_STRINGS.basis];
  const shown = b.prices.slice(0, RECEIPT_MAX_BASIS_PRICES);
  for (const p of shown)
    out.push(...wrapWords(basisPriceText(p)));
  const more = b.prices.length - shown.length;
  if (more > 0)
    out.push(fill(plural(more, RECEIPT_STRINGS.morePriced), { n: more }));
  if (b.prices.length === 0)
    out.push(RECEIPT_STRINGS.noMoney);
  if (b.unpricedCount > 0)
    out.push(fill(plural(b.unpricedCount, RECEIPT_STRINGS.unpricedExcluded), { n: b.unpricedCount }));
  if (b.coverage)
    out.push(coverageLine(b.coverage));
  return out;
}
function truncate(s, max) {
  if (max <= 0)
    return "";
  return s.length <= max ? s : `${s.slice(0, Math.max(0, max - 1))}\u2026`;
}
function wrapSegments(segments, width = RECEIPT_WIDTH) {
  const out = [];
  let line = "";
  for (const seg3 of segments) {
    if (line === "")
      line = seg3;
    else if (line.length + 3 + seg3.length <= width)
      line += ` \xB7 ${seg3}`;
    else {
      out.push(line);
      line = seg3;
    }
  }
  if (line !== "")
    out.push(line);
  return out.map((l) => truncate(l, width));
}
function alertLines(alerts, width = RECEIPT_WIDTH) {
  if (alerts.length === 0)
    return [RECEIPT_STRINGS.openAlertsNone];
  const one = fill(RECEIPT_STRINGS.openAlertsList, { n: alerts.length, titles: alerts.map((a) => a.title).join("; ") });
  if (one.length <= width)
    return [one];
  return [fill(RECEIPT_STRINGS.openAlertsCount, { n: alerts.length }), ...alerts.map((a) => truncate(`  ${a.title}`, width))];
}
function receiptSignOff(width = RECEIPT_WIDTH) {
  const sig = CREDIT_STRINGS.signature;
  return ["", `${" ".repeat(Math.max(0, Math.floor((width - sig.length) / 2)))}${sig}`];
}
function spread(left, right, width = RECEIPT_WIDTH) {
  const gap = width - left.length - right.length;
  if (gap >= 2)
    return [`${left}${" ".repeat(gap)}${right}`];
  return [truncate(left, width), right.padStart(width)];
}
function footedReceiptLines(lines, totalM) {
  const listed = lines.map((l) => l.diverted ? { label: l.label, savedM: l.savedM, diverted: true } : { label: l.label, savedM: l.savedM });
  const rest = totalM - listed.reduce((s, l) => s + l.savedM, 0);
  if (listed.length >= RECEIPT_MAX_LINES && roundToDollarsM(rest) > 0)
    listed.push({ label: RECEIPT_STRINGS.otherLine, savedM: rest });
  const footed = footColumn(
    listed.map((l) => l.savedM),
    totalM
  );
  return listed.map((l, i) => ({ ...l, savedM: footed[i] === 0 && l.savedM > 0 ? l.savedM : footed[i] }));
}
function renderReceipt(b) {
  const suffix = b.lineSuffix ?? "";
  if (b.footLines)
    b = { ...b, lines: footedReceiptLines(b.lines, b.savedM) };
  const amounts = [...b.lines.map((l) => `${fmtDollars(l.savedM)}${suffix}`), fmtDollars(b.savedM)];
  const field2 = Math.max(8, ...amounts.map((a) => a.length + 2));
  const out = [...spread(b.title, b.rangeLabel)];
  if (b.linesHeader && b.lines.length > 0)
    out.push(truncate(b.linesHeader, RECEIPT_WIDTH));
  for (const l of b.lines) {
    const amount = `${fmtDollars(l.savedM)}${suffix}`.padStart(field2);
    const room = RECEIPT_WIDTH - field2 - 1 - MIN_LEADER_DOTS;
    const tag = l.diverted ? DIVERTED_TAG : "";
    const label = `${truncate(l.label, room - tag.length)}${tag}`;
    const dots = RECEIPT_WIDTH - label.length - 1 - field2;
    out.push(`${label} ${".".repeat(dots)}${amount}`);
  }
  out.push("-".repeat(RECEIPT_WIDTH));
  out.push(...spread(b.totalLabel, fmtDollars(b.savedM)));
  out.push(...wrapSegments(b.summary));
  if (b.divertedM !== void 0 && b.divertedM > 0)
    out.push(...wrapSegments(splitSegments(b.savedM, b.divertedM)));
  if (b.net && b.net.length > 0)
    out.push(...wrapSegments(b.net));
  if (b.trend)
    out.push(b.trend);
  if (b.note)
    out.push(...wrapWords(b.note, RECEIPT_WIDTH, ""));
  out.push(...alertLines(b.openAlerts));
  if (b.basis)
    out.push(...basisBlock(b.basis));
  if (b.link)
    out.push("", RECEIPT_STRINGS.openThisWeek, b.link);
  out.push(...receiptSignOff());
  return out.join("\n");
}
var DIVERTED_TAG = RECEIPT_STRINGS.divertedTag;
function splitSegments(savedM, divertedM) {
  const d = Math.min(Math.max(0, divertedM), Math.max(0, savedM));
  const shown = footMoney({ whpM: savedM, paidM: savedM - d, savedM: d });
  return [fill(RECEIPT_STRINGS.byReduction, { amount: fmtDollars(shown.paidM) }), fill(RECEIPT_STRINGS.byDiversion, { amount: fmtDollars(shown.savedM) })];
}
function summarySegments(whpM, paidM, savedM, r) {
  const shown = footMoney({ whpM, paidM, savedM });
  return [fill(RECEIPT_STRINGS.wouldHavePaid, { amount: fmtDollars(shown.whpM) }), fill(RECEIPT_STRINGS.paid, { amount: fmtDollars(shown.paidM) }), fill(RECEIPT_STRINGS.savedPct, { pct: fmtPct(r) })];
}
function trendLine(trendPct, what) {
  if (trendPct === void 0)
    return void 0;
  const sign = trendPct > 0 ? "+" : trendPct < 0 ? "\u2212" : "";
  return fill(RECEIPT_STRINGS.vs, { what, sign, pct: Math.abs(trendPct) });
}
function receiptText(r) {
  return renderReceipt({
    title: RECEIPT_STRINGS.weeklyTitle,
    rangeLabel: r.label,
    lines: r.lines,
    footLines: true,
    totalLabel: RECEIPT_STRINGS.savedLastWeek,
    savedM: r.savedM,
    summary: summarySegments(r.whpM, r.paidM, r.savedM, r.ratio),
    ...r.divertedM !== void 0 ? { divertedM: r.divertedM } : {},
    trend: trendLine(r.trendPct, RECEIPT_STRINGS.priorWeek),
    ...r.sentLate ? { note: RECEIPT_STRINGS.sentLate } : {},
    openAlerts: r.openIncidents,
    ...r.basis ? { basis: r.basis } : {},
    ...r.link ? { link: r.link } : {}
  });
}
var PERIOD_CAPTIONS = RECEIPT_STRINGS.periods;

// core/detector.ts
var BUDGET_INTERVAL_MS = 60 * MINUTE_MS;
var SPIKE_REPEAT_MS = 24 * 60 * MINUTE_MS;
var NEW_NORMAL_NOTE = "new-normal";

// core/payloads.ts
var KIND_NAMES = { in: "input", route: "route", pipe: "pipeline", out: "output" };
var CATCH_UP_NOTE = "catch-up";
function isCatchUp(i) {
  return (i.notes ?? []).includes(CATCH_UP_NOTE);
}
function caughtInSeconds(i) {
  if (i.caughtInSec === void 0)
    return void 0;
  const opened = fromIso(i.openedAt);
  const detected = i.detectedAt ? fromIso(i.detectedAt) : Number.NaN;
  const late = Number.isFinite(opened) && Number.isFinite(detected) && detected > opened ? (detected - opened) / 1e3 : 0;
  return Math.round(i.caughtInSec + late);
}
function ledgerLink(linkBase, objectKey2) {
  const base = (linkBase ?? "").replace(/\/+$/, "");
  return `${base}/ledger?object=${encodeURIComponent(objectKey2).replace(/%3A/gi, ":")}`;
}
var BELOW_FLOOR_NOTE = "below-floor";
function closedBelowFloor(i) {
  return !!i.closedAt && !i.closedReason && (i.notes ?? []).includes(BELOW_FLOOR_NOTE);
}
function toCanonicalIncident(i, linkBase, labels, floorCentsPerDay) {
  const parsed = parseObjectKey(i.objectKey);
  const id = parsed?.id ?? i.objectKey;
  const isRatio = i.type === "regression" || i.type === "goodnews";
  const reading = (value) => isRatio ? { ratio: value } : { value };
  const r = incidentReadings(i);
  const out = {
    id: i.id,
    type: i.type,
    severity: i.severity,
    title: titleFor({ type: i.type, label: i.label || humanize(id, labels) }),
    object: {
      kind: parsed ? KIND_NAMES[parsed.kind] : "route",
      id,
      label: i.label || humanize(id, labels),
      group: parsed?.groupId ?? ""
    },
    before: reading(r.before),
    after: r.after === void 0 ? {} : reading(r.after),
    impact: { perDayMillicents: i.impactPerDayM, perDay: fmtDollars(i.impactPerDayM), perYear: fmtDollars(perYear(i.impactPerDayM)) },
    openedAt: i.openedAt,
    link: ledgerLink(linkBase, i.objectKey),
    notes: [...i.notes ?? []]
  };
  if (r.recoveredTo !== void 0)
    out.recoveredTo = reading(r.recoveredTo);
  if (i.outputId)
    out.object.destination = i.outputId;
  if (i.cause)
    out.cause = i.cause;
  if (i.commit) {
    out.commit = { hash: i.commit.hash, message: i.commit.message, author: displayAuthor(i.commit.author, labels), match: i.commit.match };
    if (i.commit.deployedAt)
      out.commit.deployedAt = i.commit.deployedAt;
  }
  const caught = caughtInSeconds(i);
  if (caught !== void 0)
    out.caughtInSeconds = caught;
  if (i.closedAt)
    out.closedAt = i.closedAt;
  if (i.closedAt && i.closedReason)
    out.closedReason = i.closedReason;
  if (i.closedAt && i.closedBy)
    out.closedBy = i.closedBy;
  if (closedBelowFloor(i) && floorCentsPerDay !== void 0 && Number.isFinite(floorCentsPerDay))
    out.floorPerDay = fmtDollars(floorCentsPerDay * 1e3);
  return out;
}
function canonicalPayload(event, opts) {
  const p = {
    schemaVersion: 1,
    app: "meter-reader",
    event,
    sentAt: opts.sentAt ?? (/* @__PURE__ */ new Date()).toISOString(),
    workspace: opts.workspace
  };
  if (opts.incident)
    p.incident = toCanonicalIncident(opts.incident, opts.linkBase, opts.labels, opts.regressionFloorCentsPerDay);
  if (opts.receipt)
    p.receipt = opts.receipt;
  return p;
}
var clip = (s, max) => s.length <= max ? s : `${s.slice(0, max - 1)}\u2026`;
var esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
var escCode = (s) => esc(s).replace(/\u0060/g, "'");
var field = (label, value) => ({ type: "mrkdwn", text: clip(`*${label}*
${value}`, 2e3) });
function closedAsNewNormal(i) {
  return (i.notes ?? []).includes(NEW_NORMAL_NOTE);
}
var MEMBER_CLOSED_PREFIX = PAYLOAD_STRINGS.memberClosed;
function closedPrefix(i) {
  if (i.closedReason)
    return MEMBER_CLOSED_PREFIX[i.closedReason] ?? PAYLOAD_STRINGS.closedPrefix;
  if ((i.notes ?? []).includes(BELOW_FLOOR_NOTE))
    return PAYLOAD_STRINGS.closedPrefix;
  return closedAsNewNormal(i) ? PAYLOAD_STRINGS.newNormalPrefix : PAYLOAD_STRINGS.recoveredPrefix;
}
function closedByText(i) {
  return i.closedReason && i.closedBy ? fill(PAYLOAD_STRINGS.closedBy, { by: i.closedBy }) : "";
}
function slackGlyph(p) {
  if (p.event === "receipt.weekly")
    return ":receipt:";
  const i = p.incident;
  if (!i)
    return ":large_blue_circle:";
  if ((p.event === "incident.closed" || i.closedAt) && (closedAsNewNormal(i) || i.closedReason || (i.notes ?? []).includes(BELOW_FLOOR_NOTE)))
    return ":large_blue_circle:";
  if (p.event === "incident.closed" || i.closedAt || i.type === "goodnews")
    return ":large_green_circle:";
  if (i.severity === "high")
    return ":red_circle:";
  if (i.severity === "medium")
    return ":large_orange_circle:";
  return ":large_blue_circle:";
}
function commitText(i) {
  if (!i.commit)
    return PAYLOAD_STRINGS.noChange;
  const nearby = i.commit.match === "nearby" ? PAYLOAD_STRINGS.nearby : "";
  return `\`${i.commit.hash.slice(0, 7)}\` ${esc(clip(i.commit.message, 150))}${nearby}`;
}
function perHour(value) {
  return fill(PAYLOAD_STRINGS.perHour, { amount: fmtDollars(value ?? 0) });
}
var pctOfBudget = (value) => fill(PAYLOAD_STRINGS.pctOfBudget, { pct: Math.round(value ?? 0) });
var F = PAYLOAD_STRINGS.fields;
function openSeconds(i) {
  const opened = fromIso(i.openedAt);
  const closed = i.closedAt ? fromIso(i.closedAt) : Number.NaN;
  return Number.isFinite(opened) && Number.isFinite(closed) && closed >= opened ? (closed - opened) / 1e3 : void 0;
}
function endedByItself(i) {
  return !!i.closedAt && !i.closedReason;
}
var DEFAULT_FLOOR_CENTS_PER_DAY = 500;
function realizedImpactM(i) {
  const sec = openSeconds(i);
  if (sec === void 0 || sec > 86400)
    return void 0;
  return Math.round(Math.max(0, i.impact.perDayMillicents) * sec / 86400);
}
function fmtRealized(mc) {
  return mc < 100 * MC_PER_DOLLAR ? fmtDollarsCents(mc) : fmtDollars(mc);
}
function impactPhrase(i) {
  const M = PAYLOAD_STRINGS.impact;
  const money = { perDay: i.impact.perDay, perYear: i.impact.perYear };
  if (i.type === "budget")
    return fill(M.overBudget, money);
  if (i.type === "goodnews")
    return fill(M.perDayPerYear, money);
  if (i.closedAt && !i.closedReason && (i.notes ?? []).includes(BELOW_FLOOR_NOTE))
    return fill(M.belowFloor, { floor: i.floorPerDay ?? fmtDollars(DEFAULT_FLOOR_CENTS_PER_DAY * 1e3), after: fmtPct(i.after?.ratio ?? 0) });
  if (endedByItself(i)) {
    const sec = openSeconds(i);
    const realized = realizedImpactM(i);
    return sec === void 0 || realized === void 0 ? fill(M.closedNoDuration, money) : fill(M.closed, { ...money, duration: fmtDurationShort(sec), realized: fmtRealized(realized) });
  }
  return fill(i.type === "spike" ? M.spike : M.open, money);
}
function incidentFields(i, closed, labels) {
  const commitPair = [field(F.commit, commitText(i)), field(F.by, i.commit ? esc(displayAuthor(i.commit.author, labels)) : "\u2014")];
  const open = closed ? openSeconds(i) : void 0;
  const underFloor = closed && closedBelowFloor(i);
  const recovered = closed && !i.closedReason && !underFloor;
  const openFor = open !== void 0 ? [field(F.openFor, fmtDuration(open))] : [];
  const realized = recovered ? realizedImpactM(i) : void 0;
  const cameTo = (label) => realized !== void 0 ? [field(label, `\u2248 ${fmtRealized(realized)}`)] : [];
  switch (i.type) {
    case "spike":
      return [
        field(recovered ? F.wasCostingExtra : F.extraPerDay, i.impact.perDay),
        ...cameTo(F.costWhileOpen),
        ...commitPair,
        field(F.baseline, perHour(i.before.value)),
        ...i.after.value !== void 0 ? [field(recovered ? F.peak : F.now, perHour(i.after.value))] : [],
        ...i.recoveredTo ? [field(F.now, perHour(i.recoveredTo.value))] : [],
        ...openFor
      ];
    case "budget":
      return [
        field(F.overBudgetPerDay, i.impact.perDay),
        ...i.after.value !== void 0 ? [field(recovered ? F.peakProjection : F.projected, pctOfBudget(i.after.value))] : [],
        field(F.threshold, `${Math.round(i.before.value ?? 0)}%`),
        ...i.recoveredTo ? [field(F.now, pctOfBudget(i.recoveredTo.value))] : [],
        ...openFor
      ];
    case "goodnews":
      return [
        field(F.savingPerDay, i.impact.perDay),
        field(F.perYear, i.impact.perYear),
        ...commitPair,
        field(F.before, fmtPct(i.before.ratio ?? 0)),
        field(F.after, fmtPct(i.after.ratio ?? 0))
      ];
    default:
      return [
        field(recovered ? F.wasLosingPerDay : F.lostPerDay, i.impact.perDay),
        // m15 (#36): an accepted or muted drop reads as open — "a year if left", as its fallback text says; a
        // below-floor close has no year at all (M9).
        ...recovered ? cameTo(F.lostWhileOpen) : underFloor ? [] : [field(F.perYearIfLeft, i.impact.perYear)],
        ...commitPair,
        field(F.before, fmtPct(i.before.ratio ?? 0)),
        ...i.after.ratio !== void 0 ? [field(F.after, fmtPct(i.after.ratio))] : [],
        ...i.recoveredTo ? [field(F.recoveredTo, fmtPct(i.recoveredTo.ratio ?? 0))] : [],
        ...openFor
      ];
  }
}
function caughtLine(i) {
  if (isCatchUp(i))
    return i.caughtInSeconds !== void 0 ? fill(PAYLOAD_STRINGS.caughtOnCatchUpAfter, { duration: fmtDuration(i.caughtInSeconds) }) : PAYLOAD_STRINGS.caughtOnCatchUp;
  return i.caughtInSeconds !== void 0 ? fill(PAYLOAD_STRINGS.caughtIn, { duration: fmtDuration(i.caughtInSeconds) }) : "";
}
function localTime(iso, tz) {
  const t = iso ? fromIso(iso) : Number.NaN;
  if (Number.isNaN(t))
    return "";
  return `${formatLocalTime(t, tz)}${tz === "UTC" ? " UTC" : ""}`;
}
function slackPayload(canonical, opts = {}) {
  const tz = opts.tz ?? "UTC";
  const glyph = slackGlyph(canonical);
  if (canonical.event === "receipt.weekly" && canonical.receipt) {
    const r = canonical.receipt;
    return {
      text: esc(fill(PAYLOAD_STRINGS.weeklyFallback, { glyph, label: r.label, amount: fmtDollars(r.savedM) })),
      blocks: [
        { type: "header", text: { type: "plain_text", text: clip(fill(PAYLOAD_STRINGS.weeklyHeader, { glyph, label: r.label }), 150), emoji: true } },
        { type: "section", text: { type: "mrkdwn", text: `\`\`\`
${clip(escCode(receiptText(r)), 2990)}
\`\`\`` } },
        // P0-23: the week on the Receipt, as the incident cards open the Ledger.
        ...r.link ? [{ type: "actions", elements: [{ type: "button", text: { type: "plain_text", text: PAYLOAD_STRINGS.openReceipt }, url: r.link, action_id: "open_receipt" }] }] : []
      ]
    };
  }
  const i = canonical.incident;
  if (!i) {
    const text = canonical.event === "test" ? PAYLOAD_STRINGS.testTitle : fill(PAYLOAD_STRINGS.eventTitle, { event: canonical.event });
    return { text: esc(`${glyph} ${text}`), blocks: [{ type: "section", text: { type: "mrkdwn", text: esc(`${glyph} ${text}`) } }] };
  }
  const recovered = (canonical.event === "incident.closed" || !!i.closedAt) && i.type !== "goodnews";
  const prefix = canonical.event === "test" ? PAYLOAD_STRINGS.testPrefix : recovered ? closedPrefix(i) : "";
  const title = `${prefix}${i.title}`;
  const destination = i.object.destination ? humanize(i.object.destination, opts.labels) : i.object.group;
  const when = recovered && i.closedAt ? localTime(i.closedAt, tz) : localTime(i.openedAt, tz);
  const context = [CREDIT_STRINGS.signature, destination, `${when}${recovered ? closedByText(i) : ""}`, recovered ? "" : caughtLine(i)].filter((s) => s).join(" \xB7 ");
  const notes = i.notes.includes("demo-profile") ? PAYLOAD_STRINGS.demoProfile : "";
  return {
    // The top-level text is the notification fallback: Slack reads &, < and > as control characters there too.
    text: esc(fill(PAYLOAD_STRINGS.incidentFallback, { glyph, title, money: impactPhrase(i) })),
    blocks: [
      { type: "header", text: { type: "plain_text", text: clip(`${glyph} ${title}`, 150), emoji: true } },
      { type: "section", fields: incidentFields(i, recovered, opts.labels) },
      { type: "context", elements: [{ type: "mrkdwn", text: esc(`${context}${notes}`) }] },
      { type: "actions", elements: [{ type: "button", text: { type: "plain_text", text: PAYLOAD_STRINGS.openLedger }, url: i.link, action_id: "open_in_ledger" }] }
    ]
  };
}
function incidentPlainText(i, tz = "UTC") {
  const P = PAYLOAD_STRINGS.plain;
  const money = { money: impactPhrase(i) };
  const lines = [i.title];
  if (i.type === "regression" || i.type === "goodnews") {
    const drop = i.after.ratio !== void 0 ? `${fmtPct(i.before.ratio ?? 0)} \u2192 ${fmtPct(i.after.ratio)}` : fill(P.before, { value: fmtPct(i.before.ratio ?? 0) });
    const back = i.recoveredTo ? fill(P.recoveredTo, { value: fmtPct(i.recoveredTo.ratio ?? 0) }) : "";
    lines.push(fill(P.ratio, { drop, back, ...money }));
  } else if (i.type === "spike") {
    const rise = i.after.value !== void 0 ? `${perHour(i.before.value)} \u2192 ${perHour(i.after.value)}` : fill(P.before, { value: perHour(i.before.value) });
    const back = i.recoveredTo ? fill(P.recoveredTo, { value: perHour(i.recoveredTo.value) }) : "";
    lines.push(fill(P.cost, { rise, back, ...money }));
  } else {
    const pace = i.after.value !== void 0 ? fill(P.projected, { value: pctOfBudget(i.after.value) }) : fill(P.threshold, { pct: Math.round(i.before.value ?? 0) });
    const back = i.recoveredTo ? fill(P.recoveredTo, { value: pctOfBudget(i.recoveredTo.value) }) : "";
    lines.push(fill(P.budget, { pace, back, perDay: i.impact.perDay }));
  }
  lines.push(i.commit ? fill(P.commit, { hash: i.commit.hash.slice(0, 7), message: i.commit.message, author: displayAuthor(i.commit.author) }) : PAYLOAD_STRINGS.noChange);
  const line = caughtLine(i);
  const caught = line ? `${line[0].toUpperCase()}${line.slice(1)} \xB7 ` : "";
  const closedWord = i.closedReason ? `${closedPrefix(i).replace(/: $/, "")}${closedByText(i)}` : closedAsNewNormal(i) ? PAYLOAD_STRINGS.closedAsNewNormal : closedBelowFloor(i) ? PAYLOAD_STRINGS.closed : PAYLOAD_STRINGS.recovered;
  const closedPart = i.closedAt && i.type !== "goodnews" ? fill(P.closed, { closed: closedWord, at: localTime(i.closedAt, tz) || i.closedAt }) : "";
  lines.push(`${caught}${fill(P.opened, { at: localTime(i.openedAt, tz) || i.openedAt })}${closedPart}`);
  lines.push(fill(PAYLOAD_STRINGS.openLedgerAt, { link: i.link }));
  lines.push(CREDIT_STRINGS.signature);
  return lines.join("\n");
}
var URGENCY = { high: 1, medium: 2, info: 3 };
function servicenowPayload(canonical, tz = "UTC") {
  if (canonical.receipt) {
    return {
      short_description: fill(PAYLOAD_STRINGS.servicenowWeekly, { label: canonical.receipt.label }),
      description: receiptText(canonical.receipt),
      urgency: 3,
      u_meter_reader: canonical.receipt
    };
  }
  if (canonical.incident) {
    const i = canonical.incident;
    const recovered = canonical.event === "incident.closed" || !!i.closedAt;
    return {
      short_description: `${recovered && i.type !== "goodnews" ? closedPrefix(i) : ""}${i.title}`,
      description: incidentPlainText(i, tz),
      urgency: URGENCY[i.severity] ?? 3,
      u_meter_reader: i
    };
  }
  const title = fill(PAYLOAD_STRINGS.eventTitle, { event: canonical.event });
  return { short_description: title, description: title, urgency: 3, u_meter_reader: { event: canonical.event } };
}
function genericPayload(canonical) {
  return canonical;
}
function payloadFor(format, canonical, opts = {}) {
  switch (format) {
    case "slack":
      return slackPayload(canonical, opts);
    case "servicenow":
      return servicenowPayload(canonical, opts.tz ?? "UTC");
    default:
      return genericPayload(canonical);
  }
}
function testPayload(workspace, nowIso, linkBase = "") {
  const openedMs = fromIso(nowIso);
  const at = (deltaSec) => new Date((Number.isNaN(openedMs) ? 0 : openedMs) + deltaSec * 1e3).toISOString();
  const incident = {
    id: "inc_test00",
    type: "regression",
    severity: "high",
    objectKey: `pipe:default:${PAYLOAD_STRINGS.testSample.objectId}`,
    label: PAYLOAD_STRINGS.testSample.label,
    outputId: PAYLOAD_STRINGS.testSample.outputId,
    openedAt: at(0),
    cause: "commit",
    commit: {
      hash: "a1f3c9e",
      message: PAYLOAD_STRINGS.testSample.commitMessage,
      author: "meter-reader",
      committedAt: at(-180),
      deployedAt: at(-171),
      groupId: "default",
      match: "message"
    },
    before: 0.75,
    after: 0.5,
    impactPerDayM: 25e5,
    caughtInSec: 171,
    notes: ["sample"],
    deliveries: []
  };
  const out = canonicalPayload("test", { incident, workspace, linkBase, sentAt: nowIso });
  if (out.incident)
    out.incident.link = ledgerRootLink(linkBase);
  return out;
}
function ledgerRootLink(linkBase) {
  return `${(linkBase ?? "").replace(/\/+$/, "")}/ledger`;
}

// core/rezone.ts
function resolveMeterZone(storedSettings, totals, defaultTimeZone) {
  const valid = (z) => typeof z === "string" && z !== "" && isValidTimeZone(z);
  if (valid(storedSettings?.displayTimezone))
    return canonicalZoneName(storedSettings.displayTimezone);
  const kept = valid(totals?.zone) ? canonicalZoneName(totals.zone) : void 0;
  if (kept && kept !== "UTC")
    return kept;
  return valid(defaultTimeZone) ? canonicalZoneName(defaultTimeZone) : "UTC";
}
var HOUR_MS2 = 60 * MINUTE_MS;

// core/adapters/cribl-notify.ts
var BELL_PATH = "/system/messages";
var SEARCH_NOTIFY_PATH = "/search/notifications";
var SEARCH_GROUP = "default_search";
var RELAY_SAVED_SEARCH_ID = "meter_reader_alert_relay";
var RELAY_NOTIFICATION_PREFIX = "meter_reader_relay_";
var SEARCH_NOTIFICATION_ID_PREFIX = "SEARCH_NOTIFICATION_";
var savedSearchPath = (id = RELAY_SAVED_SEARCH_ID) => `/m/${SEARCH_GROUP}/search/saved/${encodeURIComponent(id)}`;
var SAVED_SEARCHES_PATH = `/m/${SEARCH_GROUP}/search/saved`;
async function call(http, method, path, body) {
  try {
    return await http.request(method, path, body);
  } catch (e) {
    const name = e instanceof Error ? e.name : "";
    const message = e instanceof Error ? e.message : String(e);
    const thrown = name === "BudgetExceeded" ? "budget" : name === "RateLimited" ? "rate_limited" : "network_error";
    return { status: 0, ok: false, thrown, message };
  }
}
function errorMessage(res) {
  const j = res.json;
  const m = typeof j?.message === "string" ? j.message : typeof res.text === "string" ? res.text : void 0;
  if (!m)
    return void 0;
  const flat = m.replace(/\s+/g, " ").trim();
  return flat.length > 160 ? `${flat.slice(0, 159)}\u2026` : flat;
}
function classifyCribl(res, conflictOk = false) {
  const s = res.status;
  if (res.thrown)
    return { status: 0, ok: false, error: res.thrown, retry: res.thrown === "network_error", ...res.message ? { detail: res.message } : {} };
  if (s >= 200 && s < 300)
    return { status: s, ok: true, retry: false };
  if (s === 409 && conflictOk)
    return { status: s, ok: true, retry: false, detail: "already exists" };
  const detail = errorMessage(res);
  const withDetail = (o) => detail ? { ...o, detail } : o;
  if (s === 0)
    return withDetail({ status: 0, ok: false, error: "network_error", retry: true });
  if (s === 401 || s === 403)
    return withDetail({ status: s, ok: false, error: "not_permitted", retry: false });
  if (s === 404 || s === 405)
    return withDetail({ status: s, ok: false, error: "not_available", retry: false });
  if (s === 400)
    return withDetail({ status: s, ok: false, error: "invalid_request", retry: false });
  if (s === 429)
    return withDetail({ status: s, ok: false, error: "rate_limited", retry: false });
  return withDetail({ status: s, ok: false, error: `http_${s}`, retry: s >= 500 });
}
var BELL_SEVERITY = { high: "error", medium: "warn", info: "info" };
async function postBell(http, msg) {
  const out = classifyCribl(await call(http, "POST", BELL_PATH, msg), true);
  return out.status === 409 ? { ...out, detail: "already in the bell" } : out;
}
function relayNotificationId(targetId) {
  return `${RELAY_NOTIFICATION_PREFIX}${targetId.replace(/[^A-Za-z0-9_-]/g, "_")}`;
}
function relayEventId(notificationId, suffix) {
  return `${SEARCH_NOTIFICATION_ID_PREFIX}${notificationId}_${suffix.replace(/[^A-Za-z0-9_.-]/g, "_")}`;
}
async function relayState(http, targetId) {
  const res = await call(http, "GET", savedSearchPath());
  if (res.status === 404)
    return { state: "missing", savedSearch: false, notification: false };
  const out = classifyCribl(res);
  if (!out.ok)
    return { state: "error", status: out.status, error: out.error ?? "network_error", ...out.detail ? { detail: out.detail } : {} };
  const saved = res.json?.items?.[0];
  const wanted = relayNotificationId(targetId);
  const found = (saved?.schedule?.notifications?.items ?? []).some((n) => n?.id === wanted);
  return found ? { state: "ready", notificationId: wanted } : { state: "missing", savedSearch: true, notification: false };
}
function forwardBody(m) {
  const notificationId = relayNotificationId(m.targetId);
  const body = {
    id: relayEventId(notificationId, m.suffix),
    notificationId,
    savedQueryId: RELAY_SAVED_SEARCH_ID,
    group: SEARCH_GROUP,
    title: m.title,
    severity: BELL_SEVERITY[m.severity],
    message: m.message,
    _raw: m.message,
    now: m.now,
    _time: m.now
  };
  if (m.payload)
    body.meter_reader = m.payload;
  return body;
}
async function forwardViaTarget(http, m) {
  const res = await call(http, "POST", SEARCH_NOTIFY_PATH, forwardBody(m));
  const out = classifyCribl(res);
  if (res.status === 500)
    return { ...out, error: "relay_missing", retry: false };
  return { ...out, retry: false };
}

// core/delivery.ts
function channelOf(ep) {
  return ep.channel === "cribl-bell" || ep.channel === "cribl-target" ? ep.channel : "webhook";
}
function isRecovered(c, i) {
  return c.event === "incident.closed" || !!i.closedAt;
}
function commitLine(i) {
  if (!i.commit)
    return "no configuration change found nearby";
  const nearby = i.commit.match === "nearby" ? " (nearby change)" : "";
  return `commit ${i.commit.hash.slice(0, 7)} by ${displayAuthor(i.commit.author)}${nearby}`;
}
function renderAlert(c, tz = "UTC") {
  if (c.event === "receipt.weekly" && c.receipt) {
    const r = c.receipt;
    const f = footMoney({ whpM: r.whpM, paidM: r.paidM, savedM: r.savedM });
    return {
      title: `Weekly receipt \xB7 ${r.label}`,
      line: `Saved by Cribl ${fmtDollars(f.savedM)} \xB7 would have paid ${fmtDollars(f.whpM)} \xB7 paid ${fmtDollars(f.paidM)} \xB7 ${fmtPct(r.ratio)} saved \xB7 ${CREDIT_STRINGS.signature}`,
      text: receiptText(r),
      severity: "info"
    };
  }
  const i = c.incident;
  if (!i) {
    const title2 = c.event === "test" ? "Meter Reader test notification" : `Meter Reader ${c.event}`;
    return { title: title2, line: title2, text: title2, severity: "info" };
  }
  const recovered = isRecovered(c, i) && i.type !== "goodnews";
  const prefix = c.event === "test" ? "Test: " : recovered ? closedPrefix(i) : "";
  const title = `${prefix}${i.title}`;
  const money = impactPhrase(i);
  const caught = !recovered && isCatchUp(i) ? ` \xB7 ${caughtLine(i)}` : "";
  const line = `${i.type === "budget" ? money : `${money} \xB7 ${commitLine(i)}`}${caught} \xB7 ${CREDIT_STRINGS.signature}`;
  const body = incidentPlainText(i, tz).split("\n").slice(1);
  return {
    title,
    line,
    text: [title, ...body].join("\n"),
    // Core-11 (m2, #5): a test posts as info, whatever its sample's severity (README: tests post as info).
    severity: c.event === "test" || recovered || i.type === "goodnews" ? "info" : i.severity
  };
}
function bellMessageId(c) {
  const sent = fromIso(c.sentAt);
  const stamp = Number.isNaN(sent) ? "0" : String(sent);
  if (c.event === "receipt.weekly" && c.receipt)
    return `meter-reader-receipt-${c.receipt.periodStart.slice(0, 10)}`;
  const i = c.incident;
  if (!i)
    return `meter-reader-${c.event.replace(/\W/g, "-")}-${stamp}`;
  if (c.event === "test")
    return `meter-reader-test-${stamp}`;
  return `meter-reader-${i.id}-${isRecovered(c, i) ? "closed" : i.severity}`;
}
var BELL_ALREADY_STATUS = 208;
var BELL_UNAVAILABLE_DETAIL = "Cribl notification API unavailable";
function createDeliveryRouter(deps) {
  const sleep = deps.sleep ?? defaultSleep;
  const relays = /* @__PURE__ */ new Map();
  let bellUnavailable;
  const deliveredAlerts = /* @__PURE__ */ new Set();
  const alertKey = (req) => req.incidentId !== void 0 && req.event !== "receipt.weekly" && req.event !== "test" ? `${req.incidentId}|${req.event}` : void 0;
  const logEntry = (req, attempt, at, out) => {
    const entry = {
      endpointId: req.endpoint.id,
      event: req.event,
      status: out.status,
      attempt,
      at: new Date(at).toISOString(),
      kind: "notify"
    };
    if (req.incidentId !== void 0)
      entry.incidentId = req.incidentId;
    if (out.error !== void 0)
      entry.error = out.error;
    if (out.detail !== void 0)
      entry.detail = out.detail;
    return entry;
  };
  const bellSkipped = (req, at, out) => {
    const key = alertKey(req);
    if (key === void 0 || deliveredAlerts.has(key))
      return [];
    return [logEntry(req, 1, at, { status: out.status, ...out.error !== void 0 ? { error: out.error } : {}, detail: out.detail ?? BELL_UNAVAILABLE_DETAIL })];
  };
  async function bell(req) {
    const ep = req.endpoint;
    if (ep.implicit && bellUnavailable)
      return bellSkipped(req, deps.clock.now(), bellUnavailable);
    const r = renderAlert(req.canonical, req.tz ?? "UTC");
    const msg = {
      id: bellMessageId(req.canonical),
      severity: BELL_SEVERITY[r.severity],
      title: r.title,
      text: r.line,
      time: deps.clock.now()
    };
    const backoff = req.backoffMs ?? WEBHOOK_BACKOFF_MS;
    const logs = [];
    for (let attempt = 1; attempt <= backoff.length + 1; attempt++) {
      const at = deps.clock.now();
      const out = await postBell(deps.http, msg);
      if (ep.implicit && (out.error === "not_available" || out.error === "not_permitted")) {
        bellUnavailable = out;
        deps.logger?.info("delivery: default bell skipped", { status: out.status, error: out.error });
        return bellSkipped(req, at, out);
      }
      const logged = out.ok && out.status === 409 ? { status: BELL_ALREADY_STATUS, detail: "already in the bell (409)" } : out;
      logs.push(logEntry(req, attempt, at, logged));
      if (out.ok || !out.retry || attempt > backoff.length)
        break;
      await sleep(backoff[attempt - 1]);
    }
    return logs;
  }
  async function target(req) {
    const targetId = req.endpoint.criblTargetId ?? "";
    const at = deps.clock.now();
    if (!targetId)
      return [logEntry(req, 1, at, { status: 0, error: "target_missing", detail: "no Cribl notification target chosen" })];
    let state = relays.get(targetId);
    if (!state) {
      state = relayState(deps.http, targetId);
      relays.set(targetId, state);
    }
    const s = await state;
    if (s.state === "missing") {
      return [logEntry(req, 1, at, { status: 404, error: "relay_missing", detail: "connect this target in Settings \u2192 Where to send alerts" })];
    }
    if (s.state === "error")
      return [logEntry(req, 1, at, { status: s.status, error: s.error, ...s.detail ? { detail: s.detail } : {} })];
    const r = renderAlert(req.canonical, req.tz ?? "UTC");
    const sendAt = deps.clock.now();
    const out = await forwardViaTarget(deps.http, {
      targetId,
      suffix: `${req.incidentId ?? "mr"}_${req.event}_${sendAt}`,
      title: r.title,
      severity: r.severity,
      message: r.text,
      now: sendAt,
      payload: req.canonical
    });
    return [logEntry(req, 1, sendAt, out)];
  }
  async function webhook(req) {
    const ep = req.endpoint;
    const opts = {};
    if (req.tz !== void 0)
      opts.tz = req.tz;
    if (req.labels !== void 0)
      opts.labels = req.labels;
    return deliver({
      sender: deps.webhook,
      url: ep.url,
      body: payloadFor(ep.format, req.canonical, opts),
      clock: deps.clock,
      sleep,
      endpointId: ep.id,
      event: req.event,
      ...req.incidentId !== void 0 ? { incidentId: req.incidentId } : {},
      ...req.backoffMs !== void 0 ? { backoffMs: req.backoffMs } : {}
    });
  }
  const route = (req) => {
    switch (channelOf(req.endpoint)) {
      case "cribl-bell":
        return bell(req);
      case "cribl-target":
        return target(req);
      default:
        return webhook(req);
    }
  };
  return {
    async deliver(req) {
      try {
        const logs = await route(req);
        const key = alertKey(req);
        if (key !== void 0 && logs.some((l) => l.status >= 200 && l.status < 300))
          deliveredAlerts.add(key);
        return logs;
      } catch (e) {
        return [logEntry(req, 1, deps.clock.now(), { status: 0, error: "network_error", detail: e instanceof Error ? e.message : String(e) })];
      }
    }
  };
}

// core/snapshot.ts
var RATIO_BUCKET_MS = 5 * MINUTE_MS;
var CHANGES_WINDOW_MS = 7 * DAY_MS;
var OTHER_FLOW_KEY = makeFlowKey("-", "other", "-", "-", "-");

// core/sweep.ts
var MAX_BACKFILL_MS = 46 * HOUR_MS;
var MAX_SWEEP_SPAN_MS = 24 * HOUR_MS;
var FIRST_RUN_SEED_MS = 60 * MINUTE_MS;
var HOLD_EMPTY_MAX_MS = 3 * MINUTE_MS;
var NOTIFY_LOG_CAP = 200;
var FAILED_ATTEMPT_COOLDOWN_MS = 2 * MINUTE_MS;
var UNDELIVERED_CLOSURE_MS = 10 * MINUTE_MS;
function statusOf(e) {
  const s = e !== null && typeof e === "object" ? e.status : void 0;
  return typeof s === "number" ? s : void 0;
}
function createMeteredTransport(http, kv, opts) {
  const sleep = opts.sleep ?? defaultSleep;
  const delay = opts.retryDelayMs ?? RATE_LIMIT_RETRY_MS;
  let calls = 0;
  let hits = 0;
  let retries = 0;
  const take = (method, path) => {
    if (opts.hardCap !== void 0 && calls + 1 > opts.hardCap)
      throw new BudgetExceeded(opts.hardCap, calls, method, path);
    calls++;
  };
  async function metered(method, path, attempt, limited) {
    for (; ; ) {
      take(method, path);
      let value;
      let answer;
      let was429;
      try {
        value = await attempt();
        was429 = limited(value);
        answer = value;
      } catch (e) {
        if (statusOf(e) !== 429)
          throw e;
        was429 = true;
        answer = e;
      }
      if (!was429)
        return value;
      hits++;
      const after = retryAfterOf(answer, opts.clock.now());
      if (hits > 1)
        throw new RateLimited(method, path, after);
      const wait = retryWaitMs(after, delay);
      if (wait === void 0)
        throw new RateLimited(method, path, after);
      retries++;
      await sleep(wait);
    }
  }
  const never = () => false;
  const kvPath = (key) => `/kvstore/${key}`;
  return {
    http: {
      request: (method, path, body, reqOpts) => metered(
        method,
        path,
        () => http.request(method, path, body, reqOpts),
        (r) => r.status === 429
      )
    },
    kv: {
      get: (key) => metered("GET", kvPath(key), () => kv.get(key), never),
      put: (key, value) => metered("PUT", kvPath(key), () => kv.put(key, value), never),
      del: (key) => metered("DELETE", kvPath(key), () => kv.del(key), never),
      list: (prefix) => metered("POST", "/kvstore/keys", () => kv.list(prefix), never)
    },
    rawKv: {
      get: (key) => (calls++, kv.get(key)),
      put: (key, value) => (calls++, kv.put(key, value)),
      del: (key) => (calls++, kv.del(key)),
      list: (prefix) => (calls++, kv.list(prefix))
    },
    calls: () => calls,
    retries: () => retries,
    limitHits: () => hits
  };
}

// core/weekly.ts
var WEEKLY_AUTO_WINDOW_MS = 7 * DAY_MS;
function docsFor(deps, t, raw = false) {
  return createKvDocs({
    kv: raw ? t.rawKv : t.kv,
    codec: deps.codec,
    clock: deps.clock,
    ...deps.logger ? { logger: deps.logger } : {}
  });
}
function routerFor(deps, t) {
  return createDeliveryRouter({
    http: t.http,
    webhook: deps.webhook,
    clock: deps.clock,
    ...deps.sleep ? { sleep: deps.sleep } : {},
    ...deps.logger ? { logger: deps.logger } : {}
  });
}
async function appendLog(docs, logs, deps) {
  if (logs.length === 0)
    return;
  try {
    const log = await docs.getNotifyLog() ?? {
      schemaVersion: 1,
      items: []
    };
    await docs.putNotifyLog({
      schemaVersion: 1,
      items: [...log.items, ...logs].slice(-NOTIFY_LOG_CAP)
    });
  } catch (e) {
    deps.logger?.warn("notify/log could not be updated", e);
  }
}
async function sendTestNotification(deps, args) {
  const clock = deps.clock;
  const nowMs = args.nowMs ?? clock.now();
  const t = createMeteredTransport(deps.http, deps.kv, {
    clock,
    ...deps.sleep ? { sleep: deps.sleep } : {}
  });
  const docs = docsFor(deps, t);
  const out = (r) => ({
    ...r,
    calls: t.calls()
  });
  try {
    const stored = await docs.getSettings();
    const zone = resolveMeterZone(stored, stored?.displayTimezone ? null : await docs.getTotals(), deps.defaultTimeZone);
    const settings = mergeSettings(stored ?? {}, defaultSettings(toIso(nowMs), zone));
    const endpoint = args.endpoint ?? [...settings.notifications, ...deps.envWebhooks ?? []].find((e) => e.id === args.endpointId);
    if (!endpoint)
      return out({
        status: 0,
        hostAuthorized: false,
        attempts: 0,
        deliveries: [],
        error: "not_found"
      });
    const canonical = testPayload(deps.workspace, toIso(nowMs), deps.linkBase);
    const incidentId2 = canonical.incident?.id;
    const logs = await routerFor(deps, t).deliver({
      endpoint,
      event: "test",
      canonical,
      ...incidentId2 ? { incidentId: incidentId2 } : {},
      tz: settings.displayTimezone,
      labels: settings.humanize
    });
    await appendLog(docs, logs, deps);
    const last = lastAttempt(logs);
    const status = last?.status ?? 0;
    const r = {
      status,
      hostAuthorized: status !== 403,
      attempts: logs.length,
      deliveries: logs
    };
    if (last?.error)
      r.error = last.error;
    return out(r);
  } catch (e) {
    return out({
      status: 0,
      hostAuthorized: false,
      attempts: 0,
      deliveries: [],
      error: e instanceof Error ? e.message : String(e)
    });
  }
}

// core/runtime.ts
var APP_ID = "meter-reader";
var BACKEND_API_BASE = "/api/v1";
function createConsoleLogger(prefix = "[meter-reader]") {
  const c = globalThis.console;
  const emit = (level) => (msg, data) => {
    if (!c)
      return;
    if (data === void 0)
      c[level](`${prefix} ${msg}`);
    else
      c[level](`${prefix} ${msg}`, data);
  };
  return { info: emit("info"), warn: emit("warn"), error: emit("error") };
}
function createOwnerId(prefix, env = globalThis) {
  const uuid = env.crypto?.randomUUID?.();
  return `${prefix}:${uuid ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`}`;
}
function originOf(url) {
  const m = /^(https?):\/\/([^/?#]+)/i.exec((url ?? "").trim());
  if (!m)
    return void 0;
  const host = m[2].replace(/^[^@]*@/, "").replace(/:\d+$/, "").toLowerCase();
  return {
    origin: `${m[1].toLowerCase()}://${m[2].replace(/^[^@]*@/, "")}`,
    host
  };
}
function workspaceFromUrl(url) {
  const o = originOf(url);
  if (!o)
    return "";
  const cloud = /^([^.]+)\.cribl(?:-staging)?\.cloud$/.exec(o.host);
  return cloud ? cloud[1] : o.host;
}
function linkBaseFrom(apiUrl, basePath) {
  const o = originOf(apiUrl);
  return o ? `${o.origin}/apps/a/${APP_ID}` : `/apps/a/${APP_ID}`;
}
function globalFetch() {
  const f = globalThis.fetch;
  return typeof f === "function" ? f : void 0;
}
function createBackendDeps(opts = {}) {
  const fetchFn = opts.fetch ?? globalFetch();
  if (!fetchFn)
    throw new Error("fetch is not available in this environment");
  const deps = {
    http: createFetchHttp({ fetch: fetchFn, baseUrl: BACKEND_API_BASE }),
    kv: createFetchKvStore({ fetch: fetchFn, baseUrl: BACKEND_API_BASE }),
    webhook: createFetchWebhookSender(fetchFn),
    clock: { now: () => Date.now() },
    codec: detectCodec(),
    logger: opts.logger ?? createConsoleLogger(),
    owner: opts.owner ?? createOwnerId("backend"),
    appVersion: opts.appVersion ?? "0.0.0",
    build: opts.build ?? "release",
    runtime: "backend",
    workspace: opts.workspace ?? workspaceFromUrl(opts.requestUrl),
    linkBase: opts.linkBase ?? linkBaseFrom(opts.requestUrl, void 0)
  };
  if (opts.budget !== void 0)
    deps.budget = opts.budget;
  return deps;
}

// package.json
var version = "1.1.2";

// backend/lib/build-info.ts
var APP_VERSION = typeof version === "string" ? version : "0.0.0";
var BUILD = "release";

// backend/lib/http.ts
async function readJsonBody(request) {
  let text;
  try {
    text = await request.text();
  } catch {
    return {};
  }
  if (text.trim() === "")
    return {};
  try {
    const value = JSON.parse(text);
    return value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
  } catch {
    return {};
  }
}
function json(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" }
  });
}
function stringField(body, name) {
  const v = body[name];
  return typeof v === "string" && v.trim() !== "" ? v : void 0;
}

// backend/lib/deps.ts
function depsFor(request, context, body) {
  const workspace = stringField(body, "workspace");
  const linkBase = stringField(body, "linkBase");
  return createBackendDeps({
    appVersion: APP_VERSION,
    build: BUILD,
    owner: context?.invocationId ? `backend:${context.invocationId}` : createOwnerId("backend"),
    requestUrl: request.url,
    ...workspace ? { workspace } : {},
    ...linkBase ? { linkBase } : {}
  });
}

// backend/sendTest.ts
async function onRequest(request, context) {
  const body = await readJsonBody(request);
  const endpointId = stringField(body, "endpointId");
  if (!endpointId)
    return json(400, { error: "endpointId is required" });
  const result = await sendTestNotification(depsFor(request, context, body), {
    endpointId
  });
  if (result.error === "not_found")
    return json(404, { error: "not_found", endpointId });
  return json(200, result);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  onRequest
});
//# sourceMappingURL=sendTest.js.map
